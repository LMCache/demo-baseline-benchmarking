const {
  SvelteComponent: Us,
  assign: xs,
  create_slot: Fs,
  detach: Gs,
  element: qs,
  get_all_dirty_from_scope: js,
  get_slot_changes: Vs,
  get_spread_update: zs,
  init: Xs,
  insert: Ws,
  safe_not_equal: Zs,
  set_dynamic_element_data: yr,
  set_style: ie,
  toggle_class: Me,
  transition_in: Ii,
  transition_out: Li,
  update_slot_base: Js
} = window.__gradio__svelte__internal;
function Qs(e) {
  let t, n, r;
  const i = (
    /*#slots*/
    e[18].default
  ), s = Fs(
    i,
    e,
    /*$$scope*/
    e[17],
    null
  );
  let l = [
    { "data-testid": (
      /*test_id*/
      e[7]
    ) },
    { id: (
      /*elem_id*/
      e[2]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      e[3].join(" ") + " svelte-1t38q2d"
    }
  ], a = {};
  for (let o = 0; o < l.length; o += 1)
    a = xs(a, l[o]);
  return {
    c() {
      t = qs(
        /*tag*/
        e[14]
      ), s && s.c(), yr(
        /*tag*/
        e[14]
      )(t, a), Me(
        t,
        "hidden",
        /*visible*/
        e[10] === !1
      ), Me(
        t,
        "padded",
        /*padding*/
        e[6]
      ), Me(
        t,
        "border_focus",
        /*border_mode*/
        e[5] === "focus"
      ), Me(t, "hide-container", !/*explicit_call*/
      e[8] && !/*container*/
      e[9]), ie(
        t,
        "height",
        /*get_dimension*/
        e[15](
          /*height*/
          e[0]
        )
      ), ie(t, "width", typeof /*width*/
      e[1] == "number" ? `calc(min(${/*width*/
      e[1]}px, 100%))` : (
        /*get_dimension*/
        e[15](
          /*width*/
          e[1]
        )
      )), ie(
        t,
        "border-style",
        /*variant*/
        e[4]
      ), ie(
        t,
        "overflow",
        /*allow_overflow*/
        e[11] ? "visible" : "hidden"
      ), ie(
        t,
        "flex-grow",
        /*scale*/
        e[12]
      ), ie(t, "min-width", `calc(min(${/*min_width*/
      e[13]}px, 100%))`), ie(t, "border-width", "var(--block-border-width)");
    },
    m(o, u) {
      Ws(o, t, u), s && s.m(t, null), r = !0;
    },
    p(o, u) {
      s && s.p && (!r || u & /*$$scope*/
      131072) && Js(
        s,
        i,
        o,
        /*$$scope*/
        o[17],
        r ? Vs(
          i,
          /*$$scope*/
          o[17],
          u,
          null
        ) : js(
          /*$$scope*/
          o[17]
        ),
        null
      ), yr(
        /*tag*/
        o[14]
      )(t, a = zs(l, [
        (!r || u & /*test_id*/
        128) && { "data-testid": (
          /*test_id*/
          o[7]
        ) },
        (!r || u & /*elem_id*/
        4) && { id: (
          /*elem_id*/
          o[2]
        ) },
        (!r || u & /*elem_classes*/
        8 && n !== (n = "block " + /*elem_classes*/
        o[3].join(" ") + " svelte-1t38q2d")) && { class: n }
      ])), Me(
        t,
        "hidden",
        /*visible*/
        o[10] === !1
      ), Me(
        t,
        "padded",
        /*padding*/
        o[6]
      ), Me(
        t,
        "border_focus",
        /*border_mode*/
        o[5] === "focus"
      ), Me(t, "hide-container", !/*explicit_call*/
      o[8] && !/*container*/
      o[9]), u & /*height*/
      1 && ie(
        t,
        "height",
        /*get_dimension*/
        o[15](
          /*height*/
          o[0]
        )
      ), u & /*width*/
      2 && ie(t, "width", typeof /*width*/
      o[1] == "number" ? `calc(min(${/*width*/
      o[1]}px, 100%))` : (
        /*get_dimension*/
        o[15](
          /*width*/
          o[1]
        )
      )), u & /*variant*/
      16 && ie(
        t,
        "border-style",
        /*variant*/
        o[4]
      ), u & /*allow_overflow*/
      2048 && ie(
        t,
        "overflow",
        /*allow_overflow*/
        o[11] ? "visible" : "hidden"
      ), u & /*scale*/
      4096 && ie(
        t,
        "flex-grow",
        /*scale*/
        o[12]
      ), u & /*min_width*/
      8192 && ie(t, "min-width", `calc(min(${/*min_width*/
      o[13]}px, 100%))`);
    },
    i(o) {
      r || (Ii(s, o), r = !0);
    },
    o(o) {
      Li(s, o), r = !1;
    },
    d(o) {
      o && Gs(t), s && s.d(o);
    }
  };
}
function Ys(e) {
  let t, n = (
    /*tag*/
    e[14] && Qs(e)
  );
  return {
    c() {
      n && n.c();
    },
    m(r, i) {
      n && n.m(r, i), t = !0;
    },
    p(r, [i]) {
      /*tag*/
      r[14] && n.p(r, i);
    },
    i(r) {
      t || (Ii(n, r), t = !0);
    },
    o(r) {
      Li(n, r), t = !1;
    },
    d(r) {
      n && n.d(r);
    }
  };
}
function Ks(e, t, n) {
  let { $$slots: r = {}, $$scope: i } = t, { height: s = void 0 } = t, { width: l = void 0 } = t, { elem_id: a = "" } = t, { elem_classes: o = [] } = t, { variant: u = "solid" } = t, { border_mode: f = "base" } = t, { padding: c = !0 } = t, { type: h = "normal" } = t, { test_id: _ = void 0 } = t, { explicit_call: d = !1 } = t, { container: p = !0 } = t, { visible: y = !0 } = t, { allow_overflow: v = !0 } = t, { scale: E = null } = t, { min_width: g = 0 } = t, A = h === "fieldset" ? "fieldset" : "div";
  const T = (w) => {
    if (w !== void 0) {
      if (typeof w == "number")
        return w + "px";
      if (typeof w == "string")
        return w;
    }
  };
  return e.$$set = (w) => {
    "height" in w && n(0, s = w.height), "width" in w && n(1, l = w.width), "elem_id" in w && n(2, a = w.elem_id), "elem_classes" in w && n(3, o = w.elem_classes), "variant" in w && n(4, u = w.variant), "border_mode" in w && n(5, f = w.border_mode), "padding" in w && n(6, c = w.padding), "type" in w && n(16, h = w.type), "test_id" in w && n(7, _ = w.test_id), "explicit_call" in w && n(8, d = w.explicit_call), "container" in w && n(9, p = w.container), "visible" in w && n(10, y = w.visible), "allow_overflow" in w && n(11, v = w.allow_overflow), "scale" in w && n(12, E = w.scale), "min_width" in w && n(13, g = w.min_width), "$$scope" in w && n(17, i = w.$$scope);
  }, [
    s,
    l,
    a,
    o,
    u,
    f,
    c,
    _,
    d,
    p,
    y,
    v,
    E,
    g,
    A,
    T,
    h,
    i,
    r
  ];
}
class Oi extends Us {
  constructor(t) {
    super(), Xs(this, t, Ks, Ys, Zs, {
      height: 0,
      width: 1,
      elem_id: 2,
      elem_classes: 3,
      variant: 4,
      border_mode: 5,
      padding: 6,
      type: 16,
      test_id: 7,
      explicit_call: 8,
      container: 9,
      visible: 10,
      allow_overflow: 11,
      scale: 12,
      min_width: 13
    });
  }
}
const {
  SvelteComponent: $s,
  append: _n,
  attr: Dt,
  create_component: el,
  destroy_component: tl,
  detach: nl,
  element: wr,
  init: rl,
  insert: il,
  mount_component: sl,
  safe_not_equal: ll,
  set_data: ol,
  space: al,
  text: ul,
  toggle_class: De,
  transition_in: fl,
  transition_out: cl
} = window.__gradio__svelte__internal;
function hl(e) {
  let t, n, r, i, s, l;
  return r = new /*Icon*/
  e[1]({}), {
    c() {
      t = wr("label"), n = wr("span"), el(r.$$.fragment), i = al(), s = ul(
        /*label*/
        e[0]
      ), Dt(n, "class", "svelte-9gxdi0"), Dt(t, "for", ""), Dt(t, "data-testid", "block-label"), Dt(t, "class", "svelte-9gxdi0"), De(t, "hide", !/*show_label*/
      e[2]), De(t, "sr-only", !/*show_label*/
      e[2]), De(
        t,
        "float",
        /*float*/
        e[4]
      ), De(
        t,
        "hide-label",
        /*disable*/
        e[3]
      );
    },
    m(a, o) {
      il(a, t, o), _n(t, n), sl(r, n, null), _n(t, i), _n(t, s), l = !0;
    },
    p(a, [o]) {
      (!l || o & /*label*/
      1) && ol(
        s,
        /*label*/
        a[0]
      ), (!l || o & /*show_label*/
      4) && De(t, "hide", !/*show_label*/
      a[2]), (!l || o & /*show_label*/
      4) && De(t, "sr-only", !/*show_label*/
      a[2]), (!l || o & /*float*/
      16) && De(
        t,
        "float",
        /*float*/
        a[4]
      ), (!l || o & /*disable*/
      8) && De(
        t,
        "hide-label",
        /*disable*/
        a[3]
      );
    },
    i(a) {
      l || (fl(r.$$.fragment, a), l = !0);
    },
    o(a) {
      cl(r.$$.fragment, a), l = !1;
    },
    d(a) {
      a && nl(t), tl(r);
    }
  };
}
function _l(e, t, n) {
  let { label: r = null } = t, { Icon: i } = t, { show_label: s = !0 } = t, { disable: l = !1 } = t, { float: a = !0 } = t;
  return e.$$set = (o) => {
    "label" in o && n(0, r = o.label), "Icon" in o && n(1, i = o.Icon), "show_label" in o && n(2, s = o.show_label), "disable" in o && n(3, l = o.disable), "float" in o && n(4, a = o.float);
  }, [r, i, s, l, a];
}
class Mi extends $s {
  constructor(t) {
    super(), rl(this, t, _l, hl, ll, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4
    });
  }
}
const {
  SvelteComponent: dl,
  append: Ln,
  attr: ke,
  bubble: ml,
  create_component: pl,
  destroy_component: gl,
  detach: Di,
  element: On,
  init: bl,
  insert: Ri,
  listen: vl,
  mount_component: yl,
  safe_not_equal: wl,
  set_data: El,
  set_style: Rt,
  space: Sl,
  text: Tl,
  toggle_class: ce,
  transition_in: Al,
  transition_out: Bl
} = window.__gradio__svelte__internal;
function Er(e) {
  let t, n;
  return {
    c() {
      t = On("span"), n = Tl(
        /*label*/
        e[1]
      ), ke(t, "class", "svelte-lpi64a");
    },
    m(r, i) {
      Ri(r, t, i), Ln(t, n);
    },
    p(r, i) {
      i & /*label*/
      2 && El(
        n,
        /*label*/
        r[1]
      );
    },
    d(r) {
      r && Di(t);
    }
  };
}
function Hl(e) {
  let t, n, r, i, s, l, a, o = (
    /*show_label*/
    e[2] && Er(e)
  );
  return i = new /*Icon*/
  e[0]({}), {
    c() {
      t = On("button"), o && o.c(), n = Sl(), r = On("div"), pl(i.$$.fragment), ke(r, "class", "svelte-lpi64a"), ce(
        r,
        "small",
        /*size*/
        e[4] === "small"
      ), ce(
        r,
        "large",
        /*size*/
        e[4] === "large"
      ), t.disabled = /*disabled*/
      e[7], ke(
        t,
        "aria-label",
        /*label*/
        e[1]
      ), ke(
        t,
        "aria-haspopup",
        /*hasPopup*/
        e[8]
      ), ke(
        t,
        "title",
        /*label*/
        e[1]
      ), ke(t, "class", "svelte-lpi64a"), ce(
        t,
        "pending",
        /*pending*/
        e[3]
      ), ce(
        t,
        "padded",
        /*padded*/
        e[5]
      ), ce(
        t,
        "highlight",
        /*highlight*/
        e[6]
      ), ce(
        t,
        "transparent",
        /*transparent*/
        e[9]
      ), Rt(t, "color", !/*disabled*/
      e[7] && /*_color*/
      e[11] ? (
        /*_color*/
        e[11]
      ) : "var(--block-label-text-color)"), Rt(t, "--bg-color", /*disabled*/
      e[7] ? "auto" : (
        /*background*/
        e[10]
      ));
    },
    m(u, f) {
      Ri(u, t, f), o && o.m(t, null), Ln(t, n), Ln(t, r), yl(i, r, null), s = !0, l || (a = vl(
        t,
        "click",
        /*click_handler*/
        e[13]
      ), l = !0);
    },
    p(u, [f]) {
      /*show_label*/
      u[2] ? o ? o.p(u, f) : (o = Er(u), o.c(), o.m(t, n)) : o && (o.d(1), o = null), (!s || f & /*size*/
      16) && ce(
        r,
        "small",
        /*size*/
        u[4] === "small"
      ), (!s || f & /*size*/
      16) && ce(
        r,
        "large",
        /*size*/
        u[4] === "large"
      ), (!s || f & /*disabled*/
      128) && (t.disabled = /*disabled*/
      u[7]), (!s || f & /*label*/
      2) && ke(
        t,
        "aria-label",
        /*label*/
        u[1]
      ), (!s || f & /*hasPopup*/
      256) && ke(
        t,
        "aria-haspopup",
        /*hasPopup*/
        u[8]
      ), (!s || f & /*label*/
      2) && ke(
        t,
        "title",
        /*label*/
        u[1]
      ), (!s || f & /*pending*/
      8) && ce(
        t,
        "pending",
        /*pending*/
        u[3]
      ), (!s || f & /*padded*/
      32) && ce(
        t,
        "padded",
        /*padded*/
        u[5]
      ), (!s || f & /*highlight*/
      64) && ce(
        t,
        "highlight",
        /*highlight*/
        u[6]
      ), (!s || f & /*transparent*/
      512) && ce(
        t,
        "transparent",
        /*transparent*/
        u[9]
      ), f & /*disabled, _color*/
      2176 && Rt(t, "color", !/*disabled*/
      u[7] && /*_color*/
      u[11] ? (
        /*_color*/
        u[11]
      ) : "var(--block-label-text-color)"), f & /*disabled, background*/
      1152 && Rt(t, "--bg-color", /*disabled*/
      u[7] ? "auto" : (
        /*background*/
        u[10]
      ));
    },
    i(u) {
      s || (Al(i.$$.fragment, u), s = !0);
    },
    o(u) {
      Bl(i.$$.fragment, u), s = !1;
    },
    d(u) {
      u && Di(t), o && o.d(), gl(i), l = !1, a();
    }
  };
}
function kl(e, t, n) {
  let r, { Icon: i } = t, { label: s = "" } = t, { show_label: l = !1 } = t, { pending: a = !1 } = t, { size: o = "small" } = t, { padded: u = !0 } = t, { highlight: f = !1 } = t, { disabled: c = !1 } = t, { hasPopup: h = !1 } = t, { color: _ = "var(--block-label-text-color)" } = t, { transparent: d = !1 } = t, { background: p = "var(--background-fill-primary)" } = t;
  function y(v) {
    ml.call(this, e, v);
  }
  return e.$$set = (v) => {
    "Icon" in v && n(0, i = v.Icon), "label" in v && n(1, s = v.label), "show_label" in v && n(2, l = v.show_label), "pending" in v && n(3, a = v.pending), "size" in v && n(4, o = v.size), "padded" in v && n(5, u = v.padded), "highlight" in v && n(6, f = v.highlight), "disabled" in v && n(7, c = v.disabled), "hasPopup" in v && n(8, h = v.hasPopup), "color" in v && n(12, _ = v.color), "transparent" in v && n(9, d = v.transparent), "background" in v && n(10, p = v.background);
  }, e.$$.update = () => {
    e.$$.dirty & /*highlight, color*/
    4160 && n(11, r = f ? "var(--color-accent)" : _);
  }, [
    i,
    s,
    l,
    a,
    o,
    u,
    f,
    c,
    h,
    d,
    p,
    r,
    _,
    y
  ];
}
class Cl extends dl {
  constructor(t) {
    super(), bl(this, t, kl, Hl, wl, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: Pl,
  append: Nl,
  attr: dn,
  binding_callbacks: Il,
  create_slot: Ll,
  detach: Ol,
  element: Sr,
  get_all_dirty_from_scope: Ml,
  get_slot_changes: Dl,
  init: Rl,
  insert: Ul,
  safe_not_equal: xl,
  toggle_class: Re,
  transition_in: Fl,
  transition_out: Gl,
  update_slot_base: ql
} = window.__gradio__svelte__internal;
function jl(e) {
  let t, n, r;
  const i = (
    /*#slots*/
    e[5].default
  ), s = Ll(
    i,
    e,
    /*$$scope*/
    e[4],
    null
  );
  return {
    c() {
      t = Sr("div"), n = Sr("div"), s && s.c(), dn(n, "class", "icon svelte-3w3rth"), dn(t, "class", "empty svelte-3w3rth"), dn(t, "aria-label", "Empty value"), Re(
        t,
        "small",
        /*size*/
        e[0] === "small"
      ), Re(
        t,
        "large",
        /*size*/
        e[0] === "large"
      ), Re(
        t,
        "unpadded_box",
        /*unpadded_box*/
        e[1]
      ), Re(
        t,
        "small_parent",
        /*parent_height*/
        e[3]
      );
    },
    m(l, a) {
      Ul(l, t, a), Nl(t, n), s && s.m(n, null), e[6](t), r = !0;
    },
    p(l, [a]) {
      s && s.p && (!r || a & /*$$scope*/
      16) && ql(
        s,
        i,
        l,
        /*$$scope*/
        l[4],
        r ? Dl(
          i,
          /*$$scope*/
          l[4],
          a,
          null
        ) : Ml(
          /*$$scope*/
          l[4]
        ),
        null
      ), (!r || a & /*size*/
      1) && Re(
        t,
        "small",
        /*size*/
        l[0] === "small"
      ), (!r || a & /*size*/
      1) && Re(
        t,
        "large",
        /*size*/
        l[0] === "large"
      ), (!r || a & /*unpadded_box*/
      2) && Re(
        t,
        "unpadded_box",
        /*unpadded_box*/
        l[1]
      ), (!r || a & /*parent_height*/
      8) && Re(
        t,
        "small_parent",
        /*parent_height*/
        l[3]
      );
    },
    i(l) {
      r || (Fl(s, l), r = !0);
    },
    o(l) {
      Gl(s, l), r = !1;
    },
    d(l) {
      l && Ol(t), s && s.d(l), e[6](null);
    }
  };
}
function Vl(e) {
  let t, n = e[0], r = 1;
  for (; r < e.length; ) {
    const i = e[r], s = e[r + 1];
    if (r += 2, (i === "optionalAccess" || i === "optionalCall") && n == null)
      return;
    i === "access" || i === "optionalAccess" ? (t = n, n = s(n)) : (i === "call" || i === "optionalCall") && (n = s((...l) => n.call(t, ...l)), t = void 0);
  }
  return n;
}
function zl(e, t, n) {
  let r, { $$slots: i = {}, $$scope: s } = t, { size: l = "small" } = t, { unpadded_box: a = !1 } = t, o;
  function u(c) {
    if (!c)
      return !1;
    const { height: h } = c.getBoundingClientRect(), { height: _ } = Vl([
      c,
      "access",
      (d) => d.parentElement,
      "optionalAccess",
      (d) => d.getBoundingClientRect,
      "call",
      (d) => d()
    ]) || { height: h };
    return h > _ + 2;
  }
  function f(c) {
    Il[c ? "unshift" : "push"](() => {
      o = c, n(2, o);
    });
  }
  return e.$$set = (c) => {
    "size" in c && n(0, l = c.size), "unpadded_box" in c && n(1, a = c.unpadded_box), "$$scope" in c && n(4, s = c.$$scope);
  }, e.$$.update = () => {
    e.$$.dirty & /*el*/
    4 && n(3, r = u(o));
  }, [l, a, o, r, s, i, f];
}
class Xl extends Pl {
  constructor(t) {
    super(), Rl(this, t, zl, jl, xl, { size: 0, unpadded_box: 1 });
  }
}
const {
  SvelteComponent: Wl,
  append: mn,
  attr: be,
  detach: Zl,
  init: Jl,
  insert: Ql,
  noop: pn,
  safe_not_equal: Yl,
  set_style: we,
  svg_element: Ut
} = window.__gradio__svelte__internal;
function Kl(e) {
  let t, n, r, i;
  return {
    c() {
      t = Ut("svg"), n = Ut("g"), r = Ut("path"), i = Ut("path"), be(r, "d", "M18,6L6.087,17.913"), we(r, "fill", "none"), we(r, "fill-rule", "nonzero"), we(r, "stroke-width", "2px"), be(n, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), be(i, "d", "M4.364,4.364L19.636,19.636"), we(i, "fill", "none"), we(i, "fill-rule", "nonzero"), we(i, "stroke-width", "2px"), be(t, "width", "100%"), be(t, "height", "100%"), be(t, "viewBox", "0 0 24 24"), be(t, "version", "1.1"), be(t, "xmlns", "http://www.w3.org/2000/svg"), be(t, "xmlns:xlink", "http://www.w3.org/1999/xlink"), be(t, "xml:space", "preserve"), be(t, "stroke", "currentColor"), we(t, "fill-rule", "evenodd"), we(t, "clip-rule", "evenodd"), we(t, "stroke-linecap", "round"), we(t, "stroke-linejoin", "round");
    },
    m(s, l) {
      Ql(s, t, l), mn(t, n), mn(n, r), mn(t, i);
    },
    p: pn,
    i: pn,
    o: pn,
    d(s) {
      s && Zl(t);
    }
  };
}
class $l extends Wl {
  constructor(t) {
    super(), Jl(this, t, null, Kl, Yl, {});
  }
}
const {
  SvelteComponent: eo,
  append: Tr,
  attr: he,
  detach: to,
  init: no,
  insert: ro,
  noop: gn,
  safe_not_equal: io,
  svg_element: bn
} = window.__gradio__svelte__internal;
function so(e) {
  let t, n, r;
  return {
    c() {
      t = bn("svg"), n = bn("path"), r = bn("polyline"), he(n, "d", "M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"), he(r, "points", "13 2 13 9 20 9"), he(t, "xmlns", "http://www.w3.org/2000/svg"), he(t, "width", "100%"), he(t, "height", "100%"), he(t, "viewBox", "0 0 24 24"), he(t, "fill", "none"), he(t, "stroke", "currentColor"), he(t, "stroke-width", "1.5"), he(t, "stroke-linecap", "round"), he(t, "stroke-linejoin", "round"), he(t, "class", "feather feather-file");
    },
    m(i, s) {
      ro(i, t, s), Tr(t, n), Tr(t, r);
    },
    p: gn,
    i: gn,
    o: gn,
    d(i) {
      i && to(t);
    }
  };
}
let or = class extends eo {
  constructor(t) {
    super(), no(this, t, null, so, io, {});
  }
};
const {
  SvelteComponent: lo,
  append: oo,
  attr: st,
  detach: ao,
  init: uo,
  insert: fo,
  noop: vn,
  safe_not_equal: co,
  svg_element: Ar
} = window.__gradio__svelte__internal;
function ho(e) {
  let t, n;
  return {
    c() {
      t = Ar("svg"), n = Ar("path"), st(n, "fill", "currentColor"), st(n, "d", "M13.75 2a2.25 2.25 0 0 1 2.236 2.002V4h1.764A2.25 2.25 0 0 1 20 6.25V11h-1.5V6.25a.75.75 0 0 0-.75-.75h-2.129c-.404.603-1.091 1-1.871 1h-3.5c-.78 0-1.467-.397-1.871-1H6.25a.75.75 0 0 0-.75.75v13.5c0 .414.336.75.75.75h4.78a3.99 3.99 0 0 0 .505 1.5H6.25A2.25 2.25 0 0 1 4 19.75V6.25A2.25 2.25 0 0 1 6.25 4h1.764a2.25 2.25 0 0 1 2.236-2h3.5Zm2.245 2.096L16 4.25c0-.052-.002-.103-.005-.154ZM13.75 3.5h-3.5a.75.75 0 0 0 0 1.5h3.5a.75.75 0 0 0 0-1.5ZM15 12a3 3 0 0 0-3 3v5c0 .556.151 1.077.415 1.524l3.494-3.494a2.25 2.25 0 0 1 3.182 0l3.494 3.494c.264-.447.415-.968.415-1.524v-5a3 3 0 0 0-3-3h-5Zm0 11a2.985 2.985 0 0 1-1.524-.415l3.494-3.494a.75.75 0 0 1 1.06 0l3.494 3.494A2.985 2.985 0 0 1 20 23h-5Zm5-7a1 1 0 1 1 0-2a1 1 0 0 1 0 2Z"), st(t, "xmlns", "http://www.w3.org/2000/svg"), st(t, "width", "100%"), st(t, "height", "100%"), st(t, "viewBox", "0 0 24 24");
    },
    m(r, i) {
      fo(r, t, i), oo(t, n);
    },
    p: vn,
    i: vn,
    o: vn,
    d(r) {
      r && ao(t);
    }
  };
}
class _o extends lo {
  constructor(t) {
    super(), uo(this, t, null, ho, co, {});
  }
}
const {
  SvelteComponent: mo,
  append: yn,
  attr: Q,
  detach: po,
  init: go,
  insert: bo,
  noop: wn,
  safe_not_equal: vo,
  svg_element: xt
} = window.__gradio__svelte__internal;
function yo(e) {
  let t, n, r, i;
  return {
    c() {
      t = xt("svg"), n = xt("path"), r = xt("polyline"), i = xt("line"), Q(n, "d", "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"), Q(r, "points", "17 8 12 3 7 8"), Q(i, "x1", "12"), Q(i, "y1", "3"), Q(i, "x2", "12"), Q(i, "y2", "15"), Q(t, "xmlns", "http://www.w3.org/2000/svg"), Q(t, "width", "90%"), Q(t, "height", "90%"), Q(t, "viewBox", "0 0 24 24"), Q(t, "fill", "none"), Q(t, "stroke", "currentColor"), Q(t, "stroke-width", "2"), Q(t, "stroke-linecap", "round"), Q(t, "stroke-linejoin", "round"), Q(t, "class", "feather feather-upload");
    },
    m(s, l) {
      bo(s, t, l), yn(t, n), yn(t, r), yn(t, i);
    },
    p: wn,
    i: wn,
    o: wn,
    d(s) {
      s && po(t);
    }
  };
}
let wo = class extends mo {
  constructor(t) {
    super(), go(this, t, null, yo, vo, {});
  }
};
const Eo = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Br = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Eo.reduce(
  (e, { color: t, primary: n, secondary: r }) => ({
    ...e,
    [t]: {
      primary: Br[t][n],
      secondary: Br[t][r]
    }
  }),
  {}
);
const {
  SvelteComponent: So,
  append: Je,
  attr: Mn,
  check_outros: To,
  create_component: Ui,
  destroy_component: xi,
  detach: Vt,
  element: Dn,
  group_outros: Ao,
  init: Bo,
  insert: zt,
  mount_component: Fi,
  safe_not_equal: Ho,
  set_data: Rn,
  space: Un,
  text: Bt,
  toggle_class: Hr,
  transition_in: Zt,
  transition_out: Jt
} = window.__gradio__svelte__internal;
function ko(e) {
  let t, n;
  return t = new wo({}), {
    c() {
      Ui(t.$$.fragment);
    },
    m(r, i) {
      Fi(t, r, i), n = !0;
    },
    i(r) {
      n || (Zt(t.$$.fragment, r), n = !0);
    },
    o(r) {
      Jt(t.$$.fragment, r), n = !1;
    },
    d(r) {
      xi(t, r);
    }
  };
}
function Co(e) {
  let t, n;
  return t = new _o({}), {
    c() {
      Ui(t.$$.fragment);
    },
    m(r, i) {
      Fi(t, r, i), n = !0;
    },
    i(r) {
      n || (Zt(t.$$.fragment, r), n = !0);
    },
    o(r) {
      Jt(t.$$.fragment, r), n = !1;
    },
    d(r) {
      xi(t, r);
    }
  };
}
function kr(e) {
  let t, n, r = (
    /*i18n*/
    e[1]("common.or") + ""
  ), i, s, l, a = (
    /*message*/
    (e[2] || /*i18n*/
    e[1]("upload_text.click_to_upload")) + ""
  ), o;
  return {
    c() {
      t = Dn("span"), n = Bt("- "), i = Bt(r), s = Bt(" -"), l = Un(), o = Bt(a), Mn(t, "class", "or svelte-kzcjhc");
    },
    m(u, f) {
      zt(u, t, f), Je(t, n), Je(t, i), Je(t, s), zt(u, l, f), zt(u, o, f);
    },
    p(u, f) {
      f & /*i18n*/
      2 && r !== (r = /*i18n*/
      u[1]("common.or") + "") && Rn(i, r), f & /*message, i18n*/
      6 && a !== (a = /*message*/
      (u[2] || /*i18n*/
      u[1]("upload_text.click_to_upload")) + "") && Rn(o, a);
    },
    d(u) {
      u && (Vt(t), Vt(l), Vt(o));
    }
  };
}
function Po(e) {
  let t, n, r, i, s, l = (
    /*i18n*/
    e[1](
      /*defs*/
      e[5][
        /*type*/
        e[0]
      ] || /*defs*/
      e[5].file
    ) + ""
  ), a, o, u;
  const f = [Co, ko], c = [];
  function h(d, p) {
    return (
      /*type*/
      d[0] === "clipboard" ? 0 : 1
    );
  }
  r = h(e), i = c[r] = f[r](e);
  let _ = (
    /*mode*/
    e[3] !== "short" && kr(e)
  );
  return {
    c() {
      t = Dn("div"), n = Dn("span"), i.c(), s = Un(), a = Bt(l), o = Un(), _ && _.c(), Mn(n, "class", "icon-wrap svelte-kzcjhc"), Hr(
        n,
        "hovered",
        /*hovered*/
        e[4]
      ), Mn(t, "class", "wrap svelte-kzcjhc");
    },
    m(d, p) {
      zt(d, t, p), Je(t, n), c[r].m(n, null), Je(t, s), Je(t, a), Je(t, o), _ && _.m(t, null), u = !0;
    },
    p(d, [p]) {
      let y = r;
      r = h(d), r !== y && (Ao(), Jt(c[y], 1, 1, () => {
        c[y] = null;
      }), To(), i = c[r], i || (i = c[r] = f[r](d), i.c()), Zt(i, 1), i.m(n, null)), (!u || p & /*hovered*/
      16) && Hr(
        n,
        "hovered",
        /*hovered*/
        d[4]
      ), (!u || p & /*i18n, type*/
      3) && l !== (l = /*i18n*/
      d[1](
        /*defs*/
        d[5][
          /*type*/
          d[0]
        ] || /*defs*/
        d[5].file
      ) + "") && Rn(a, l), /*mode*/
      d[3] !== "short" ? _ ? _.p(d, p) : (_ = kr(d), _.c(), _.m(t, null)) : _ && (_.d(1), _ = null);
    },
    i(d) {
      u || (Zt(i), u = !0);
    },
    o(d) {
      Jt(i), u = !1;
    },
    d(d) {
      d && Vt(t), c[r].d(), _ && _.d();
    }
  };
}
function No(e, t, n) {
  let { type: r = "file" } = t, { i18n: i } = t, { message: s = void 0 } = t, { mode: l = "full" } = t, { hovered: a = !1 } = t;
  const o = {
    image: "upload_text.drop_image",
    video: "upload_text.drop_video",
    audio: "upload_text.drop_audio",
    file: "upload_text.drop_file",
    csv: "upload_text.drop_csv",
    gallery: "upload_text.drop_gallery",
    clipboard: "upload_text.paste_clipboard"
  };
  return e.$$set = (u) => {
    "type" in u && n(0, r = u.type), "i18n" in u && n(1, i = u.i18n), "message" in u && n(2, s = u.message), "mode" in u && n(3, l = u.mode), "hovered" in u && n(4, a = u.hovered);
  }, [r, i, s, l, a, o];
}
class Io extends So {
  constructor(t) {
    super(), Bo(this, t, No, Po, Ho, {
      type: 0,
      i18n: 1,
      message: 2,
      mode: 3,
      hovered: 4
    });
  }
}
var En = new Intl.Collator(0, { numeric: 1 }).compare;
function Cr(e, t, n) {
  return e = e.split("."), t = t.split("."), En(e[0], t[0]) || En(e[1], t[1]) || (t[2] = t.slice(2).join("."), n = /[.-]/.test(e[2] = e.slice(2).join(".")), n == /[.-]/.test(t[2]) ? En(e[2], t[2]) : n ? -1 : 1);
}
function Gi(e, t, n) {
  return t.startsWith("http://") || t.startsWith("https://") ? n ? e : t : e + t;
}
function Sn(e) {
  if (e.startsWith("http")) {
    const { protocol: t, host: n } = new URL(e);
    return n.endsWith("hf.space") ? {
      ws_protocol: "wss",
      host: n,
      http_protocol: t
    } : {
      ws_protocol: t === "https:" ? "wss" : "ws",
      http_protocol: t,
      host: n
    };
  } else if (e.startsWith("file:"))
    return {
      ws_protocol: "ws",
      http_protocol: "http:",
      host: "lite.local"
      // Special fake hostname only used for this case. This matches the hostname allowed in `is_self_host()` in `js/wasm/network/host.ts`.
    };
  return {
    ws_protocol: "wss",
    http_protocol: "https:",
    host: e
  };
}
const qi = /^[^\/]*\/[^\/]*$/, Lo = /.*hf\.space\/{0,1}$/;
async function Oo(e, t) {
  const n = {};
  t && (n.Authorization = `Bearer ${t}`);
  const r = e.trim();
  if (qi.test(r))
    try {
      const i = await fetch(
        `https://huggingface.co/api/spaces/${r}/host`,
        { headers: n }
      );
      if (i.status !== 200)
        throw new Error("Space metadata could not be loaded.");
      const s = (await i.json()).host;
      return {
        space_id: e,
        ...Sn(s)
      };
    } catch (i) {
      throw new Error("Space metadata could not be loaded." + i.message);
    }
  if (Lo.test(r)) {
    const { ws_protocol: i, http_protocol: s, host: l } = Sn(r);
    return {
      space_id: l.replace(".hf.space", ""),
      ws_protocol: i,
      http_protocol: s,
      host: l
    };
  }
  return {
    space_id: !1,
    ...Sn(r)
  };
}
function Mo(e) {
  let t = {};
  return e.forEach(({ api_name: n }, r) => {
    n && (t[n] = r);
  }), t;
}
const Do = /^(?=[^]*\b[dD]iscussions{0,1}\b)(?=[^]*\b[dD]isabled\b)[^]*$/;
async function Pr(e) {
  try {
    const n = (await fetch(
      `https://huggingface.co/api/spaces/${e}/discussions`,
      {
        method: "HEAD"
      }
    )).headers.get("x-error-message");
    return !(n && Do.test(n));
  } catch {
    return !1;
  }
}
function Ce(e, t, n) {
  if (e == null)
    return null;
  if (Array.isArray(e)) {
    const r = [];
    for (const i of e)
      i == null ? r.push(null) : r.push(Ce(i, t, n));
    return r;
  }
  return e.is_stream ? n == null ? new ft({
    ...e,
    url: t + "/stream/" + e.path
  }) : new ft({
    ...e,
    url: "/proxy=" + n + "stream/" + e.path
  }) : new ft({
    ...e,
    url: Uo(e.path, t, n)
  });
}
function Ro(e) {
  try {
    const t = new URL(e);
    return t.protocol === "http:" || t.protocol === "https:";
  } catch {
    return !1;
  }
}
function Uo(e, t, n) {
  return e == null ? n ? `/proxy=${n}file=` : `${t}/file=` : Ro(e) ? e : n ? `/proxy=${n}file=${e}` : `${t}/file=${e}`;
}
async function xo(e, t, n, r = qo) {
  let i = (Array.isArray(e) ? e : [e]).map(
    (s) => s.blob
  );
  return await Promise.all(
    await r(t, i, void 0, n).then(
      async (s) => {
        if (s.error)
          throw new Error(s.error);
        return s.files ? s.files.map((l, a) => {
          const o = new ft({ ...e[a], path: l });
          return Ce(o, t, null);
        }) : [];
      }
    )
  );
}
async function Fo(e, t) {
  return e.map(
    (n, r) => new ft({
      path: n.name,
      orig_name: n.name,
      blob: n,
      size: n.size,
      mime_type: n.type,
      is_stream: t
    })
  );
}
class ft {
  constructor({
    path: t,
    url: n,
    orig_name: r,
    size: i,
    blob: s,
    is_stream: l,
    mime_type: a,
    alt_text: o
  }) {
    this.path = t, this.url = n, this.orig_name = r, this.size = i, this.blob = n ? void 0 : s, this.is_stream = l, this.mime_type = a, this.alt_text = o;
  }
}
const ji = "This application is too busy. Keep trying!", je = "Connection errored out.";
let Vi;
function Go(e, t) {
  return { post_data: n, upload_files: r, client: i, handle_blob: s };
  async function n(l, a, o) {
    const u = { "Content-Type": "application/json" };
    o && (u.Authorization = `Bearer ${o}`);
    try {
      var f = await e(l, {
        method: "POST",
        body: JSON.stringify(a),
        headers: u
      });
    } catch {
      return [{ error: je }, 500];
    }
    let c, h;
    try {
      c = await f.json(), h = f.status;
    } catch (_) {
      c = { error: `Could not parse server response: ${_}` }, h = 500;
    }
    return [c, h];
  }
  async function r(l, a, o, u) {
    const f = {};
    o && (f.Authorization = `Bearer ${o}`);
    const c = 1e3, h = [];
    for (let d = 0; d < a.length; d += c) {
      const p = a.slice(d, d + c), y = new FormData();
      p.forEach((E) => {
        y.append("files", E);
      });
      try {
        const E = u ? `${l}/upload?upload_id=${u}` : `${l}/upload`;
        var _ = await e(E, {
          method: "POST",
          body: y,
          headers: f
        });
      } catch {
        return { error: je };
      }
      const v = await _.json();
      h.push(...v);
    }
    return { files: h };
  }
  async function i(l, a = { normalise_files: !0 }) {
    return new Promise(async (o) => {
      const { status_callback: u, hf_token: f, normalise_files: c } = a, h = {
        predict: oe,
        submit: qe,
        view_api: Be,
        component_server: rt
      }, _ = c ?? !0;
      if ((typeof window > "u" || !("WebSocket" in window)) && !global.Websocket) {
        const m = await import("./wrapper-6f348d45-f837cf34.js");
        Vi = (await import("./__vite-browser-external-2447137e.js")).Blob, global.WebSocket = m.WebSocket;
      }
      const { ws_protocol: d, http_protocol: p, host: y, space_id: v } = await Oo(l, f), E = Math.random().toString(36).substring(2), g = {};
      let A = !1, T = {}, w = null;
      const j = {}, B = /* @__PURE__ */ new Set();
      let H, Z = {}, le = !1;
      f && v && (le = await Vo(v, f));
      async function Ge(m) {
        if (H = m, Z = Mo((m == null ? void 0 : m.dependencies) || []), H.auth_required)
          return {
            config: H,
            ...h
          };
        try {
          $ = await Be(H);
        } catch (N) {
          console.error(`Could not get api details: ${N.message}`);
        }
        return {
          config: H,
          ...h
        };
      }
      let $;
      async function Ae(m) {
        if (u && u(m), m.status === "running")
          try {
            H = await Or(
              e,
              `${p}//${y}`,
              f
            );
            const N = await Ge(H);
            o(N);
          } catch (N) {
            console.error(N), u && u({
              status: "error",
              message: "Could not load this space.",
              load_status: "error",
              detail: "NOT_FOUND"
            });
          }
      }
      try {
        H = await Or(
          e,
          `${p}//${y}`,
          f
        );
        const m = await Ge(H);
        o(m);
      } catch (m) {
        console.error(m), v ? Fn(
          v,
          qi.test(v) ? "space_name" : "subdomain",
          Ae
        ) : u && u({
          status: "error",
          message: "Could not load this space.",
          load_status: "error",
          detail: "NOT_FOUND"
        });
      }
      function oe(m, N, b) {
        let M = !1, S = !1, X;
        if (typeof m == "number")
          X = H.dependencies[m];
        else {
          const V = m.replace(/^\//, "");
          X = H.dependencies[Z[V]];
        }
        if (X.types.continuous)
          throw new Error(
            "Cannot call predict on this function as it may run forever. Use submit instead"
          );
        return new Promise((V, ae) => {
          const He = qe(m, N, b);
          let P;
          He.on("data", (ue) => {
            S && (He.destroy(), V(ue)), M = !0, P = ue;
          }).on("status", (ue) => {
            ue.stage === "error" && ae(ue), ue.stage === "complete" && (S = !0, M && (He.destroy(), V(P)));
          });
        });
      }
      function qe(m, N, b, M = null) {
        let S, X;
        if (typeof m == "number")
          S = m, X = $.unnamed_endpoints[S];
        else {
          const W = m.replace(/^\//, "");
          S = Z[W], X = $.named_endpoints[m.trim()];
        }
        if (typeof S != "number")
          throw new Error(
            "There is no endpoint matching that name of fn_index matching that number."
          );
        let V, ae, He = H.protocol ?? "ws";
        const P = typeof m == "number" ? "/predict" : m;
        let ue, pe = null, re = !1;
        const St = {};
        let Oe = "";
        typeof window < "u" && (Oe = new URLSearchParams(window.location.search).toString()), s(`${H.root}`, N, X, f).then(
          (W) => {
            if (ue = {
              data: W || [],
              event_data: b,
              fn_index: S,
              trigger_id: M
            }, zo(S, H))
              D({
                type: "status",
                endpoint: P,
                stage: "pending",
                queue: !1,
                fn_index: S,
                time: /* @__PURE__ */ new Date()
              }), n(
                `${H.root}/run${P.startsWith("/") ? P : `/${P}`}${Oe ? "?" + Oe : ""}`,
                {
                  ...ue,
                  session_hash: E
                },
                f
              ).then(([G, z]) => {
                const ge = _ ? Ft(
                  G.data,
                  X,
                  H.root,
                  H.root_url
                ) : G.data;
                z == 200 ? (D({
                  type: "data",
                  endpoint: P,
                  fn_index: S,
                  data: ge,
                  time: /* @__PURE__ */ new Date()
                }), D({
                  type: "status",
                  endpoint: P,
                  fn_index: S,
                  stage: "complete",
                  eta: G.average_duration,
                  queue: !1,
                  time: /* @__PURE__ */ new Date()
                })) : D({
                  type: "status",
                  stage: "error",
                  endpoint: P,
                  fn_index: S,
                  message: G.error,
                  queue: !1,
                  time: /* @__PURE__ */ new Date()
                });
              }).catch((G) => {
                D({
                  type: "status",
                  stage: "error",
                  message: G.message,
                  endpoint: P,
                  fn_index: S,
                  queue: !1,
                  time: /* @__PURE__ */ new Date()
                });
              });
            else if (He == "ws") {
              D({
                type: "status",
                stage: "pending",
                queue: !0,
                endpoint: P,
                fn_index: S,
                time: /* @__PURE__ */ new Date()
              });
              let G = new URL(`${d}://${Gi(
                y,
                H.path,
                !0
              )}
							/queue/join${Oe ? "?" + Oe : ""}`);
              le && G.searchParams.set("__sign", le), V = new WebSocket(G), V.onclose = (z) => {
                z.wasClean || D({
                  type: "status",
                  stage: "error",
                  broken: !0,
                  message: je,
                  queue: !0,
                  endpoint: P,
                  fn_index: S,
                  time: /* @__PURE__ */ new Date()
                });
              }, V.onmessage = function(z) {
                const ge = JSON.parse(z.data), { type: J, status: U, data: x } = Tn(
                  ge,
                  g[S]
                );
                if (J === "update" && U && !re)
                  D({
                    type: "status",
                    endpoint: P,
                    fn_index: S,
                    time: /* @__PURE__ */ new Date(),
                    ...U
                  }), U.stage === "error" && V.close();
                else if (J === "hash") {
                  V.send(JSON.stringify({ fn_index: S, session_hash: E }));
                  return;
                } else
                  J === "data" ? V.send(JSON.stringify({ ...ue, session_hash: E })) : J === "complete" ? re = U : J === "log" ? D({
                    type: "log",
                    log: x.log,
                    level: x.level,
                    endpoint: P,
                    fn_index: S
                  }) : J === "generating" && D({
                    type: "status",
                    time: /* @__PURE__ */ new Date(),
                    ...U,
                    stage: U == null ? void 0 : U.stage,
                    queue: !0,
                    endpoint: P,
                    fn_index: S
                  });
                x && (D({
                  type: "data",
                  time: /* @__PURE__ */ new Date(),
                  data: _ ? Ft(
                    x.data,
                    X,
                    H.root,
                    H.root_url
                  ) : x.data,
                  endpoint: P,
                  fn_index: S
                }), re && (D({
                  type: "status",
                  time: /* @__PURE__ */ new Date(),
                  ...re,
                  stage: U == null ? void 0 : U.stage,
                  queue: !0,
                  endpoint: P,
                  fn_index: S
                }), V.close()));
              }, Cr(H.version || "2.0.0", "3.6") < 0 && addEventListener(
                "open",
                () => V.send(JSON.stringify({ hash: E }))
              );
            } else if (He == "sse") {
              D({
                type: "status",
                stage: "pending",
                queue: !0,
                endpoint: P,
                fn_index: S,
                time: /* @__PURE__ */ new Date()
              });
              var fe = new URLSearchParams({
                fn_index: S.toString(),
                session_hash: E
              }).toString();
              let G = new URL(
                `${H.root}/queue/join?${Oe ? Oe + "&" : ""}${fe}`
              );
              ae = t(G), ae.onmessage = async function(z) {
                const ge = JSON.parse(z.data), { type: J, status: U, data: x } = Tn(
                  ge,
                  g[S]
                );
                if (J === "update" && U && !re)
                  D({
                    type: "status",
                    endpoint: P,
                    fn_index: S,
                    time: /* @__PURE__ */ new Date(),
                    ...U
                  }), U.stage === "error" && ae.close();
                else if (J === "data") {
                  pe = ge.event_id;
                  let [it, Rs] = await n(
                    `${H.root}/queue/data`,
                    {
                      ...ue,
                      session_hash: E,
                      event_id: pe
                    },
                    f
                  );
                  Rs !== 200 && (D({
                    type: "status",
                    stage: "error",
                    message: je,
                    queue: !0,
                    endpoint: P,
                    fn_index: S,
                    time: /* @__PURE__ */ new Date()
                  }), ae.close());
                } else
                  J === "complete" ? re = U : J === "log" ? D({
                    type: "log",
                    log: x.log,
                    level: x.level,
                    endpoint: P,
                    fn_index: S
                  }) : J === "generating" && D({
                    type: "status",
                    time: /* @__PURE__ */ new Date(),
                    ...U,
                    stage: U == null ? void 0 : U.stage,
                    queue: !0,
                    endpoint: P,
                    fn_index: S
                  });
                x && (D({
                  type: "data",
                  time: /* @__PURE__ */ new Date(),
                  data: _ ? Ft(
                    x.data,
                    X,
                    H.root,
                    H.root_url
                  ) : x.data,
                  endpoint: P,
                  fn_index: S
                }), re && (D({
                  type: "status",
                  time: /* @__PURE__ */ new Date(),
                  ...re,
                  stage: U == null ? void 0 : U.stage,
                  queue: !0,
                  endpoint: P,
                  fn_index: S
                }), ae.close()));
              };
            } else
              He == "sse_v1" && (D({
                type: "status",
                stage: "pending",
                queue: !0,
                endpoint: P,
                fn_index: S,
                time: /* @__PURE__ */ new Date()
              }), n(
                `${H.root}/queue/join?${Oe}`,
                {
                  ...ue,
                  session_hash: E
                },
                f
              ).then(([G, z]) => {
                if (z === 503)
                  D({
                    type: "status",
                    stage: "error",
                    message: ji,
                    queue: !0,
                    endpoint: P,
                    fn_index: S,
                    time: /* @__PURE__ */ new Date()
                  });
                else if (z !== 200)
                  D({
                    type: "status",
                    stage: "error",
                    message: je,
                    queue: !0,
                    endpoint: P,
                    fn_index: S,
                    time: /* @__PURE__ */ new Date()
                  });
                else {
                  pe = G.event_id;
                  let ge = async function(J) {
                    try {
                      const { type: U, status: x, data: it } = Tn(
                        J,
                        g[S]
                      );
                      if (U == "heartbeat")
                        return;
                      if (U === "update" && x && !re)
                        D({
                          type: "status",
                          endpoint: P,
                          fn_index: S,
                          time: /* @__PURE__ */ new Date(),
                          ...x
                        });
                      else if (U === "complete")
                        re = x;
                      else if (U == "unexpected_error")
                        console.error("Unexpected error", x == null ? void 0 : x.message), D({
                          type: "status",
                          stage: "error",
                          message: (x == null ? void 0 : x.message) || "An Unexpected Error Occurred!",
                          queue: !0,
                          endpoint: P,
                          fn_index: S,
                          time: /* @__PURE__ */ new Date()
                        });
                      else if (U === "log") {
                        D({
                          type: "log",
                          log: it.log,
                          level: it.level,
                          endpoint: P,
                          fn_index: S
                        });
                        return;
                      } else
                        U === "generating" && D({
                          type: "status",
                          time: /* @__PURE__ */ new Date(),
                          ...x,
                          stage: x == null ? void 0 : x.stage,
                          queue: !0,
                          endpoint: P,
                          fn_index: S
                        });
                      it && (D({
                        type: "data",
                        time: /* @__PURE__ */ new Date(),
                        data: _ ? Ft(
                          it.data,
                          X,
                          H.root,
                          H.root_url
                        ) : it.data,
                        endpoint: P,
                        fn_index: S
                      }), re && D({
                        type: "status",
                        time: /* @__PURE__ */ new Date(),
                        ...re,
                        stage: x == null ? void 0 : x.stage,
                        queue: !0,
                        endpoint: P,
                        fn_index: S
                      })), ((x == null ? void 0 : x.stage) === "complete" || (x == null ? void 0 : x.stage) === "error") && j[pe] && delete j[pe];
                    } catch (U) {
                      console.error("Unexpected client exception", U), D({
                        type: "status",
                        stage: "error",
                        message: "An Unexpected Error Occurred!",
                        queue: !0,
                        endpoint: P,
                        fn_index: S,
                        time: /* @__PURE__ */ new Date()
                      }), Le();
                    }
                  };
                  pe in T && (T[pe].forEach(
                    (J) => ge(J)
                  ), delete T[pe]), j[pe] = ge, B.add(pe), A || Et();
                }
              }));
          }
        );
        function D(W) {
          const G = St[W.type] || [];
          G == null || G.forEach((z) => z(W));
        }
        function fn(W, fe) {
          const G = St, z = G[W] || [];
          return G[W] = z, z == null || z.push(fe), { on: fn, off: Mt, cancel: cn, destroy: hn };
        }
        function Mt(W, fe) {
          const G = St;
          let z = G[W] || [];
          return z = z == null ? void 0 : z.filter((ge) => ge !== fe), G[W] = z, { on: fn, off: Mt, cancel: cn, destroy: hn };
        }
        async function cn() {
          const W = {
            stage: "complete",
            queue: !1,
            time: /* @__PURE__ */ new Date()
          };
          re = W, D({
            ...W,
            type: "status",
            endpoint: P,
            fn_index: S
          });
          let fe = {};
          He === "ws" ? (V && V.readyState === 0 ? V.addEventListener("open", () => {
            V.close();
          }) : V.close(), fe = { fn_index: S, session_hash: E }) : (ae.close(), fe = { event_id: pe });
          try {
            await e(`${H.root}/reset`, {
              headers: { "Content-Type": "application/json" },
              method: "POST",
              body: JSON.stringify(fe)
            });
          } catch {
            console.warn(
              "The `/reset` endpoint could not be called. Subsequent endpoint results may be unreliable."
            );
          }
        }
        function hn() {
          for (const W in St)
            St[W].forEach((fe) => {
              Mt(W, fe);
            });
        }
        return {
          on: fn,
          off: Mt,
          cancel: cn,
          destroy: hn
        };
      }
      function Et() {
        A = !0;
        let m = new URLSearchParams({
          session_hash: E
        }).toString(), N = new URL(`${H.root}/queue/data?${m}`);
        w = t(N), w.onmessage = async function(b) {
          let M = JSON.parse(b.data);
          const S = M.event_id;
          if (!S)
            await Promise.all(
              Object.keys(j).map(
                (X) => j[X](M)
              )
            );
          else if (j[S]) {
            M.msg === "process_completed" && (B.delete(S), B.size === 0 && Le());
            let X = j[S];
            window.setTimeout(X, 0, M);
          } else
            T[S] || (T[S] = []), T[S].push(M);
        }, w.onerror = async function(b) {
          await Promise.all(
            Object.keys(j).map(
              (M) => j[M]({
                msg: "unexpected_error",
                message: je
              })
            )
          ), Le();
        };
      }
      function Le() {
        A = !1, w == null || w.close();
      }
      async function rt(m, N, b) {
        var M;
        const S = { "Content-Type": "application/json" };
        f && (S.Authorization = `Bearer ${f}`);
        let X, V = H.components.find(
          (P) => P.id === m
        );
        (M = V == null ? void 0 : V.props) != null && M.root_url ? X = V.props.root_url : X = H.root;
        const ae = await e(
          `${X}/component_server/`,
          {
            method: "POST",
            body: JSON.stringify({
              data: b,
              component_id: m,
              fn_name: N,
              session_hash: E
            }),
            headers: S
          }
        );
        if (!ae.ok)
          throw new Error(
            "Could not connect to component server: " + ae.statusText
          );
        return await ae.json();
      }
      async function Be(m) {
        if ($)
          return $;
        const N = { "Content-Type": "application/json" };
        f && (N.Authorization = `Bearer ${f}`);
        let b;
        if (Cr(m.version || "2.0.0", "3.30") < 0 ? b = await e(
          "https://gradio-space-api-fetcher-v2.hf.space/api",
          {
            method: "POST",
            body: JSON.stringify({
              serialize: !1,
              config: JSON.stringify(m)
            }),
            headers: N
          }
        ) : b = await e(`${m.root}/info`, {
          headers: N
        }), !b.ok)
          throw new Error(je);
        let M = await b.json();
        return "api" in M && (M = M.api), M.named_endpoints["/predict"] && !M.unnamed_endpoints[0] && (M.unnamed_endpoints[0] = M.named_endpoints["/predict"]), jo(M, m, Z);
      }
    });
  }
  async function s(l, a, o, u) {
    const f = await xn(
      a,
      void 0,
      [],
      !0,
      o
    );
    return Promise.all(
      f.map(async ({ path: c, blob: h, type: _ }) => {
        if (h) {
          const d = (await r(l, [h], u)).files[0];
          return { path: c, file_url: d, type: _, name: h == null ? void 0 : h.name };
        }
        return { path: c, type: _ };
      })
    ).then((c) => (c.forEach(({ path: h, file_url: _, type: d, name: p }) => {
      if (d === "Gallery")
        Lr(a, _, h);
      else if (_) {
        const y = new ft({ path: _, orig_name: p });
        Lr(a, y, h);
      }
    }), a));
  }
}
const { post_data: m0, upload_files: qo, client: p0, handle_blob: g0 } = Go(
  fetch,
  (...e) => new EventSource(...e)
);
function Ft(e, t, n, r) {
  return e.map((i, s) => {
    var l, a, o, u;
    return ((a = (l = t == null ? void 0 : t.returns) == null ? void 0 : l[s]) == null ? void 0 : a.component) === "File" ? Ce(i, n, r) : ((u = (o = t == null ? void 0 : t.returns) == null ? void 0 : o[s]) == null ? void 0 : u.component) === "Gallery" ? i.map((f) => Array.isArray(f) ? [Ce(f[0], n, r), f[1]] : [Ce(f, n, r), null]) : typeof i == "object" && i.path ? Ce(i, n, r) : i;
  });
}
function Nr(e, t, n, r) {
  switch (e.type) {
    case "string":
      return "string";
    case "boolean":
      return "boolean";
    case "number":
      return "number";
  }
  if (n === "JSONSerializable" || n === "StringSerializable")
    return "any";
  if (n === "ListStringSerializable")
    return "string[]";
  if (t === "Image")
    return r === "parameter" ? "Blob | File | Buffer" : "string";
  if (n === "FileSerializable")
    return (e == null ? void 0 : e.type) === "array" ? r === "parameter" ? "(Blob | File | Buffer)[]" : "{ name: string; data: string; size?: number; is_file?: boolean; orig_name?: string}[]" : r === "parameter" ? "Blob | File | Buffer" : "{ name: string; data: string; size?: number; is_file?: boolean; orig_name?: string}";
  if (n === "GallerySerializable")
    return r === "parameter" ? "[(Blob | File | Buffer), (string | null)][]" : "[{ name: string; data: string; size?: number; is_file?: boolean; orig_name?: string}, (string | null))][]";
}
function Ir(e, t) {
  return t === "GallerySerializable" ? "array of [file, label] tuples" : t === "ListStringSerializable" ? "array of strings" : t === "FileSerializable" ? "array of files or single file" : e.description;
}
function jo(e, t, n) {
  const r = {
    named_endpoints: {},
    unnamed_endpoints: {}
  };
  for (const i in e) {
    const s = e[i];
    for (const l in s) {
      const a = t.dependencies[l] ? l : n[l.replace("/", "")], o = s[l];
      r[i][l] = {}, r[i][l].parameters = {}, r[i][l].returns = {}, r[i][l].type = t.dependencies[a].types, r[i][l].parameters = o.parameters.map(
        ({ label: u, component: f, type: c, serializer: h }) => ({
          label: u,
          component: f,
          type: Nr(c, f, h, "parameter"),
          description: Ir(c, h)
        })
      ), r[i][l].returns = o.returns.map(
        ({ label: u, component: f, type: c, serializer: h }) => ({
          label: u,
          component: f,
          type: Nr(c, f, h, "return"),
          description: Ir(c, h)
        })
      );
    }
  }
  return r;
}
async function Vo(e, t) {
  try {
    return (await (await fetch(`https://huggingface.co/api/spaces/${e}/jwt`, {
      headers: {
        Authorization: `Bearer ${t}`
      }
    })).json()).token || !1;
  } catch (n) {
    return console.error(n), !1;
  }
}
function Lr(e, t, n) {
  for (; n.length > 1; )
    e = e[n.shift()];
  e[n.shift()] = t;
}
async function xn(e, t = void 0, n = [], r = !1, i = void 0) {
  if (Array.isArray(e)) {
    let s = [];
    return await Promise.all(
      e.map(async (l, a) => {
        var o;
        let u = n.slice();
        u.push(a);
        const f = await xn(
          e[a],
          r ? ((o = i == null ? void 0 : i.parameters[a]) == null ? void 0 : o.component) || void 0 : t,
          u,
          !1,
          i
        );
        s = s.concat(f);
      })
    ), s;
  } else {
    if (globalThis.Buffer && e instanceof globalThis.Buffer)
      return [
        {
          path: n,
          blob: t === "Image" ? !1 : new Vi([e]),
          type: t
        }
      ];
    if (typeof e == "object") {
      let s = [];
      for (let l in e)
        if (e.hasOwnProperty(l)) {
          let a = n.slice();
          a.push(l), s = s.concat(
            await xn(
              e[l],
              void 0,
              a,
              !1,
              i
            )
          );
        }
      return s;
    }
  }
  return [];
}
function zo(e, t) {
  var n, r, i, s;
  return !(((r = (n = t == null ? void 0 : t.dependencies) == null ? void 0 : n[e]) == null ? void 0 : r.queue) === null ? t.enable_queue : (s = (i = t == null ? void 0 : t.dependencies) == null ? void 0 : i[e]) != null && s.queue) || !1;
}
async function Or(e, t, n) {
  const r = {};
  if (n && (r.Authorization = `Bearer ${n}`), typeof window < "u" && window.gradio_config && location.origin !== "http://localhost:9876" && !window.gradio_config.dev_mode) {
    const i = window.gradio_config.root, s = window.gradio_config;
    return s.root = Gi(t, s.root, !1), { ...s, path: i };
  } else if (t) {
    let i = await e(`${t}/config`, {
      headers: r
    });
    if (i.status === 200) {
      const s = await i.json();
      return s.path = s.path ?? "", s.root = t, s;
    }
    throw new Error("Could not get config.");
  }
  throw new Error("No config or app endpoint found");
}
async function Fn(e, t, n) {
  let r = t === "subdomain" ? `https://huggingface.co/api/spaces/by-subdomain/${e}` : `https://huggingface.co/api/spaces/${e}`, i, s;
  try {
    if (i = await fetch(r), s = i.status, s !== 200)
      throw new Error();
    i = await i.json();
  } catch {
    n({
      status: "error",
      load_status: "error",
      message: "Could not get space status",
      detail: "NOT_FOUND"
    });
    return;
  }
  if (!i || s !== 200)
    return;
  const {
    runtime: { stage: l },
    id: a
  } = i;
  switch (l) {
    case "STOPPED":
    case "SLEEPING":
      n({
        status: "sleeping",
        load_status: "pending",
        message: "Space is asleep. Waking it up...",
        detail: l
      }), setTimeout(() => {
        Fn(e, t, n);
      }, 1e3);
      break;
    case "PAUSED":
      n({
        status: "paused",
        load_status: "error",
        message: "This space has been paused by the author. If you would like to try this demo, consider duplicating the space.",
        detail: l,
        discussions_enabled: await Pr(a)
      });
      break;
    case "RUNNING":
    case "RUNNING_BUILDING":
      n({
        status: "running",
        load_status: "complete",
        message: "",
        detail: l
      });
      break;
    case "BUILDING":
      n({
        status: "building",
        load_status: "pending",
        message: "Space is building...",
        detail: l
      }), setTimeout(() => {
        Fn(e, t, n);
      }, 1e3);
      break;
    default:
      n({
        status: "space_error",
        load_status: "error",
        message: "This space is experiencing an issue.",
        detail: l,
        discussions_enabled: await Pr(a)
      });
      break;
  }
}
function Tn(e, t) {
  switch (e.msg) {
    case "send_data":
      return { type: "data" };
    case "send_hash":
      return { type: "hash" };
    case "queue_full":
      return {
        type: "update",
        status: {
          queue: !0,
          message: ji,
          stage: "error",
          code: e.code,
          success: e.success
        }
      };
    case "heartbeat":
      return {
        type: "heartbeat"
      };
    case "unexpected_error":
      return {
        type: "unexpected_error",
        status: {
          queue: !0,
          message: e.message,
          stage: "error",
          success: !1
        }
      };
    case "estimation":
      return {
        type: "update",
        status: {
          queue: !0,
          stage: t || "pending",
          code: e.code,
          size: e.queue_size,
          position: e.rank,
          eta: e.rank_eta,
          success: e.success
        }
      };
    case "progress":
      return {
        type: "update",
        status: {
          queue: !0,
          stage: "pending",
          code: e.code,
          progress_data: e.progress_data,
          success: e.success
        }
      };
    case "log":
      return { type: "log", data: e };
    case "process_generating":
      return {
        type: "generating",
        status: {
          queue: !0,
          message: e.success ? null : e.output.error,
          stage: e.success ? "generating" : "error",
          code: e.code,
          progress_data: e.progress_data,
          eta: e.average_duration
        },
        data: e.success ? e.output : null
      };
    case "process_completed":
      return "error" in e.output ? {
        type: "update",
        status: {
          queue: !0,
          message: e.output.error,
          stage: "error",
          code: e.code,
          success: e.success
        }
      } : {
        type: "complete",
        status: {
          queue: !0,
          message: e.success ? void 0 : e.output.error,
          stage: e.success ? "complete" : "error",
          code: e.code,
          progress_data: e.progress_data
        },
        data: e.success ? e.output : null
      };
    case "process_starts":
      return {
        type: "update",
        status: {
          queue: !0,
          stage: "pending",
          code: e.code,
          size: e.rank,
          position: 0,
          success: e.success,
          eta: e.eta
        }
      };
  }
  return { type: "none", status: { stage: "error", queue: !0 } };
}
const {
  SvelteComponent: Xo,
  attr: Mr,
  check_outros: Wo,
  create_component: ar,
  destroy_component: ur,
  detach: Gn,
  element: Zo,
  empty: Jo,
  group_outros: Qo,
  init: Yo,
  insert: qn,
  mount_component: fr,
  noop: Dr,
  safe_not_equal: Ko,
  space: $o,
  transition_in: kt,
  transition_out: Ct
} = window.__gradio__svelte__internal;
function ea(e) {
  let t;
  return {
    c() {
      t = Zo("div"), Mr(t, "id", "fasta_content"), Mr(t, "class", "svelte-1r6bt2i");
    },
    m(n, r) {
      qn(n, t, r), t.innerHTML = /*fasta_text*/
      e[4];
    },
    p(n, r) {
      r & /*fasta_text*/
      16 && (t.innerHTML = /*fasta_text*/
      n[4]);
    },
    i: Dr,
    o: Dr,
    d(n) {
      n && Gn(t);
    }
  };
}
function ta(e) {
  let t, n;
  return t = new Xl({
    props: {
      unpadded_box: !0,
      size: "large",
      $$slots: { default: [na] },
      $$scope: { ctx: e }
    }
  }), {
    c() {
      ar(t.$$.fragment);
    },
    m(r, i) {
      fr(t, r, i), n = !0;
    },
    p(r, i) {
      const s = {};
      i & /*$$scope*/
      256 && (s.$$scope = { dirty: i, ctx: r }), t.$set(s);
    },
    i(r) {
      n || (kt(t.$$.fragment, r), n = !0);
    },
    o(r) {
      Ct(t.$$.fragment, r), n = !1;
    },
    d(r) {
      ur(t, r);
    }
  };
}
function na(e) {
  let t, n;
  return t = new or({}), {
    c() {
      ar(t.$$.fragment);
    },
    m(r, i) {
      fr(t, r, i), n = !0;
    },
    i(r) {
      n || (kt(t.$$.fragment, r), n = !0);
    },
    o(r) {
      Ct(t.$$.fragment, r), n = !1;
    },
    d(r) {
      ur(t, r);
    }
  };
}
function ra(e) {
  let t, n, r, i, s, l;
  t = new Mi({
    props: {
      show_label: (
        /*show_label*/
        e[2]
      ),
      Icon: or,
      label: (
        /*label*/
        e[1] || /*i18n*/
        e[3]("image.image")
      )
    }
  });
  const a = [ta, ea], o = [];
  function u(f, c) {
    return (
      /*value*/
      f[0] === null || !/*value*/
      f[0].url ? 0 : 1
    );
  }
  return r = u(e), i = o[r] = a[r](e), {
    c() {
      ar(t.$$.fragment), n = $o(), i.c(), s = Jo();
    },
    m(f, c) {
      fr(t, f, c), qn(f, n, c), o[r].m(f, c), qn(f, s, c), l = !0;
    },
    p(f, [c]) {
      const h = {};
      c & /*show_label*/
      4 && (h.show_label = /*show_label*/
      f[2]), c & /*label, i18n*/
      10 && (h.label = /*label*/
      f[1] || /*i18n*/
      f[3]("image.image")), t.$set(h);
      let _ = r;
      r = u(f), r === _ ? o[r].p(f, c) : (Qo(), Ct(o[_], 1, 1, () => {
        o[_] = null;
      }), Wo(), i = o[r], i ? i.p(f, c) : (i = o[r] = a[r](f), i.c()), kt(i, 1), i.m(s.parentNode, s));
    },
    i(f) {
      l || (kt(t.$$.fragment, f), kt(i), l = !0);
    },
    o(f) {
      Ct(t.$$.fragment, f), Ct(i), l = !1;
    },
    d(f) {
      f && (Gn(n), Gn(s)), ur(t, f), o[r].d(f);
    }
  };
}
function ia(e, t, n) {
  let { value: r } = t, { label: i = void 0 } = t, { show_label: s } = t, { show_download_button: l = !0 } = t, { selectable: a = !1 } = t, { i18n: o } = t, u = "";
  async function f(c) {
    const h = await fetch(c);
    n(4, u = await h.text()), n(4, u = u.replaceAll("G", "<span style='color: green'>G</span>")), n(4, u = u.replaceAll("A", "<span style='color: red'>A</span>")), n(4, u = u.replaceAll("T", "<span style='color: blue'>T</span>")), n(4, u = u.replaceAll("C", "<span style='color: orange'>C</span>")), n(4, u = u.replaceAll(/^(>.*)$/gm, "<span style='color: gray !important'>$1</span>"));
  }
  return e.$$set = (c) => {
    "value" in c && n(0, r = c.value), "label" in c && n(1, i = c.label), "show_label" in c && n(2, s = c.show_label), "show_download_button" in c && n(5, l = c.show_download_button), "selectable" in c && n(6, a = c.selectable), "i18n" in c && n(3, o = c.i18n);
  }, e.$$.update = () => {
    e.$$.dirty & /*value*/
    1 && r && r.url && f(r.url);
  }, [r, i, s, o, u, l, a];
}
class sa extends Xo {
  constructor(t) {
    super(), Yo(this, t, ia, ra, Ko, {
      value: 0,
      label: 1,
      show_label: 2,
      show_download_button: 5,
      selectable: 6,
      i18n: 3
    });
  }
}
function Ye() {
}
function la(e) {
  return e();
}
function oa(e) {
  e.forEach(la);
}
function aa(e) {
  return typeof e == "function";
}
function ua(e, t) {
  return e != e ? t == t : e !== t || e && typeof e == "object" || typeof e == "function";
}
function fa(e, ...t) {
  if (e == null) {
    for (const r of t)
      r(void 0);
    return Ye;
  }
  const n = e.subscribe(...t);
  return n.unsubscribe ? () => n.unsubscribe() : n;
}
const zi = typeof window < "u";
let Rr = zi ? () => window.performance.now() : () => Date.now(), Xi = zi ? (e) => requestAnimationFrame(e) : Ye;
const ct = /* @__PURE__ */ new Set();
function Wi(e) {
  ct.forEach((t) => {
    t.c(e) || (ct.delete(t), t.f());
  }), ct.size !== 0 && Xi(Wi);
}
function ca(e) {
  let t;
  return ct.size === 0 && Xi(Wi), {
    promise: new Promise((n) => {
      ct.add(t = { c: e, f: n });
    }),
    abort() {
      ct.delete(t);
    }
  };
}
const lt = [];
function ha(e, t) {
  return {
    subscribe: It(e, t).subscribe
  };
}
function It(e, t = Ye) {
  let n;
  const r = /* @__PURE__ */ new Set();
  function i(a) {
    if (ua(e, a) && (e = a, n)) {
      const o = !lt.length;
      for (const u of r)
        u[1](), lt.push(u, e);
      if (o) {
        for (let u = 0; u < lt.length; u += 2)
          lt[u][0](lt[u + 1]);
        lt.length = 0;
      }
    }
  }
  function s(a) {
    i(a(e));
  }
  function l(a, o = Ye) {
    const u = [a, o];
    return r.add(u), r.size === 1 && (n = t(i, s) || Ye), a(e), () => {
      r.delete(u), r.size === 0 && n && (n(), n = null);
    };
  }
  return { set: i, update: s, subscribe: l };
}
function vt(e, t, n) {
  const r = !Array.isArray(e), i = r ? [e] : e;
  if (!i.every(Boolean))
    throw new Error("derived() expects stores as input, got a falsy value");
  const s = t.length < 2;
  return ha(n, (l, a) => {
    let o = !1;
    const u = [];
    let f = 0, c = Ye;
    const h = () => {
      if (f)
        return;
      c();
      const d = t(r ? u[0] : u, l, a);
      s ? l(d) : c = aa(d) ? d : Ye;
    }, _ = i.map(
      (d, p) => fa(
        d,
        (y) => {
          u[p] = y, f &= ~(1 << p), o && h();
        },
        () => {
          f |= 1 << p;
        }
      )
    );
    return o = !0, h(), function() {
      oa(_), c(), o = !1;
    };
  });
}
function Ur(e) {
  return Object.prototype.toString.call(e) === "[object Date]";
}
function jn(e, t, n, r) {
  if (typeof n == "number" || Ur(n)) {
    const i = r - n, s = (n - t) / (e.dt || 1 / 60), l = e.opts.stiffness * i, a = e.opts.damping * s, o = (l - a) * e.inv_mass, u = (s + o) * e.dt;
    return Math.abs(u) < e.opts.precision && Math.abs(i) < e.opts.precision ? r : (e.settled = !1, Ur(n) ? new Date(n.getTime() + u) : n + u);
  } else {
    if (Array.isArray(n))
      return n.map(
        (i, s) => jn(e, t[s], n[s], r[s])
      );
    if (typeof n == "object") {
      const i = {};
      for (const s in n)
        i[s] = jn(e, t[s], n[s], r[s]);
      return i;
    } else
      throw new Error(`Cannot spring ${typeof n} values`);
  }
}
function xr(e, t = {}) {
  const n = It(e), { stiffness: r = 0.15, damping: i = 0.8, precision: s = 0.01 } = t;
  let l, a, o, u = e, f = e, c = 1, h = 0, _ = !1;
  function d(y, v = {}) {
    f = y;
    const E = o = {};
    return e == null || v.hard || p.stiffness >= 1 && p.damping >= 1 ? (_ = !0, l = Rr(), u = y, n.set(e = f), Promise.resolve()) : (v.soft && (h = 1 / ((v.soft === !0 ? 0.5 : +v.soft) * 60), c = 0), a || (l = Rr(), _ = !1, a = ca((g) => {
      if (_)
        return _ = !1, a = null, !1;
      c = Math.min(c + h, 1);
      const A = {
        inv_mass: c,
        opts: p,
        settled: !0,
        dt: (g - l) * 60 / 1e3
      }, T = jn(A, u, e, f);
      return l = g, u = e, n.set(e = T), A.settled && (a = null), !A.settled;
    })), new Promise((g) => {
      a.promise.then(() => {
        E === o && g();
      });
    }));
  }
  const p = {
    set: d,
    update: (y, v) => d(y(f, e), v),
    subscribe: n.subscribe,
    stiffness: r,
    damping: i,
    precision: s
  };
  return p;
}
function _a(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var da = function(t) {
  return ma(t) && !pa(t);
};
function ma(e) {
  return !!e && typeof e == "object";
}
function pa(e) {
  var t = Object.prototype.toString.call(e);
  return t === "[object RegExp]" || t === "[object Date]" || va(e);
}
var ga = typeof Symbol == "function" && Symbol.for, ba = ga ? Symbol.for("react.element") : 60103;
function va(e) {
  return e.$$typeof === ba;
}
function ya(e) {
  return Array.isArray(e) ? [] : {};
}
function Pt(e, t) {
  return t.clone !== !1 && t.isMergeableObject(e) ? _t(ya(e), e, t) : e;
}
function wa(e, t, n) {
  return e.concat(t).map(function(r) {
    return Pt(r, n);
  });
}
function Ea(e, t) {
  if (!t.customMerge)
    return _t;
  var n = t.customMerge(e);
  return typeof n == "function" ? n : _t;
}
function Sa(e) {
  return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(e).filter(function(t) {
    return Object.propertyIsEnumerable.call(e, t);
  }) : [];
}
function Fr(e) {
  return Object.keys(e).concat(Sa(e));
}
function Zi(e, t) {
  try {
    return t in e;
  } catch {
    return !1;
  }
}
function Ta(e, t) {
  return Zi(e, t) && !(Object.hasOwnProperty.call(e, t) && Object.propertyIsEnumerable.call(e, t));
}
function Aa(e, t, n) {
  var r = {};
  return n.isMergeableObject(e) && Fr(e).forEach(function(i) {
    r[i] = Pt(e[i], n);
  }), Fr(t).forEach(function(i) {
    Ta(e, i) || (Zi(e, i) && n.isMergeableObject(t[i]) ? r[i] = Ea(i, n)(e[i], t[i], n) : r[i] = Pt(t[i], n));
  }), r;
}
function _t(e, t, n) {
  n = n || {}, n.arrayMerge = n.arrayMerge || wa, n.isMergeableObject = n.isMergeableObject || da, n.cloneUnlessOtherwiseSpecified = Pt;
  var r = Array.isArray(t), i = Array.isArray(e), s = r === i;
  return s ? r ? n.arrayMerge(e, t, n) : Aa(e, t, n) : Pt(t, n);
}
_t.all = function(t, n) {
  if (!Array.isArray(t))
    throw new Error("first argument should be an array");
  return t.reduce(function(r, i) {
    return _t(r, i, n);
  }, {});
};
var Ba = _t, Ha = Ba;
const ka = /* @__PURE__ */ _a(Ha);
var Vn = function(e, t) {
  return Vn = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(n, r) {
    n.__proto__ = r;
  } || function(n, r) {
    for (var i in r)
      Object.prototype.hasOwnProperty.call(r, i) && (n[i] = r[i]);
  }, Vn(e, t);
};
function rn(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
  Vn(e, t);
  function n() {
    this.constructor = e;
  }
  e.prototype = t === null ? Object.create(t) : (n.prototype = t.prototype, new n());
}
var R = function() {
  return R = Object.assign || function(t) {
    for (var n, r = 1, i = arguments.length; r < i; r++) {
      n = arguments[r];
      for (var s in n)
        Object.prototype.hasOwnProperty.call(n, s) && (t[s] = n[s]);
    }
    return t;
  }, R.apply(this, arguments);
};
function An(e, t, n) {
  if (n || arguments.length === 2)
    for (var r = 0, i = t.length, s; r < i; r++)
      (s || !(r in t)) && (s || (s = Array.prototype.slice.call(t, 0, r)), s[r] = t[r]);
  return e.concat(s || Array.prototype.slice.call(t));
}
var I;
(function(e) {
  e[e.EXPECT_ARGUMENT_CLOSING_BRACE = 1] = "EXPECT_ARGUMENT_CLOSING_BRACE", e[e.EMPTY_ARGUMENT = 2] = "EMPTY_ARGUMENT", e[e.MALFORMED_ARGUMENT = 3] = "MALFORMED_ARGUMENT", e[e.EXPECT_ARGUMENT_TYPE = 4] = "EXPECT_ARGUMENT_TYPE", e[e.INVALID_ARGUMENT_TYPE = 5] = "INVALID_ARGUMENT_TYPE", e[e.EXPECT_ARGUMENT_STYLE = 6] = "EXPECT_ARGUMENT_STYLE", e[e.INVALID_NUMBER_SKELETON = 7] = "INVALID_NUMBER_SKELETON", e[e.INVALID_DATE_TIME_SKELETON = 8] = "INVALID_DATE_TIME_SKELETON", e[e.EXPECT_NUMBER_SKELETON = 9] = "EXPECT_NUMBER_SKELETON", e[e.EXPECT_DATE_TIME_SKELETON = 10] = "EXPECT_DATE_TIME_SKELETON", e[e.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE = 11] = "UNCLOSED_QUOTE_IN_ARGUMENT_STYLE", e[e.EXPECT_SELECT_ARGUMENT_OPTIONS = 12] = "EXPECT_SELECT_ARGUMENT_OPTIONS", e[e.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE = 13] = "EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE", e[e.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE = 14] = "INVALID_PLURAL_ARGUMENT_OFFSET_VALUE", e[e.EXPECT_SELECT_ARGUMENT_SELECTOR = 15] = "EXPECT_SELECT_ARGUMENT_SELECTOR", e[e.EXPECT_PLURAL_ARGUMENT_SELECTOR = 16] = "EXPECT_PLURAL_ARGUMENT_SELECTOR", e[e.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT = 17] = "EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT", e[e.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT = 18] = "EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT", e[e.INVALID_PLURAL_ARGUMENT_SELECTOR = 19] = "INVALID_PLURAL_ARGUMENT_SELECTOR", e[e.DUPLICATE_PLURAL_ARGUMENT_SELECTOR = 20] = "DUPLICATE_PLURAL_ARGUMENT_SELECTOR", e[e.DUPLICATE_SELECT_ARGUMENT_SELECTOR = 21] = "DUPLICATE_SELECT_ARGUMENT_SELECTOR", e[e.MISSING_OTHER_CLAUSE = 22] = "MISSING_OTHER_CLAUSE", e[e.INVALID_TAG = 23] = "INVALID_TAG", e[e.INVALID_TAG_NAME = 25] = "INVALID_TAG_NAME", e[e.UNMATCHED_CLOSING_TAG = 26] = "UNMATCHED_CLOSING_TAG", e[e.UNCLOSED_TAG = 27] = "UNCLOSED_TAG";
})(I || (I = {}));
var F;
(function(e) {
  e[e.literal = 0] = "literal", e[e.argument = 1] = "argument", e[e.number = 2] = "number", e[e.date = 3] = "date", e[e.time = 4] = "time", e[e.select = 5] = "select", e[e.plural = 6] = "plural", e[e.pound = 7] = "pound", e[e.tag = 8] = "tag";
})(F || (F = {}));
var dt;
(function(e) {
  e[e.number = 0] = "number", e[e.dateTime = 1] = "dateTime";
})(dt || (dt = {}));
function Gr(e) {
  return e.type === F.literal;
}
function Ca(e) {
  return e.type === F.argument;
}
function Ji(e) {
  return e.type === F.number;
}
function Qi(e) {
  return e.type === F.date;
}
function Yi(e) {
  return e.type === F.time;
}
function Ki(e) {
  return e.type === F.select;
}
function $i(e) {
  return e.type === F.plural;
}
function Pa(e) {
  return e.type === F.pound;
}
function es(e) {
  return e.type === F.tag;
}
function ts(e) {
  return !!(e && typeof e == "object" && e.type === dt.number);
}
function zn(e) {
  return !!(e && typeof e == "object" && e.type === dt.dateTime);
}
var ns = /[ \xA0\u1680\u2000-\u200A\u202F\u205F\u3000]/, Na = /(?:[Eec]{1,6}|G{1,5}|[Qq]{1,5}|(?:[yYur]+|U{1,5})|[ML]{1,5}|d{1,2}|D{1,3}|F{1}|[abB]{1,5}|[hkHK]{1,2}|w{1,2}|W{1}|m{1,2}|s{1,2}|[zZOvVxX]{1,4})(?=([^']*'[^']*')*[^']*$)/g;
function Ia(e) {
  var t = {};
  return e.replace(Na, function(n) {
    var r = n.length;
    switch (n[0]) {
      case "G":
        t.era = r === 4 ? "long" : r === 5 ? "narrow" : "short";
        break;
      case "y":
        t.year = r === 2 ? "2-digit" : "numeric";
        break;
      case "Y":
      case "u":
      case "U":
      case "r":
        throw new RangeError("`Y/u/U/r` (year) patterns are not supported, use `y` instead");
      case "q":
      case "Q":
        throw new RangeError("`q/Q` (quarter) patterns are not supported");
      case "M":
      case "L":
        t.month = ["numeric", "2-digit", "short", "long", "narrow"][r - 1];
        break;
      case "w":
      case "W":
        throw new RangeError("`w/W` (week) patterns are not supported");
      case "d":
        t.day = ["numeric", "2-digit"][r - 1];
        break;
      case "D":
      case "F":
      case "g":
        throw new RangeError("`D/F/g` (day) patterns are not supported, use `d` instead");
      case "E":
        t.weekday = r === 4 ? "short" : r === 5 ? "narrow" : "short";
        break;
      case "e":
        if (r < 4)
          throw new RangeError("`e..eee` (weekday) patterns are not supported");
        t.weekday = ["short", "long", "narrow", "short"][r - 4];
        break;
      case "c":
        if (r < 4)
          throw new RangeError("`c..ccc` (weekday) patterns are not supported");
        t.weekday = ["short", "long", "narrow", "short"][r - 4];
        break;
      case "a":
        t.hour12 = !0;
        break;
      case "b":
      case "B":
        throw new RangeError("`b/B` (period) patterns are not supported, use `a` instead");
      case "h":
        t.hourCycle = "h12", t.hour = ["numeric", "2-digit"][r - 1];
        break;
      case "H":
        t.hourCycle = "h23", t.hour = ["numeric", "2-digit"][r - 1];
        break;
      case "K":
        t.hourCycle = "h11", t.hour = ["numeric", "2-digit"][r - 1];
        break;
      case "k":
        t.hourCycle = "h24", t.hour = ["numeric", "2-digit"][r - 1];
        break;
      case "j":
      case "J":
      case "C":
        throw new RangeError("`j/J/C` (hour) patterns are not supported, use `h/H/K/k` instead");
      case "m":
        t.minute = ["numeric", "2-digit"][r - 1];
        break;
      case "s":
        t.second = ["numeric", "2-digit"][r - 1];
        break;
      case "S":
      case "A":
        throw new RangeError("`S/A` (second) patterns are not supported, use `s` instead");
      case "z":
        t.timeZoneName = r < 4 ? "short" : "long";
        break;
      case "Z":
      case "O":
      case "v":
      case "V":
      case "X":
      case "x":
        throw new RangeError("`Z/O/v/V/X/x` (timeZone) patterns are not supported, use `z` instead");
    }
    return "";
  }), t;
}
var La = /[\t-\r \x85\u200E\u200F\u2028\u2029]/i;
function Oa(e) {
  if (e.length === 0)
    throw new Error("Number skeleton cannot be empty");
  for (var t = e.split(La).filter(function(h) {
    return h.length > 0;
  }), n = [], r = 0, i = t; r < i.length; r++) {
    var s = i[r], l = s.split("/");
    if (l.length === 0)
      throw new Error("Invalid number skeleton");
    for (var a = l[0], o = l.slice(1), u = 0, f = o; u < f.length; u++) {
      var c = f[u];
      if (c.length === 0)
        throw new Error("Invalid number skeleton");
    }
    n.push({ stem: a, options: o });
  }
  return n;
}
function Ma(e) {
  return e.replace(/^(.*?)-/, "");
}
var qr = /^\.(?:(0+)(\*)?|(#+)|(0+)(#+))$/g, rs = /^(@+)?(\+|#+)?[rs]?$/g, Da = /(\*)(0+)|(#+)(0+)|(0+)/g, is = /^(0+)$/;
function jr(e) {
  var t = {};
  return e[e.length - 1] === "r" ? t.roundingPriority = "morePrecision" : e[e.length - 1] === "s" && (t.roundingPriority = "lessPrecision"), e.replace(rs, function(n, r, i) {
    return typeof i != "string" ? (t.minimumSignificantDigits = r.length, t.maximumSignificantDigits = r.length) : i === "+" ? t.minimumSignificantDigits = r.length : r[0] === "#" ? t.maximumSignificantDigits = r.length : (t.minimumSignificantDigits = r.length, t.maximumSignificantDigits = r.length + (typeof i == "string" ? i.length : 0)), "";
  }), t;
}
function ss(e) {
  switch (e) {
    case "sign-auto":
      return {
        signDisplay: "auto"
      };
    case "sign-accounting":
    case "()":
      return {
        currencySign: "accounting"
      };
    case "sign-always":
    case "+!":
      return {
        signDisplay: "always"
      };
    case "sign-accounting-always":
    case "()!":
      return {
        signDisplay: "always",
        currencySign: "accounting"
      };
    case "sign-except-zero":
    case "+?":
      return {
        signDisplay: "exceptZero"
      };
    case "sign-accounting-except-zero":
    case "()?":
      return {
        signDisplay: "exceptZero",
        currencySign: "accounting"
      };
    case "sign-never":
    case "+_":
      return {
        signDisplay: "never"
      };
  }
}
function Ra(e) {
  var t;
  if (e[0] === "E" && e[1] === "E" ? (t = {
    notation: "engineering"
  }, e = e.slice(2)) : e[0] === "E" && (t = {
    notation: "scientific"
  }, e = e.slice(1)), t) {
    var n = e.slice(0, 2);
    if (n === "+!" ? (t.signDisplay = "always", e = e.slice(2)) : n === "+?" && (t.signDisplay = "exceptZero", e = e.slice(2)), !is.test(e))
      throw new Error("Malformed concise eng/scientific notation");
    t.minimumIntegerDigits = e.length;
  }
  return t;
}
function Vr(e) {
  var t = {}, n = ss(e);
  return n || t;
}
function Ua(e) {
  for (var t = {}, n = 0, r = e; n < r.length; n++) {
    var i = r[n];
    switch (i.stem) {
      case "percent":
      case "%":
        t.style = "percent";
        continue;
      case "%x100":
        t.style = "percent", t.scale = 100;
        continue;
      case "currency":
        t.style = "currency", t.currency = i.options[0];
        continue;
      case "group-off":
      case ",_":
        t.useGrouping = !1;
        continue;
      case "precision-integer":
      case ".":
        t.maximumFractionDigits = 0;
        continue;
      case "measure-unit":
      case "unit":
        t.style = "unit", t.unit = Ma(i.options[0]);
        continue;
      case "compact-short":
      case "K":
        t.notation = "compact", t.compactDisplay = "short";
        continue;
      case "compact-long":
      case "KK":
        t.notation = "compact", t.compactDisplay = "long";
        continue;
      case "scientific":
        t = R(R(R({}, t), { notation: "scientific" }), i.options.reduce(function(o, u) {
          return R(R({}, o), Vr(u));
        }, {}));
        continue;
      case "engineering":
        t = R(R(R({}, t), { notation: "engineering" }), i.options.reduce(function(o, u) {
          return R(R({}, o), Vr(u));
        }, {}));
        continue;
      case "notation-simple":
        t.notation = "standard";
        continue;
      case "unit-width-narrow":
        t.currencyDisplay = "narrowSymbol", t.unitDisplay = "narrow";
        continue;
      case "unit-width-short":
        t.currencyDisplay = "code", t.unitDisplay = "short";
        continue;
      case "unit-width-full-name":
        t.currencyDisplay = "name", t.unitDisplay = "long";
        continue;
      case "unit-width-iso-code":
        t.currencyDisplay = "symbol";
        continue;
      case "scale":
        t.scale = parseFloat(i.options[0]);
        continue;
      case "integer-width":
        if (i.options.length > 1)
          throw new RangeError("integer-width stems only accept a single optional option");
        i.options[0].replace(Da, function(o, u, f, c, h, _) {
          if (u)
            t.minimumIntegerDigits = f.length;
          else {
            if (c && h)
              throw new Error("We currently do not support maximum integer digits");
            if (_)
              throw new Error("We currently do not support exact integer digits");
          }
          return "";
        });
        continue;
    }
    if (is.test(i.stem)) {
      t.minimumIntegerDigits = i.stem.length;
      continue;
    }
    if (qr.test(i.stem)) {
      if (i.options.length > 1)
        throw new RangeError("Fraction-precision stems only accept a single optional option");
      i.stem.replace(qr, function(o, u, f, c, h, _) {
        return f === "*" ? t.minimumFractionDigits = u.length : c && c[0] === "#" ? t.maximumFractionDigits = c.length : h && _ ? (t.minimumFractionDigits = h.length, t.maximumFractionDigits = h.length + _.length) : (t.minimumFractionDigits = u.length, t.maximumFractionDigits = u.length), "";
      });
      var s = i.options[0];
      s === "w" ? t = R(R({}, t), { trailingZeroDisplay: "stripIfInteger" }) : s && (t = R(R({}, t), jr(s)));
      continue;
    }
    if (rs.test(i.stem)) {
      t = R(R({}, t), jr(i.stem));
      continue;
    }
    var l = ss(i.stem);
    l && (t = R(R({}, t), l));
    var a = Ra(i.stem);
    a && (t = R(R({}, t), a));
  }
  return t;
}
var Gt = {
  AX: [
    "H"
  ],
  BQ: [
    "H"
  ],
  CP: [
    "H"
  ],
  CZ: [
    "H"
  ],
  DK: [
    "H"
  ],
  FI: [
    "H"
  ],
  ID: [
    "H"
  ],
  IS: [
    "H"
  ],
  ML: [
    "H"
  ],
  NE: [
    "H"
  ],
  RU: [
    "H"
  ],
  SE: [
    "H"
  ],
  SJ: [
    "H"
  ],
  SK: [
    "H"
  ],
  AS: [
    "h",
    "H"
  ],
  BT: [
    "h",
    "H"
  ],
  DJ: [
    "h",
    "H"
  ],
  ER: [
    "h",
    "H"
  ],
  GH: [
    "h",
    "H"
  ],
  IN: [
    "h",
    "H"
  ],
  LS: [
    "h",
    "H"
  ],
  PG: [
    "h",
    "H"
  ],
  PW: [
    "h",
    "H"
  ],
  SO: [
    "h",
    "H"
  ],
  TO: [
    "h",
    "H"
  ],
  VU: [
    "h",
    "H"
  ],
  WS: [
    "h",
    "H"
  ],
  "001": [
    "H",
    "h"
  ],
  AL: [
    "h",
    "H",
    "hB"
  ],
  TD: [
    "h",
    "H",
    "hB"
  ],
  "ca-ES": [
    "H",
    "h",
    "hB"
  ],
  CF: [
    "H",
    "h",
    "hB"
  ],
  CM: [
    "H",
    "h",
    "hB"
  ],
  "fr-CA": [
    "H",
    "h",
    "hB"
  ],
  "gl-ES": [
    "H",
    "h",
    "hB"
  ],
  "it-CH": [
    "H",
    "h",
    "hB"
  ],
  "it-IT": [
    "H",
    "h",
    "hB"
  ],
  LU: [
    "H",
    "h",
    "hB"
  ],
  NP: [
    "H",
    "h",
    "hB"
  ],
  PF: [
    "H",
    "h",
    "hB"
  ],
  SC: [
    "H",
    "h",
    "hB"
  ],
  SM: [
    "H",
    "h",
    "hB"
  ],
  SN: [
    "H",
    "h",
    "hB"
  ],
  TF: [
    "H",
    "h",
    "hB"
  ],
  VA: [
    "H",
    "h",
    "hB"
  ],
  CY: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  GR: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  CO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  DO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KP: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  NA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  VE: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  AC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  AI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BW: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BZ: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  DG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  FK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GB: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IM: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IO: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  JE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  LT: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MS: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NF: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NR: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NU: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  PN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SH: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  TA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  ZA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  "af-ZA": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  AR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CL: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CU: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  EA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BO": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BR": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-EC": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-ES": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-GQ": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-PE": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  GT: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  HN: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  IC: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KG: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KM: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  LK: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MX: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  NI: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  PY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  SV: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  UY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  JP: [
    "H",
    "h",
    "K"
  ],
  AD: [
    "H",
    "hB"
  ],
  AM: [
    "H",
    "hB"
  ],
  AO: [
    "H",
    "hB"
  ],
  AT: [
    "H",
    "hB"
  ],
  AW: [
    "H",
    "hB"
  ],
  BE: [
    "H",
    "hB"
  ],
  BF: [
    "H",
    "hB"
  ],
  BJ: [
    "H",
    "hB"
  ],
  BL: [
    "H",
    "hB"
  ],
  BR: [
    "H",
    "hB"
  ],
  CG: [
    "H",
    "hB"
  ],
  CI: [
    "H",
    "hB"
  ],
  CV: [
    "H",
    "hB"
  ],
  DE: [
    "H",
    "hB"
  ],
  EE: [
    "H",
    "hB"
  ],
  FR: [
    "H",
    "hB"
  ],
  GA: [
    "H",
    "hB"
  ],
  GF: [
    "H",
    "hB"
  ],
  GN: [
    "H",
    "hB"
  ],
  GP: [
    "H",
    "hB"
  ],
  GW: [
    "H",
    "hB"
  ],
  HR: [
    "H",
    "hB"
  ],
  IL: [
    "H",
    "hB"
  ],
  IT: [
    "H",
    "hB"
  ],
  KZ: [
    "H",
    "hB"
  ],
  MC: [
    "H",
    "hB"
  ],
  MD: [
    "H",
    "hB"
  ],
  MF: [
    "H",
    "hB"
  ],
  MQ: [
    "H",
    "hB"
  ],
  MZ: [
    "H",
    "hB"
  ],
  NC: [
    "H",
    "hB"
  ],
  NL: [
    "H",
    "hB"
  ],
  PM: [
    "H",
    "hB"
  ],
  PT: [
    "H",
    "hB"
  ],
  RE: [
    "H",
    "hB"
  ],
  RO: [
    "H",
    "hB"
  ],
  SI: [
    "H",
    "hB"
  ],
  SR: [
    "H",
    "hB"
  ],
  ST: [
    "H",
    "hB"
  ],
  TG: [
    "H",
    "hB"
  ],
  TR: [
    "H",
    "hB"
  ],
  WF: [
    "H",
    "hB"
  ],
  YT: [
    "H",
    "hB"
  ],
  BD: [
    "h",
    "hB",
    "H"
  ],
  PK: [
    "h",
    "hB",
    "H"
  ],
  AZ: [
    "H",
    "hB",
    "h"
  ],
  BA: [
    "H",
    "hB",
    "h"
  ],
  BG: [
    "H",
    "hB",
    "h"
  ],
  CH: [
    "H",
    "hB",
    "h"
  ],
  GE: [
    "H",
    "hB",
    "h"
  ],
  LI: [
    "H",
    "hB",
    "h"
  ],
  ME: [
    "H",
    "hB",
    "h"
  ],
  RS: [
    "H",
    "hB",
    "h"
  ],
  UA: [
    "H",
    "hB",
    "h"
  ],
  UZ: [
    "H",
    "hB",
    "h"
  ],
  XK: [
    "H",
    "hB",
    "h"
  ],
  AG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  AU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  CA: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  DM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  "en-001": [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FJ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GD: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  JM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KN: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LR: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MH: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MP: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MW: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  NZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SL: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TT: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  UM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  US: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  ZM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BO: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  EC: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  ES: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  GQ: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  PE: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  AE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  "ar-001": [
    "h",
    "hB",
    "hb",
    "H"
  ],
  BH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  DZ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EG: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  HK: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  IQ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  JO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  KW: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LB: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MR: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  OM: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PS: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  QA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SD: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  TN: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  YE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  AF: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  LA: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  CN: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  LV: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  TL: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  "zu-ZA": [
    "H",
    "hB",
    "hb",
    "h"
  ],
  CD: [
    "hB",
    "H"
  ],
  IR: [
    "hB",
    "H"
  ],
  "hi-IN": [
    "hB",
    "h",
    "H"
  ],
  "kn-IN": [
    "hB",
    "h",
    "H"
  ],
  "ml-IN": [
    "hB",
    "h",
    "H"
  ],
  "te-IN": [
    "hB",
    "h",
    "H"
  ],
  KH: [
    "hB",
    "h",
    "H",
    "hb"
  ],
  "ta-IN": [
    "hB",
    "h",
    "hb",
    "H"
  ],
  BN: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  MY: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  ET: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "gu-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "mr-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "pa-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  TW: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  KE: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  MM: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  TZ: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  UG: [
    "hB",
    "hb",
    "H",
    "h"
  ]
};
function xa(e, t) {
  for (var n = "", r = 0; r < e.length; r++) {
    var i = e.charAt(r);
    if (i === "j") {
      for (var s = 0; r + 1 < e.length && e.charAt(r + 1) === i; )
        s++, r++;
      var l = 1 + (s & 1), a = s < 2 ? 1 : 3 + (s >> 1), o = "a", u = Fa(t);
      for ((u == "H" || u == "k") && (a = 0); a-- > 0; )
        n += o;
      for (; l-- > 0; )
        n = u + n;
    } else
      i === "J" ? n += "H" : n += i;
  }
  return n;
}
function Fa(e) {
  var t = e.hourCycle;
  if (t === void 0 && // @ts-ignore hourCycle(s) is not identified yet
  e.hourCycles && // @ts-ignore
  e.hourCycles.length && (t = e.hourCycles[0]), t)
    switch (t) {
      case "h24":
        return "k";
      case "h23":
        return "H";
      case "h12":
        return "h";
      case "h11":
        return "K";
      default:
        throw new Error("Invalid hourCycle");
    }
  var n = e.language, r;
  n !== "root" && (r = e.maximize().region);
  var i = Gt[r || ""] || Gt[n || ""] || Gt["".concat(n, "-001")] || Gt["001"];
  return i[0];
}
var Bn, Ga = new RegExp("^".concat(ns.source, "*")), qa = new RegExp("".concat(ns.source, "*$"));
function L(e, t) {
  return { start: e, end: t };
}
var ja = !!String.prototype.startsWith, Va = !!String.fromCodePoint, za = !!Object.fromEntries, Xa = !!String.prototype.codePointAt, Wa = !!String.prototype.trimStart, Za = !!String.prototype.trimEnd, Ja = !!Number.isSafeInteger, Qa = Ja ? Number.isSafeInteger : function(e) {
  return typeof e == "number" && isFinite(e) && Math.floor(e) === e && Math.abs(e) <= 9007199254740991;
}, Xn = !0;
try {
  var Ya = os("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  Xn = ((Bn = Ya.exec("a")) === null || Bn === void 0 ? void 0 : Bn[0]) === "a";
} catch {
  Xn = !1;
}
var zr = ja ? (
  // Native
  function(t, n, r) {
    return t.startsWith(n, r);
  }
) : (
  // For IE11
  function(t, n, r) {
    return t.slice(r, r + n.length) === n;
  }
), Wn = Va ? String.fromCodePoint : (
  // IE11
  function() {
    for (var t = [], n = 0; n < arguments.length; n++)
      t[n] = arguments[n];
    for (var r = "", i = t.length, s = 0, l; i > s; ) {
      if (l = t[s++], l > 1114111)
        throw RangeError(l + " is not a valid code point");
      r += l < 65536 ? String.fromCharCode(l) : String.fromCharCode(((l -= 65536) >> 10) + 55296, l % 1024 + 56320);
    }
    return r;
  }
), Xr = (
  // native
  za ? Object.fromEntries : (
    // Ponyfill
    function(t) {
      for (var n = {}, r = 0, i = t; r < i.length; r++) {
        var s = i[r], l = s[0], a = s[1];
        n[l] = a;
      }
      return n;
    }
  )
), ls = Xa ? (
  // Native
  function(t, n) {
    return t.codePointAt(n);
  }
) : (
  // IE 11
  function(t, n) {
    var r = t.length;
    if (!(n < 0 || n >= r)) {
      var i = t.charCodeAt(n), s;
      return i < 55296 || i > 56319 || n + 1 === r || (s = t.charCodeAt(n + 1)) < 56320 || s > 57343 ? i : (i - 55296 << 10) + (s - 56320) + 65536;
    }
  }
), Ka = Wa ? (
  // Native
  function(t) {
    return t.trimStart();
  }
) : (
  // Ponyfill
  function(t) {
    return t.replace(Ga, "");
  }
), $a = Za ? (
  // Native
  function(t) {
    return t.trimEnd();
  }
) : (
  // Ponyfill
  function(t) {
    return t.replace(qa, "");
  }
);
function os(e, t) {
  return new RegExp(e, t);
}
var Zn;
if (Xn) {
  var Wr = os("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  Zn = function(t, n) {
    var r;
    Wr.lastIndex = n;
    var i = Wr.exec(t);
    return (r = i[1]) !== null && r !== void 0 ? r : "";
  };
} else
  Zn = function(t, n) {
    for (var r = []; ; ) {
      var i = ls(t, n);
      if (i === void 0 || as(i) || ru(i))
        break;
      r.push(i), n += i >= 65536 ? 2 : 1;
    }
    return Wn.apply(void 0, r);
  };
var eu = (
  /** @class */
  function() {
    function e(t, n) {
      n === void 0 && (n = {}), this.message = t, this.position = { offset: 0, line: 1, column: 1 }, this.ignoreTag = !!n.ignoreTag, this.locale = n.locale, this.requiresOtherClause = !!n.requiresOtherClause, this.shouldParseSkeletons = !!n.shouldParseSkeletons;
    }
    return e.prototype.parse = function() {
      if (this.offset() !== 0)
        throw Error("parser can only be used once");
      return this.parseMessage(0, "", !1);
    }, e.prototype.parseMessage = function(t, n, r) {
      for (var i = []; !this.isEOF(); ) {
        var s = this.char();
        if (s === 123) {
          var l = this.parseArgument(t, r);
          if (l.err)
            return l;
          i.push(l.val);
        } else {
          if (s === 125 && t > 0)
            break;
          if (s === 35 && (n === "plural" || n === "selectordinal")) {
            var a = this.clonePosition();
            this.bump(), i.push({
              type: F.pound,
              location: L(a, this.clonePosition())
            });
          } else if (s === 60 && !this.ignoreTag && this.peek() === 47) {
            if (r)
              break;
            return this.error(I.UNMATCHED_CLOSING_TAG, L(this.clonePosition(), this.clonePosition()));
          } else if (s === 60 && !this.ignoreTag && Jn(this.peek() || 0)) {
            var l = this.parseTag(t, n);
            if (l.err)
              return l;
            i.push(l.val);
          } else {
            var l = this.parseLiteral(t, n);
            if (l.err)
              return l;
            i.push(l.val);
          }
        }
      }
      return { val: i, err: null };
    }, e.prototype.parseTag = function(t, n) {
      var r = this.clonePosition();
      this.bump();
      var i = this.parseTagName();
      if (this.bumpSpace(), this.bumpIf("/>"))
        return {
          val: {
            type: F.literal,
            value: "<".concat(i, "/>"),
            location: L(r, this.clonePosition())
          },
          err: null
        };
      if (this.bumpIf(">")) {
        var s = this.parseMessage(t + 1, n, !0);
        if (s.err)
          return s;
        var l = s.val, a = this.clonePosition();
        if (this.bumpIf("</")) {
          if (this.isEOF() || !Jn(this.char()))
            return this.error(I.INVALID_TAG, L(a, this.clonePosition()));
          var o = this.clonePosition(), u = this.parseTagName();
          return i !== u ? this.error(I.UNMATCHED_CLOSING_TAG, L(o, this.clonePosition())) : (this.bumpSpace(), this.bumpIf(">") ? {
            val: {
              type: F.tag,
              value: i,
              children: l,
              location: L(r, this.clonePosition())
            },
            err: null
          } : this.error(I.INVALID_TAG, L(a, this.clonePosition())));
        } else
          return this.error(I.UNCLOSED_TAG, L(r, this.clonePosition()));
      } else
        return this.error(I.INVALID_TAG, L(r, this.clonePosition()));
    }, e.prototype.parseTagName = function() {
      var t = this.offset();
      for (this.bump(); !this.isEOF() && nu(this.char()); )
        this.bump();
      return this.message.slice(t, this.offset());
    }, e.prototype.parseLiteral = function(t, n) {
      for (var r = this.clonePosition(), i = ""; ; ) {
        var s = this.tryParseQuote(n);
        if (s) {
          i += s;
          continue;
        }
        var l = this.tryParseUnquoted(t, n);
        if (l) {
          i += l;
          continue;
        }
        var a = this.tryParseLeftAngleBracket();
        if (a) {
          i += a;
          continue;
        }
        break;
      }
      var o = L(r, this.clonePosition());
      return {
        val: { type: F.literal, value: i, location: o },
        err: null
      };
    }, e.prototype.tryParseLeftAngleBracket = function() {
      return !this.isEOF() && this.char() === 60 && (this.ignoreTag || // If at the opening tag or closing tag position, bail.
      !tu(this.peek() || 0)) ? (this.bump(), "<") : null;
    }, e.prototype.tryParseQuote = function(t) {
      if (this.isEOF() || this.char() !== 39)
        return null;
      switch (this.peek()) {
        case 39:
          return this.bump(), this.bump(), "'";
        case 123:
        case 60:
        case 62:
        case 125:
          break;
        case 35:
          if (t === "plural" || t === "selectordinal")
            break;
          return null;
        default:
          return null;
      }
      this.bump();
      var n = [this.char()];
      for (this.bump(); !this.isEOF(); ) {
        var r = this.char();
        if (r === 39)
          if (this.peek() === 39)
            n.push(39), this.bump();
          else {
            this.bump();
            break;
          }
        else
          n.push(r);
        this.bump();
      }
      return Wn.apply(void 0, n);
    }, e.prototype.tryParseUnquoted = function(t, n) {
      if (this.isEOF())
        return null;
      var r = this.char();
      return r === 60 || r === 123 || r === 35 && (n === "plural" || n === "selectordinal") || r === 125 && t > 0 ? null : (this.bump(), Wn(r));
    }, e.prototype.parseArgument = function(t, n) {
      var r = this.clonePosition();
      if (this.bump(), this.bumpSpace(), this.isEOF())
        return this.error(I.EXPECT_ARGUMENT_CLOSING_BRACE, L(r, this.clonePosition()));
      if (this.char() === 125)
        return this.bump(), this.error(I.EMPTY_ARGUMENT, L(r, this.clonePosition()));
      var i = this.parseIdentifierIfPossible().value;
      if (!i)
        return this.error(I.MALFORMED_ARGUMENT, L(r, this.clonePosition()));
      if (this.bumpSpace(), this.isEOF())
        return this.error(I.EXPECT_ARGUMENT_CLOSING_BRACE, L(r, this.clonePosition()));
      switch (this.char()) {
        case 125:
          return this.bump(), {
            val: {
              type: F.argument,
              // value does not include the opening and closing braces.
              value: i,
              location: L(r, this.clonePosition())
            },
            err: null
          };
        case 44:
          return this.bump(), this.bumpSpace(), this.isEOF() ? this.error(I.EXPECT_ARGUMENT_CLOSING_BRACE, L(r, this.clonePosition())) : this.parseArgumentOptions(t, n, i, r);
        default:
          return this.error(I.MALFORMED_ARGUMENT, L(r, this.clonePosition()));
      }
    }, e.prototype.parseIdentifierIfPossible = function() {
      var t = this.clonePosition(), n = this.offset(), r = Zn(this.message, n), i = n + r.length;
      this.bumpTo(i);
      var s = this.clonePosition(), l = L(t, s);
      return { value: r, location: l };
    }, e.prototype.parseArgumentOptions = function(t, n, r, i) {
      var s, l = this.clonePosition(), a = this.parseIdentifierIfPossible().value, o = this.clonePosition();
      switch (a) {
        case "":
          return this.error(I.EXPECT_ARGUMENT_TYPE, L(l, o));
        case "number":
        case "date":
        case "time": {
          this.bumpSpace();
          var u = null;
          if (this.bumpIf(",")) {
            this.bumpSpace();
            var f = this.clonePosition(), c = this.parseSimpleArgStyleIfPossible();
            if (c.err)
              return c;
            var h = $a(c.val);
            if (h.length === 0)
              return this.error(I.EXPECT_ARGUMENT_STYLE, L(this.clonePosition(), this.clonePosition()));
            var _ = L(f, this.clonePosition());
            u = { style: h, styleLocation: _ };
          }
          var d = this.tryParseArgumentClose(i);
          if (d.err)
            return d;
          var p = L(i, this.clonePosition());
          if (u && zr(u == null ? void 0 : u.style, "::", 0)) {
            var y = Ka(u.style.slice(2));
            if (a === "number") {
              var c = this.parseNumberSkeletonFromString(y, u.styleLocation);
              return c.err ? c : {
                val: { type: F.number, value: r, location: p, style: c.val },
                err: null
              };
            } else {
              if (y.length === 0)
                return this.error(I.EXPECT_DATE_TIME_SKELETON, p);
              var v = y;
              this.locale && (v = xa(y, this.locale));
              var h = {
                type: dt.dateTime,
                pattern: v,
                location: u.styleLocation,
                parsedOptions: this.shouldParseSkeletons ? Ia(v) : {}
              }, E = a === "date" ? F.date : F.time;
              return {
                val: { type: E, value: r, location: p, style: h },
                err: null
              };
            }
          }
          return {
            val: {
              type: a === "number" ? F.number : a === "date" ? F.date : F.time,
              value: r,
              location: p,
              style: (s = u == null ? void 0 : u.style) !== null && s !== void 0 ? s : null
            },
            err: null
          };
        }
        case "plural":
        case "selectordinal":
        case "select": {
          var g = this.clonePosition();
          if (this.bumpSpace(), !this.bumpIf(","))
            return this.error(I.EXPECT_SELECT_ARGUMENT_OPTIONS, L(g, R({}, g)));
          this.bumpSpace();
          var A = this.parseIdentifierIfPossible(), T = 0;
          if (a !== "select" && A.value === "offset") {
            if (!this.bumpIf(":"))
              return this.error(I.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, L(this.clonePosition(), this.clonePosition()));
            this.bumpSpace();
            var c = this.tryParseDecimalInteger(I.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, I.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE);
            if (c.err)
              return c;
            this.bumpSpace(), A = this.parseIdentifierIfPossible(), T = c.val;
          }
          var w = this.tryParsePluralOrSelectOptions(t, a, n, A);
          if (w.err)
            return w;
          var d = this.tryParseArgumentClose(i);
          if (d.err)
            return d;
          var j = L(i, this.clonePosition());
          return a === "select" ? {
            val: {
              type: F.select,
              value: r,
              options: Xr(w.val),
              location: j
            },
            err: null
          } : {
            val: {
              type: F.plural,
              value: r,
              options: Xr(w.val),
              offset: T,
              pluralType: a === "plural" ? "cardinal" : "ordinal",
              location: j
            },
            err: null
          };
        }
        default:
          return this.error(I.INVALID_ARGUMENT_TYPE, L(l, o));
      }
    }, e.prototype.tryParseArgumentClose = function(t) {
      return this.isEOF() || this.char() !== 125 ? this.error(I.EXPECT_ARGUMENT_CLOSING_BRACE, L(t, this.clonePosition())) : (this.bump(), { val: !0, err: null });
    }, e.prototype.parseSimpleArgStyleIfPossible = function() {
      for (var t = 0, n = this.clonePosition(); !this.isEOF(); ) {
        var r = this.char();
        switch (r) {
          case 39: {
            this.bump();
            var i = this.clonePosition();
            if (!this.bumpUntil("'"))
              return this.error(I.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE, L(i, this.clonePosition()));
            this.bump();
            break;
          }
          case 123: {
            t += 1, this.bump();
            break;
          }
          case 125: {
            if (t > 0)
              t -= 1;
            else
              return {
                val: this.message.slice(n.offset, this.offset()),
                err: null
              };
            break;
          }
          default:
            this.bump();
            break;
        }
      }
      return {
        val: this.message.slice(n.offset, this.offset()),
        err: null
      };
    }, e.prototype.parseNumberSkeletonFromString = function(t, n) {
      var r = [];
      try {
        r = Oa(t);
      } catch {
        return this.error(I.INVALID_NUMBER_SKELETON, n);
      }
      return {
        val: {
          type: dt.number,
          tokens: r,
          location: n,
          parsedOptions: this.shouldParseSkeletons ? Ua(r) : {}
        },
        err: null
      };
    }, e.prototype.tryParsePluralOrSelectOptions = function(t, n, r, i) {
      for (var s, l = !1, a = [], o = /* @__PURE__ */ new Set(), u = i.value, f = i.location; ; ) {
        if (u.length === 0) {
          var c = this.clonePosition();
          if (n !== "select" && this.bumpIf("=")) {
            var h = this.tryParseDecimalInteger(I.EXPECT_PLURAL_ARGUMENT_SELECTOR, I.INVALID_PLURAL_ARGUMENT_SELECTOR);
            if (h.err)
              return h;
            f = L(c, this.clonePosition()), u = this.message.slice(c.offset, this.offset());
          } else
            break;
        }
        if (o.has(u))
          return this.error(n === "select" ? I.DUPLICATE_SELECT_ARGUMENT_SELECTOR : I.DUPLICATE_PLURAL_ARGUMENT_SELECTOR, f);
        u === "other" && (l = !0), this.bumpSpace();
        var _ = this.clonePosition();
        if (!this.bumpIf("{"))
          return this.error(n === "select" ? I.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT : I.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT, L(this.clonePosition(), this.clonePosition()));
        var d = this.parseMessage(t + 1, n, r);
        if (d.err)
          return d;
        var p = this.tryParseArgumentClose(_);
        if (p.err)
          return p;
        a.push([
          u,
          {
            value: d.val,
            location: L(_, this.clonePosition())
          }
        ]), o.add(u), this.bumpSpace(), s = this.parseIdentifierIfPossible(), u = s.value, f = s.location;
      }
      return a.length === 0 ? this.error(n === "select" ? I.EXPECT_SELECT_ARGUMENT_SELECTOR : I.EXPECT_PLURAL_ARGUMENT_SELECTOR, L(this.clonePosition(), this.clonePosition())) : this.requiresOtherClause && !l ? this.error(I.MISSING_OTHER_CLAUSE, L(this.clonePosition(), this.clonePosition())) : { val: a, err: null };
    }, e.prototype.tryParseDecimalInteger = function(t, n) {
      var r = 1, i = this.clonePosition();
      this.bumpIf("+") || this.bumpIf("-") && (r = -1);
      for (var s = !1, l = 0; !this.isEOF(); ) {
        var a = this.char();
        if (a >= 48 && a <= 57)
          s = !0, l = l * 10 + (a - 48), this.bump();
        else
          break;
      }
      var o = L(i, this.clonePosition());
      return s ? (l *= r, Qa(l) ? { val: l, err: null } : this.error(n, o)) : this.error(t, o);
    }, e.prototype.offset = function() {
      return this.position.offset;
    }, e.prototype.isEOF = function() {
      return this.offset() === this.message.length;
    }, e.prototype.clonePosition = function() {
      return {
        offset: this.position.offset,
        line: this.position.line,
        column: this.position.column
      };
    }, e.prototype.char = function() {
      var t = this.position.offset;
      if (t >= this.message.length)
        throw Error("out of bound");
      var n = ls(this.message, t);
      if (n === void 0)
        throw Error("Offset ".concat(t, " is at invalid UTF-16 code unit boundary"));
      return n;
    }, e.prototype.error = function(t, n) {
      return {
        val: null,
        err: {
          kind: t,
          message: this.message,
          location: n
        }
      };
    }, e.prototype.bump = function() {
      if (!this.isEOF()) {
        var t = this.char();
        t === 10 ? (this.position.line += 1, this.position.column = 1, this.position.offset += 1) : (this.position.column += 1, this.position.offset += t < 65536 ? 1 : 2);
      }
    }, e.prototype.bumpIf = function(t) {
      if (zr(this.message, t, this.offset())) {
        for (var n = 0; n < t.length; n++)
          this.bump();
        return !0;
      }
      return !1;
    }, e.prototype.bumpUntil = function(t) {
      var n = this.offset(), r = this.message.indexOf(t, n);
      return r >= 0 ? (this.bumpTo(r), !0) : (this.bumpTo(this.message.length), !1);
    }, e.prototype.bumpTo = function(t) {
      if (this.offset() > t)
        throw Error("targetOffset ".concat(t, " must be greater than or equal to the current offset ").concat(this.offset()));
      for (t = Math.min(t, this.message.length); ; ) {
        var n = this.offset();
        if (n === t)
          break;
        if (n > t)
          throw Error("targetOffset ".concat(t, " is at invalid UTF-16 code unit boundary"));
        if (this.bump(), this.isEOF())
          break;
      }
    }, e.prototype.bumpSpace = function() {
      for (; !this.isEOF() && as(this.char()); )
        this.bump();
    }, e.prototype.peek = function() {
      if (this.isEOF())
        return null;
      var t = this.char(), n = this.offset(), r = this.message.charCodeAt(n + (t >= 65536 ? 2 : 1));
      return r ?? null;
    }, e;
  }()
);
function Jn(e) {
  return e >= 97 && e <= 122 || e >= 65 && e <= 90;
}
function tu(e) {
  return Jn(e) || e === 47;
}
function nu(e) {
  return e === 45 || e === 46 || e >= 48 && e <= 57 || e === 95 || e >= 97 && e <= 122 || e >= 65 && e <= 90 || e == 183 || e >= 192 && e <= 214 || e >= 216 && e <= 246 || e >= 248 && e <= 893 || e >= 895 && e <= 8191 || e >= 8204 && e <= 8205 || e >= 8255 && e <= 8256 || e >= 8304 && e <= 8591 || e >= 11264 && e <= 12271 || e >= 12289 && e <= 55295 || e >= 63744 && e <= 64975 || e >= 65008 && e <= 65533 || e >= 65536 && e <= 983039;
}
function as(e) {
  return e >= 9 && e <= 13 || e === 32 || e === 133 || e >= 8206 && e <= 8207 || e === 8232 || e === 8233;
}
function ru(e) {
  return e >= 33 && e <= 35 || e === 36 || e >= 37 && e <= 39 || e === 40 || e === 41 || e === 42 || e === 43 || e === 44 || e === 45 || e >= 46 && e <= 47 || e >= 58 && e <= 59 || e >= 60 && e <= 62 || e >= 63 && e <= 64 || e === 91 || e === 92 || e === 93 || e === 94 || e === 96 || e === 123 || e === 124 || e === 125 || e === 126 || e === 161 || e >= 162 && e <= 165 || e === 166 || e === 167 || e === 169 || e === 171 || e === 172 || e === 174 || e === 176 || e === 177 || e === 182 || e === 187 || e === 191 || e === 215 || e === 247 || e >= 8208 && e <= 8213 || e >= 8214 && e <= 8215 || e === 8216 || e === 8217 || e === 8218 || e >= 8219 && e <= 8220 || e === 8221 || e === 8222 || e === 8223 || e >= 8224 && e <= 8231 || e >= 8240 && e <= 8248 || e === 8249 || e === 8250 || e >= 8251 && e <= 8254 || e >= 8257 && e <= 8259 || e === 8260 || e === 8261 || e === 8262 || e >= 8263 && e <= 8273 || e === 8274 || e === 8275 || e >= 8277 && e <= 8286 || e >= 8592 && e <= 8596 || e >= 8597 && e <= 8601 || e >= 8602 && e <= 8603 || e >= 8604 && e <= 8607 || e === 8608 || e >= 8609 && e <= 8610 || e === 8611 || e >= 8612 && e <= 8613 || e === 8614 || e >= 8615 && e <= 8621 || e === 8622 || e >= 8623 && e <= 8653 || e >= 8654 && e <= 8655 || e >= 8656 && e <= 8657 || e === 8658 || e === 8659 || e === 8660 || e >= 8661 && e <= 8691 || e >= 8692 && e <= 8959 || e >= 8960 && e <= 8967 || e === 8968 || e === 8969 || e === 8970 || e === 8971 || e >= 8972 && e <= 8991 || e >= 8992 && e <= 8993 || e >= 8994 && e <= 9e3 || e === 9001 || e === 9002 || e >= 9003 && e <= 9083 || e === 9084 || e >= 9085 && e <= 9114 || e >= 9115 && e <= 9139 || e >= 9140 && e <= 9179 || e >= 9180 && e <= 9185 || e >= 9186 && e <= 9254 || e >= 9255 && e <= 9279 || e >= 9280 && e <= 9290 || e >= 9291 && e <= 9311 || e >= 9472 && e <= 9654 || e === 9655 || e >= 9656 && e <= 9664 || e === 9665 || e >= 9666 && e <= 9719 || e >= 9720 && e <= 9727 || e >= 9728 && e <= 9838 || e === 9839 || e >= 9840 && e <= 10087 || e === 10088 || e === 10089 || e === 10090 || e === 10091 || e === 10092 || e === 10093 || e === 10094 || e === 10095 || e === 10096 || e === 10097 || e === 10098 || e === 10099 || e === 10100 || e === 10101 || e >= 10132 && e <= 10175 || e >= 10176 && e <= 10180 || e === 10181 || e === 10182 || e >= 10183 && e <= 10213 || e === 10214 || e === 10215 || e === 10216 || e === 10217 || e === 10218 || e === 10219 || e === 10220 || e === 10221 || e === 10222 || e === 10223 || e >= 10224 && e <= 10239 || e >= 10240 && e <= 10495 || e >= 10496 && e <= 10626 || e === 10627 || e === 10628 || e === 10629 || e === 10630 || e === 10631 || e === 10632 || e === 10633 || e === 10634 || e === 10635 || e === 10636 || e === 10637 || e === 10638 || e === 10639 || e === 10640 || e === 10641 || e === 10642 || e === 10643 || e === 10644 || e === 10645 || e === 10646 || e === 10647 || e === 10648 || e >= 10649 && e <= 10711 || e === 10712 || e === 10713 || e === 10714 || e === 10715 || e >= 10716 && e <= 10747 || e === 10748 || e === 10749 || e >= 10750 && e <= 11007 || e >= 11008 && e <= 11055 || e >= 11056 && e <= 11076 || e >= 11077 && e <= 11078 || e >= 11079 && e <= 11084 || e >= 11085 && e <= 11123 || e >= 11124 && e <= 11125 || e >= 11126 && e <= 11157 || e === 11158 || e >= 11159 && e <= 11263 || e >= 11776 && e <= 11777 || e === 11778 || e === 11779 || e === 11780 || e === 11781 || e >= 11782 && e <= 11784 || e === 11785 || e === 11786 || e === 11787 || e === 11788 || e === 11789 || e >= 11790 && e <= 11798 || e === 11799 || e >= 11800 && e <= 11801 || e === 11802 || e === 11803 || e === 11804 || e === 11805 || e >= 11806 && e <= 11807 || e === 11808 || e === 11809 || e === 11810 || e === 11811 || e === 11812 || e === 11813 || e === 11814 || e === 11815 || e === 11816 || e === 11817 || e >= 11818 && e <= 11822 || e === 11823 || e >= 11824 && e <= 11833 || e >= 11834 && e <= 11835 || e >= 11836 && e <= 11839 || e === 11840 || e === 11841 || e === 11842 || e >= 11843 && e <= 11855 || e >= 11856 && e <= 11857 || e === 11858 || e >= 11859 && e <= 11903 || e >= 12289 && e <= 12291 || e === 12296 || e === 12297 || e === 12298 || e === 12299 || e === 12300 || e === 12301 || e === 12302 || e === 12303 || e === 12304 || e === 12305 || e >= 12306 && e <= 12307 || e === 12308 || e === 12309 || e === 12310 || e === 12311 || e === 12312 || e === 12313 || e === 12314 || e === 12315 || e === 12316 || e === 12317 || e >= 12318 && e <= 12319 || e === 12320 || e === 12336 || e === 64830 || e === 64831 || e >= 65093 && e <= 65094;
}
function Qn(e) {
  e.forEach(function(t) {
    if (delete t.location, Ki(t) || $i(t))
      for (var n in t.options)
        delete t.options[n].location, Qn(t.options[n].value);
    else
      Ji(t) && ts(t.style) || (Qi(t) || Yi(t)) && zn(t.style) ? delete t.style.location : es(t) && Qn(t.children);
  });
}
function iu(e, t) {
  t === void 0 && (t = {}), t = R({ shouldParseSkeletons: !0, requiresOtherClause: !0 }, t);
  var n = new eu(e, t).parse();
  if (n.err) {
    var r = SyntaxError(I[n.err.kind]);
    throw r.location = n.err.location, r.originalMessage = n.err.message, r;
  }
  return t != null && t.captureLocation || Qn(n.val), n.val;
}
function Hn(e, t) {
  var n = t && t.cache ? t.cache : fu, r = t && t.serializer ? t.serializer : uu, i = t && t.strategy ? t.strategy : lu;
  return i(e, {
    cache: n,
    serializer: r
  });
}
function su(e) {
  return e == null || typeof e == "number" || typeof e == "boolean";
}
function us(e, t, n, r) {
  var i = su(r) ? r : n(r), s = t.get(i);
  return typeof s > "u" && (s = e.call(this, r), t.set(i, s)), s;
}
function fs(e, t, n) {
  var r = Array.prototype.slice.call(arguments, 3), i = n(r), s = t.get(i);
  return typeof s > "u" && (s = e.apply(this, r), t.set(i, s)), s;
}
function cr(e, t, n, r, i) {
  return n.bind(t, e, r, i);
}
function lu(e, t) {
  var n = e.length === 1 ? us : fs;
  return cr(e, this, n, t.cache.create(), t.serializer);
}
function ou(e, t) {
  return cr(e, this, fs, t.cache.create(), t.serializer);
}
function au(e, t) {
  return cr(e, this, us, t.cache.create(), t.serializer);
}
var uu = function() {
  return JSON.stringify(arguments);
};
function hr() {
  this.cache = /* @__PURE__ */ Object.create(null);
}
hr.prototype.get = function(e) {
  return this.cache[e];
};
hr.prototype.set = function(e, t) {
  this.cache[e] = t;
};
var fu = {
  create: function() {
    return new hr();
  }
}, kn = {
  variadic: ou,
  monadic: au
}, mt;
(function(e) {
  e.MISSING_VALUE = "MISSING_VALUE", e.INVALID_VALUE = "INVALID_VALUE", e.MISSING_INTL_API = "MISSING_INTL_API";
})(mt || (mt = {}));
var sn = (
  /** @class */
  function(e) {
    rn(t, e);
    function t(n, r, i) {
      var s = e.call(this, n) || this;
      return s.code = r, s.originalMessage = i, s;
    }
    return t.prototype.toString = function() {
      return "[formatjs Error: ".concat(this.code, "] ").concat(this.message);
    }, t;
  }(Error)
), Zr = (
  /** @class */
  function(e) {
    rn(t, e);
    function t(n, r, i, s) {
      return e.call(this, 'Invalid values for "'.concat(n, '": "').concat(r, '". Options are "').concat(Object.keys(i).join('", "'), '"'), mt.INVALID_VALUE, s) || this;
    }
    return t;
  }(sn)
), cu = (
  /** @class */
  function(e) {
    rn(t, e);
    function t(n, r, i) {
      return e.call(this, 'Value for "'.concat(n, '" must be of type ').concat(r), mt.INVALID_VALUE, i) || this;
    }
    return t;
  }(sn)
), hu = (
  /** @class */
  function(e) {
    rn(t, e);
    function t(n, r) {
      return e.call(this, 'The intl string context variable "'.concat(n, '" was not provided to the string "').concat(r, '"'), mt.MISSING_VALUE, r) || this;
    }
    return t;
  }(sn)
), ee;
(function(e) {
  e[e.literal = 0] = "literal", e[e.object = 1] = "object";
})(ee || (ee = {}));
function _u(e) {
  return e.length < 2 ? e : e.reduce(function(t, n) {
    var r = t[t.length - 1];
    return !r || r.type !== ee.literal || n.type !== ee.literal ? t.push(n) : r.value += n.value, t;
  }, []);
}
function du(e) {
  return typeof e == "function";
}
function Xt(e, t, n, r, i, s, l) {
  if (e.length === 1 && Gr(e[0]))
    return [
      {
        type: ee.literal,
        value: e[0].value
      }
    ];
  for (var a = [], o = 0, u = e; o < u.length; o++) {
    var f = u[o];
    if (Gr(f)) {
      a.push({
        type: ee.literal,
        value: f.value
      });
      continue;
    }
    if (Pa(f)) {
      typeof s == "number" && a.push({
        type: ee.literal,
        value: n.getNumberFormat(t).format(s)
      });
      continue;
    }
    var c = f.value;
    if (!(i && c in i))
      throw new hu(c, l);
    var h = i[c];
    if (Ca(f)) {
      (!h || typeof h == "string" || typeof h == "number") && (h = typeof h == "string" || typeof h == "number" ? String(h) : ""), a.push({
        type: typeof h == "string" ? ee.literal : ee.object,
        value: h
      });
      continue;
    }
    if (Qi(f)) {
      var _ = typeof f.style == "string" ? r.date[f.style] : zn(f.style) ? f.style.parsedOptions : void 0;
      a.push({
        type: ee.literal,
        value: n.getDateTimeFormat(t, _).format(h)
      });
      continue;
    }
    if (Yi(f)) {
      var _ = typeof f.style == "string" ? r.time[f.style] : zn(f.style) ? f.style.parsedOptions : r.time.medium;
      a.push({
        type: ee.literal,
        value: n.getDateTimeFormat(t, _).format(h)
      });
      continue;
    }
    if (Ji(f)) {
      var _ = typeof f.style == "string" ? r.number[f.style] : ts(f.style) ? f.style.parsedOptions : void 0;
      _ && _.scale && (h = h * (_.scale || 1)), a.push({
        type: ee.literal,
        value: n.getNumberFormat(t, _).format(h)
      });
      continue;
    }
    if (es(f)) {
      var d = f.children, p = f.value, y = i[p];
      if (!du(y))
        throw new cu(p, "function", l);
      var v = Xt(d, t, n, r, i, s), E = y(v.map(function(T) {
        return T.value;
      }));
      Array.isArray(E) || (E = [E]), a.push.apply(a, E.map(function(T) {
        return {
          type: typeof T == "string" ? ee.literal : ee.object,
          value: T
        };
      }));
    }
    if (Ki(f)) {
      var g = f.options[h] || f.options.other;
      if (!g)
        throw new Zr(f.value, h, Object.keys(f.options), l);
      a.push.apply(a, Xt(g.value, t, n, r, i));
      continue;
    }
    if ($i(f)) {
      var g = f.options["=".concat(h)];
      if (!g) {
        if (!Intl.PluralRules)
          throw new sn(`Intl.PluralRules is not available in this environment.
Try polyfilling it using "@formatjs/intl-pluralrules"
`, mt.MISSING_INTL_API, l);
        var A = n.getPluralRules(t, { type: f.pluralType }).select(h - (f.offset || 0));
        g = f.options[A] || f.options.other;
      }
      if (!g)
        throw new Zr(f.value, h, Object.keys(f.options), l);
      a.push.apply(a, Xt(g.value, t, n, r, i, h - (f.offset || 0)));
      continue;
    }
  }
  return _u(a);
}
function mu(e, t) {
  return t ? R(R(R({}, e || {}), t || {}), Object.keys(e).reduce(function(n, r) {
    return n[r] = R(R({}, e[r]), t[r] || {}), n;
  }, {})) : e;
}
function pu(e, t) {
  return t ? Object.keys(e).reduce(function(n, r) {
    return n[r] = mu(e[r], t[r]), n;
  }, R({}, e)) : e;
}
function Cn(e) {
  return {
    create: function() {
      return {
        get: function(t) {
          return e[t];
        },
        set: function(t, n) {
          e[t] = n;
        }
      };
    }
  };
}
function gu(e) {
  return e === void 0 && (e = {
    number: {},
    dateTime: {},
    pluralRules: {}
  }), {
    getNumberFormat: Hn(function() {
      for (var t, n = [], r = 0; r < arguments.length; r++)
        n[r] = arguments[r];
      return new ((t = Intl.NumberFormat).bind.apply(t, An([void 0], n, !1)))();
    }, {
      cache: Cn(e.number),
      strategy: kn.variadic
    }),
    getDateTimeFormat: Hn(function() {
      for (var t, n = [], r = 0; r < arguments.length; r++)
        n[r] = arguments[r];
      return new ((t = Intl.DateTimeFormat).bind.apply(t, An([void 0], n, !1)))();
    }, {
      cache: Cn(e.dateTime),
      strategy: kn.variadic
    }),
    getPluralRules: Hn(function() {
      for (var t, n = [], r = 0; r < arguments.length; r++)
        n[r] = arguments[r];
      return new ((t = Intl.PluralRules).bind.apply(t, An([void 0], n, !1)))();
    }, {
      cache: Cn(e.pluralRules),
      strategy: kn.variadic
    })
  };
}
var bu = (
  /** @class */
  function() {
    function e(t, n, r, i) {
      var s = this;
      if (n === void 0 && (n = e.defaultLocale), this.formatterCache = {
        number: {},
        dateTime: {},
        pluralRules: {}
      }, this.format = function(l) {
        var a = s.formatToParts(l);
        if (a.length === 1)
          return a[0].value;
        var o = a.reduce(function(u, f) {
          return !u.length || f.type !== ee.literal || typeof u[u.length - 1] != "string" ? u.push(f.value) : u[u.length - 1] += f.value, u;
        }, []);
        return o.length <= 1 ? o[0] || "" : o;
      }, this.formatToParts = function(l) {
        return Xt(s.ast, s.locales, s.formatters, s.formats, l, void 0, s.message);
      }, this.resolvedOptions = function() {
        return {
          locale: s.resolvedLocale.toString()
        };
      }, this.getAst = function() {
        return s.ast;
      }, this.locales = n, this.resolvedLocale = e.resolveLocale(n), typeof t == "string") {
        if (this.message = t, !e.__parse)
          throw new TypeError("IntlMessageFormat.__parse must be set to process `message` of type `string`");
        this.ast = e.__parse(t, {
          ignoreTag: i == null ? void 0 : i.ignoreTag,
          locale: this.resolvedLocale
        });
      } else
        this.ast = t;
      if (!Array.isArray(this.ast))
        throw new TypeError("A message must be provided as a String or AST.");
      this.formats = pu(e.formats, r), this.formatters = i && i.formatters || gu(this.formatterCache);
    }
    return Object.defineProperty(e, "defaultLocale", {
      get: function() {
        return e.memoizedDefaultLocale || (e.memoizedDefaultLocale = new Intl.NumberFormat().resolvedOptions().locale), e.memoizedDefaultLocale;
      },
      enumerable: !1,
      configurable: !0
    }), e.memoizedDefaultLocale = null, e.resolveLocale = function(t) {
      var n = Intl.NumberFormat.supportedLocalesOf(t);
      return n.length > 0 ? new Intl.Locale(n[0]) : new Intl.Locale(typeof t == "string" ? t : t[0]);
    }, e.__parse = iu, e.formats = {
      number: {
        integer: {
          maximumFractionDigits: 0
        },
        currency: {
          style: "currency"
        },
        percent: {
          style: "percent"
        }
      },
      date: {
        short: {
          month: "numeric",
          day: "numeric",
          year: "2-digit"
        },
        medium: {
          month: "short",
          day: "numeric",
          year: "numeric"
        },
        long: {
          month: "long",
          day: "numeric",
          year: "numeric"
        },
        full: {
          weekday: "long",
          month: "long",
          day: "numeric",
          year: "numeric"
        }
      },
      time: {
        short: {
          hour: "numeric",
          minute: "numeric"
        },
        medium: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric"
        },
        long: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        },
        full: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        }
      }
    }, e;
  }()
);
function vu(e, t) {
  if (t == null)
    return;
  if (t in e)
    return e[t];
  const n = t.split(".");
  let r = e;
  for (let i = 0; i < n.length; i++)
    if (typeof r == "object") {
      if (i > 0) {
        const s = n.slice(i, n.length).join(".");
        if (s in r) {
          r = r[s];
          break;
        }
      }
      r = r[n[i]];
    } else
      r = void 0;
  return r;
}
const Ue = {}, yu = (e, t, n) => n && (t in Ue || (Ue[t] = {}), e in Ue[t] || (Ue[t][e] = n), n), cs = (e, t) => {
  if (t == null)
    return;
  if (t in Ue && e in Ue[t])
    return Ue[t][e];
  const n = ln(t);
  for (let r = 0; r < n.length; r++) {
    const i = n[r], s = Eu(i, e);
    if (s)
      return yu(e, t, s);
  }
};
let _r;
const Lt = It({});
function wu(e) {
  return _r[e] || null;
}
function hs(e) {
  return e in _r;
}
function Eu(e, t) {
  if (!hs(e))
    return null;
  const n = wu(e);
  return vu(n, t);
}
function Su(e) {
  if (e == null)
    return;
  const t = ln(e);
  for (let n = 0; n < t.length; n++) {
    const r = t[n];
    if (hs(r))
      return r;
  }
}
function Tu(e, ...t) {
  delete Ue[e], Lt.update((n) => (n[e] = ka.all([n[e] || {}, ...t]), n));
}
vt(
  [Lt],
  ([e]) => Object.keys(e)
);
Lt.subscribe((e) => _r = e);
const Wt = {};
function Au(e, t) {
  Wt[e].delete(t), Wt[e].size === 0 && delete Wt[e];
}
function _s(e) {
  return Wt[e];
}
function Bu(e) {
  return ln(e).map((t) => {
    const n = _s(t);
    return [t, n ? [...n] : []];
  }).filter(([, t]) => t.length > 0);
}
function Yn(e) {
  return e == null ? !1 : ln(e).some(
    (t) => {
      var n;
      return (n = _s(t)) == null ? void 0 : n.size;
    }
  );
}
function Hu(e, t) {
  return Promise.all(
    t.map((r) => (Au(e, r), r().then((i) => i.default || i)))
  ).then((r) => Tu(e, ...r));
}
const Tt = {};
function ds(e) {
  if (!Yn(e))
    return e in Tt ? Tt[e] : Promise.resolve();
  const t = Bu(e);
  return Tt[e] = Promise.all(
    t.map(
      ([n, r]) => Hu(n, r)
    )
  ).then(() => {
    if (Yn(e))
      return ds(e);
    delete Tt[e];
  }), Tt[e];
}
const ku = {
  number: {
    scientific: { notation: "scientific" },
    engineering: { notation: "engineering" },
    compactLong: { notation: "compact", compactDisplay: "long" },
    compactShort: { notation: "compact", compactDisplay: "short" }
  },
  date: {
    short: { month: "numeric", day: "numeric", year: "2-digit" },
    medium: { month: "short", day: "numeric", year: "numeric" },
    long: { month: "long", day: "numeric", year: "numeric" },
    full: { weekday: "long", month: "long", day: "numeric", year: "numeric" }
  },
  time: {
    short: { hour: "numeric", minute: "numeric" },
    medium: { hour: "numeric", minute: "numeric", second: "numeric" },
    long: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    },
    full: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    }
  }
}, Cu = {
  fallbackLocale: null,
  loadingDelay: 200,
  formats: ku,
  warnOnMissingMessages: !0,
  handleMissingMessage: void 0,
  ignoreTag: !0
}, Pu = Cu;
function pt() {
  return Pu;
}
const Pn = It(!1);
var Nu = Object.defineProperty, Iu = Object.defineProperties, Lu = Object.getOwnPropertyDescriptors, Jr = Object.getOwnPropertySymbols, Ou = Object.prototype.hasOwnProperty, Mu = Object.prototype.propertyIsEnumerable, Qr = (e, t, n) => t in e ? Nu(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, Du = (e, t) => {
  for (var n in t || (t = {}))
    Ou.call(t, n) && Qr(e, n, t[n]);
  if (Jr)
    for (var n of Jr(t))
      Mu.call(t, n) && Qr(e, n, t[n]);
  return e;
}, Ru = (e, t) => Iu(e, Lu(t));
let Kn;
const Qt = It(null);
function Yr(e) {
  return e.split("-").map((t, n, r) => r.slice(0, n + 1).join("-")).reverse();
}
function ln(e, t = pt().fallbackLocale) {
  const n = Yr(e);
  return t ? [.../* @__PURE__ */ new Set([...n, ...Yr(t)])] : n;
}
function nt() {
  return Kn ?? void 0;
}
Qt.subscribe((e) => {
  Kn = e ?? void 0, typeof window < "u" && e != null && document.documentElement.setAttribute("lang", e);
});
const Uu = (e) => {
  if (e && Su(e) && Yn(e)) {
    const { loadingDelay: t } = pt();
    let n;
    return typeof window < "u" && nt() != null && t ? n = window.setTimeout(
      () => Pn.set(!0),
      t
    ) : Pn.set(!0), ds(e).then(() => {
      Qt.set(e);
    }).finally(() => {
      clearTimeout(n), Pn.set(!1);
    });
  }
  return Qt.set(e);
}, Ot = Ru(Du({}, Qt), {
  set: Uu
}), on = (e) => {
  const t = /* @__PURE__ */ Object.create(null);
  return (r) => {
    const i = JSON.stringify(r);
    return i in t ? t[i] : t[i] = e(r);
  };
};
var xu = Object.defineProperty, Yt = Object.getOwnPropertySymbols, ms = Object.prototype.hasOwnProperty, ps = Object.prototype.propertyIsEnumerable, Kr = (e, t, n) => t in e ? xu(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, dr = (e, t) => {
  for (var n in t || (t = {}))
    ms.call(t, n) && Kr(e, n, t[n]);
  if (Yt)
    for (var n of Yt(t))
      ps.call(t, n) && Kr(e, n, t[n]);
  return e;
}, yt = (e, t) => {
  var n = {};
  for (var r in e)
    ms.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
  if (e != null && Yt)
    for (var r of Yt(e))
      t.indexOf(r) < 0 && ps.call(e, r) && (n[r] = e[r]);
  return n;
};
const Nt = (e, t) => {
  const { formats: n } = pt();
  if (e in n && t in n[e])
    return n[e][t];
  throw new Error(`[svelte-i18n] Unknown "${t}" ${e} format.`);
}, Fu = on(
  (e) => {
    var t = e, { locale: n, format: r } = t, i = yt(t, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format numbers');
    return r && (i = Nt("number", r)), new Intl.NumberFormat(n, i);
  }
), Gu = on(
  (e) => {
    var t = e, { locale: n, format: r } = t, i = yt(t, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format dates');
    return r ? i = Nt("date", r) : Object.keys(i).length === 0 && (i = Nt("date", "short")), new Intl.DateTimeFormat(n, i);
  }
), qu = on(
  (e) => {
    var t = e, { locale: n, format: r } = t, i = yt(t, ["locale", "format"]);
    if (n == null)
      throw new Error(
        '[svelte-i18n] A "locale" must be set to format time values'
      );
    return r ? i = Nt("time", r) : Object.keys(i).length === 0 && (i = Nt("time", "short")), new Intl.DateTimeFormat(n, i);
  }
), ju = (e = {}) => {
  var t = e, {
    locale: n = nt()
  } = t, r = yt(t, [
    "locale"
  ]);
  return Fu(dr({ locale: n }, r));
}, Vu = (e = {}) => {
  var t = e, {
    locale: n = nt()
  } = t, r = yt(t, [
    "locale"
  ]);
  return Gu(dr({ locale: n }, r));
}, zu = (e = {}) => {
  var t = e, {
    locale: n = nt()
  } = t, r = yt(t, [
    "locale"
  ]);
  return qu(dr({ locale: n }, r));
}, Xu = on(
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  (e, t = nt()) => new bu(e, t, pt().formats, {
    ignoreTag: pt().ignoreTag
  })
), Wu = (e, t = {}) => {
  var n, r, i, s;
  let l = t;
  typeof e == "object" && (l = e, e = l.id);
  const {
    values: a,
    locale: o = nt(),
    default: u
  } = l;
  if (o == null)
    throw new Error(
      "[svelte-i18n] Cannot format a message without first setting the initial locale."
    );
  let f = cs(e, o);
  if (!f)
    f = (s = (i = (r = (n = pt()).handleMissingMessage) == null ? void 0 : r.call(n, { locale: o, id: e, defaultValue: u })) != null ? i : u) != null ? s : e;
  else if (typeof f != "string")
    return console.warn(
      `[svelte-i18n] Message with id "${e}" must be of type "string", found: "${typeof f}". Gettin its value through the "$format" method is deprecated; use the "json" method instead.`
    ), f;
  if (!a)
    return f;
  let c = f;
  try {
    c = Xu(f, o).format(a);
  } catch (h) {
    h instanceof Error && console.warn(
      `[svelte-i18n] Message "${e}" has syntax error:`,
      h.message
    );
  }
  return c;
}, Zu = (e, t) => zu(t).format(e), Ju = (e, t) => Vu(t).format(e), Qu = (e, t) => ju(t).format(e), Yu = (e, t = nt()) => cs(e, t);
vt([Ot, Lt], () => Wu);
vt([Ot], () => Zu);
vt([Ot], () => Ju);
vt([Ot], () => Qu);
vt([Ot, Lt], () => Yu);
const {
  SvelteComponent: Ku,
  append: ne,
  attr: We,
  detach: gs,
  element: Ze,
  init: $u,
  insert: bs,
  noop: $r,
  safe_not_equal: ef,
  set_data: Kt,
  set_style: Nn,
  space: $n,
  text: at,
  toggle_class: ei
} = window.__gradio__svelte__internal, { onMount: tf, createEventDispatcher: nf, getContext: rf } = window.__gradio__svelte__internal;
function ti(e) {
  let t, n, r, i, s = Ht(
    /*file_to_display*/
    e[2]
  ) + "", l, a, o, u, f = (
    /*file_to_display*/
    e[2].orig_name + ""
  ), c;
  return {
    c() {
      t = Ze("div"), n = Ze("span"), r = Ze("div"), i = Ze("progress"), l = at(s), o = $n(), u = Ze("span"), c = at(f), Nn(i, "visibility", "hidden"), Nn(i, "height", "0"), Nn(i, "width", "0"), i.value = a = Ht(
        /*file_to_display*/
        e[2]
      ), We(i, "max", "100"), We(i, "class", "svelte-12ckl9l"), We(r, "class", "progress-bar svelte-12ckl9l"), We(u, "class", "file-name svelte-12ckl9l"), We(t, "class", "file svelte-12ckl9l");
    },
    m(h, _) {
      bs(h, t, _), ne(t, n), ne(n, r), ne(r, i), ne(i, l), ne(t, o), ne(t, u), ne(u, c);
    },
    p(h, _) {
      _ & /*file_to_display*/
      4 && s !== (s = Ht(
        /*file_to_display*/
        h[2]
      ) + "") && Kt(l, s), _ & /*file_to_display*/
      4 && a !== (a = Ht(
        /*file_to_display*/
        h[2]
      )) && (i.value = a), _ & /*file_to_display*/
      4 && f !== (f = /*file_to_display*/
      h[2].orig_name + "") && Kt(c, f);
    },
    d(h) {
      h && gs(t);
    }
  };
}
function sf(e) {
  let t, n, r, i = (
    /*files_with_progress*/
    e[0].length + ""
  ), s, l, a = (
    /*files_with_progress*/
    e[0].length > 1 ? "files" : "file"
  ), o, u, f, c = (
    /*file_to_display*/
    e[2] && ti(e)
  );
  return {
    c() {
      t = Ze("div"), n = Ze("span"), r = at("Uploading "), s = at(i), l = $n(), o = at(a), u = at("..."), f = $n(), c && c.c(), We(n, "class", "uploading svelte-12ckl9l"), We(t, "class", "wrap svelte-12ckl9l"), ei(
        t,
        "progress",
        /*progress*/
        e[1]
      );
    },
    m(h, _) {
      bs(h, t, _), ne(t, n), ne(n, r), ne(n, s), ne(n, l), ne(n, o), ne(n, u), ne(t, f), c && c.m(t, null);
    },
    p(h, [_]) {
      _ & /*files_with_progress*/
      1 && i !== (i = /*files_with_progress*/
      h[0].length + "") && Kt(s, i), _ & /*files_with_progress*/
      1 && a !== (a = /*files_with_progress*/
      h[0].length > 1 ? "files" : "file") && Kt(o, a), /*file_to_display*/
      h[2] ? c ? c.p(h, _) : (c = ti(h), c.c(), c.m(t, null)) : c && (c.d(1), c = null), _ & /*progress*/
      2 && ei(
        t,
        "progress",
        /*progress*/
        h[1]
      );
    },
    i: $r,
    o: $r,
    d(h) {
      h && gs(t), c && c.d();
    }
  };
}
function Ht(e) {
  return e.progress * 100 / (e.size || 0) || 0;
}
function lf(e) {
  let t = 0;
  return e.forEach((n) => {
    t += Ht(n);
  }), document.documentElement.style.setProperty("--upload-progress-width", (t / e.length).toFixed(2) + "%"), t / e.length;
}
function of(e, t, n) {
  let { upload_id: r } = t, { root: i } = t, { files: s } = t, l, a = !1, o, u, f = s.map((d) => ({ ...d, progress: 0 }));
  const c = nf();
  function h(d, p) {
    n(0, f = f.map((y) => (y.orig_name === d && (y.progress += p), y)));
  }
  const _ = rf("EventSource_factory");
  return tf(() => {
    l = _(new URL(`${i}/upload_progress?upload_id=${r}`)), l.onmessage = async function(d) {
      const p = JSON.parse(d.data);
      a || n(1, a = !0), p.msg === "done" ? (l.close(), c("done")) : (n(6, o = p), h(p.orig_name, p.chunk_size));
    };
  }), e.$$set = (d) => {
    "upload_id" in d && n(3, r = d.upload_id), "root" in d && n(4, i = d.root), "files" in d && n(5, s = d.files);
  }, e.$$.update = () => {
    e.$$.dirty & /*files_with_progress*/
    1 && lf(f), e.$$.dirty & /*current_file_upload, files_with_progress*/
    65 && n(2, u = o || f[0]);
  }, [
    f,
    a,
    u,
    r,
    i,
    s,
    o
  ];
}
class af extends Ku {
  constructor(t) {
    super(), $u(this, t, of, sf, ef, { upload_id: 3, root: 4, files: 5 });
  }
}
const {
  SvelteComponent: uf,
  append: ni,
  attr: Y,
  binding_callbacks: ff,
  bubble: Ve,
  check_outros: vs,
  create_component: cf,
  create_slot: ys,
  destroy_component: hf,
  detach: an,
  element: er,
  empty: ws,
  get_all_dirty_from_scope: Es,
  get_slot_changes: Ss,
  group_outros: Ts,
  init: _f,
  insert: un,
  listen: se,
  mount_component: df,
  prevent_default: ze,
  run_all: mf,
  safe_not_equal: pf,
  set_style: As,
  space: gf,
  stop_propagation: Xe,
  toggle_class: K,
  transition_in: Fe,
  transition_out: Ke,
  update_slot_base: Bs
} = window.__gradio__svelte__internal, { createEventDispatcher: bf, tick: vf, getContext: yf } = window.__gradio__svelte__internal;
function wf(e) {
  let t, n, r, i, s, l, a, o, u, f;
  const c = (
    /*#slots*/
    e[22].default
  ), h = ys(
    c,
    e,
    /*$$scope*/
    e[21],
    null
  );
  return {
    c() {
      t = er("button"), h && h.c(), n = gf(), r = er("input"), Y(r, "aria-label", "file upload"), Y(r, "data-testid", "file-upload"), Y(r, "type", "file"), Y(
        r,
        "accept",
        /*accept_file_types*/
        e[12]
      ), r.multiple = i = /*file_count*/
      e[5] === "multiple" || void 0, Y(r, "webkitdirectory", s = /*file_count*/
      e[5] === "directory" || void 0), Y(r, "mozdirectory", l = /*file_count*/
      e[5] === "directory" || void 0), Y(r, "class", "svelte-1aq8tno"), Y(t, "tabindex", a = /*hidden*/
      e[7] ? -1 : 0), Y(t, "class", "svelte-1aq8tno"), K(
        t,
        "hidden",
        /*hidden*/
        e[7]
      ), K(
        t,
        "center",
        /*center*/
        e[3]
      ), K(
        t,
        "boundedheight",
        /*boundedheight*/
        e[2]
      ), K(
        t,
        "flex",
        /*flex*/
        e[4]
      ), As(t, "height", "100%");
    },
    m(_, d) {
      un(_, t, d), h && h.m(t, null), ni(t, n), ni(t, r), e[30](r), o = !0, u || (f = [
        se(
          r,
          "change",
          /*load_files_from_upload*/
          e[15]
        ),
        se(t, "drag", Xe(ze(
          /*drag_handler*/
          e[23]
        ))),
        se(t, "dragstart", Xe(ze(
          /*dragstart_handler*/
          e[24]
        ))),
        se(t, "dragend", Xe(ze(
          /*dragend_handler*/
          e[25]
        ))),
        se(t, "dragover", Xe(ze(
          /*dragover_handler*/
          e[26]
        ))),
        se(t, "dragenter", Xe(ze(
          /*dragenter_handler*/
          e[27]
        ))),
        se(t, "dragleave", Xe(ze(
          /*dragleave_handler*/
          e[28]
        ))),
        se(t, "drop", Xe(ze(
          /*drop_handler*/
          e[29]
        ))),
        se(
          t,
          "click",
          /*open_file_upload*/
          e[9]
        ),
        se(
          t,
          "drop",
          /*loadFilesFromDrop*/
          e[16]
        ),
        se(
          t,
          "dragenter",
          /*updateDragging*/
          e[14]
        ),
        se(
          t,
          "dragleave",
          /*updateDragging*/
          e[14]
        )
      ], u = !0);
    },
    p(_, d) {
      h && h.p && (!o || d[0] & /*$$scope*/
      2097152) && Bs(
        h,
        c,
        _,
        /*$$scope*/
        _[21],
        o ? Ss(
          c,
          /*$$scope*/
          _[21],
          d,
          null
        ) : Es(
          /*$$scope*/
          _[21]
        ),
        null
      ), (!o || d[0] & /*accept_file_types*/
      4096) && Y(
        r,
        "accept",
        /*accept_file_types*/
        _[12]
      ), (!o || d[0] & /*file_count*/
      32 && i !== (i = /*file_count*/
      _[5] === "multiple" || void 0)) && (r.multiple = i), (!o || d[0] & /*file_count*/
      32 && s !== (s = /*file_count*/
      _[5] === "directory" || void 0)) && Y(r, "webkitdirectory", s), (!o || d[0] & /*file_count*/
      32 && l !== (l = /*file_count*/
      _[5] === "directory" || void 0)) && Y(r, "mozdirectory", l), (!o || d[0] & /*hidden*/
      128 && a !== (a = /*hidden*/
      _[7] ? -1 : 0)) && Y(t, "tabindex", a), (!o || d[0] & /*hidden*/
      128) && K(
        t,
        "hidden",
        /*hidden*/
        _[7]
      ), (!o || d[0] & /*center*/
      8) && K(
        t,
        "center",
        /*center*/
        _[3]
      ), (!o || d[0] & /*boundedheight*/
      4) && K(
        t,
        "boundedheight",
        /*boundedheight*/
        _[2]
      ), (!o || d[0] & /*flex*/
      16) && K(
        t,
        "flex",
        /*flex*/
        _[4]
      );
    },
    i(_) {
      o || (Fe(h, _), o = !0);
    },
    o(_) {
      Ke(h, _), o = !1;
    },
    d(_) {
      _ && an(t), h && h.d(_), e[30](null), u = !1, mf(f);
    }
  };
}
function Ef(e) {
  let t, n, r = !/*hidden*/
  e[7] && ri(e);
  return {
    c() {
      r && r.c(), t = ws();
    },
    m(i, s) {
      r && r.m(i, s), un(i, t, s), n = !0;
    },
    p(i, s) {
      /*hidden*/
      i[7] ? r && (Ts(), Ke(r, 1, 1, () => {
        r = null;
      }), vs()) : r ? (r.p(i, s), s[0] & /*hidden*/
      128 && Fe(r, 1)) : (r = ri(i), r.c(), Fe(r, 1), r.m(t.parentNode, t));
    },
    i(i) {
      n || (Fe(r), n = !0);
    },
    o(i) {
      Ke(r), n = !1;
    },
    d(i) {
      i && an(t), r && r.d(i);
    }
  };
}
function Sf(e) {
  let t, n, r, i, s;
  const l = (
    /*#slots*/
    e[22].default
  ), a = ys(
    l,
    e,
    /*$$scope*/
    e[21],
    null
  );
  return {
    c() {
      t = er("button"), a && a.c(), Y(t, "tabindex", n = /*hidden*/
      e[7] ? -1 : 0), Y(t, "class", "svelte-1aq8tno"), K(
        t,
        "hidden",
        /*hidden*/
        e[7]
      ), K(
        t,
        "center",
        /*center*/
        e[3]
      ), K(
        t,
        "boundedheight",
        /*boundedheight*/
        e[2]
      ), K(
        t,
        "flex",
        /*flex*/
        e[4]
      ), As(t, "height", "100%");
    },
    m(o, u) {
      un(o, t, u), a && a.m(t, null), r = !0, i || (s = se(
        t,
        "click",
        /*paste_clipboard*/
        e[8]
      ), i = !0);
    },
    p(o, u) {
      a && a.p && (!r || u[0] & /*$$scope*/
      2097152) && Bs(
        a,
        l,
        o,
        /*$$scope*/
        o[21],
        r ? Ss(
          l,
          /*$$scope*/
          o[21],
          u,
          null
        ) : Es(
          /*$$scope*/
          o[21]
        ),
        null
      ), (!r || u[0] & /*hidden*/
      128 && n !== (n = /*hidden*/
      o[7] ? -1 : 0)) && Y(t, "tabindex", n), (!r || u[0] & /*hidden*/
      128) && K(
        t,
        "hidden",
        /*hidden*/
        o[7]
      ), (!r || u[0] & /*center*/
      8) && K(
        t,
        "center",
        /*center*/
        o[3]
      ), (!r || u[0] & /*boundedheight*/
      4) && K(
        t,
        "boundedheight",
        /*boundedheight*/
        o[2]
      ), (!r || u[0] & /*flex*/
      16) && K(
        t,
        "flex",
        /*flex*/
        o[4]
      );
    },
    i(o) {
      r || (Fe(a, o), r = !0);
    },
    o(o) {
      Ke(a, o), r = !1;
    },
    d(o) {
      o && an(t), a && a.d(o), i = !1, s();
    }
  };
}
function ri(e) {
  let t, n;
  return t = new af({
    props: {
      root: (
        /*root*/
        e[6]
      ),
      upload_id: (
        /*upload_id*/
        e[10]
      ),
      files: (
        /*file_data*/
        e[11]
      )
    }
  }), {
    c() {
      cf(t.$$.fragment);
    },
    m(r, i) {
      df(t, r, i), n = !0;
    },
    p(r, i) {
      const s = {};
      i[0] & /*root*/
      64 && (s.root = /*root*/
      r[6]), i[0] & /*upload_id*/
      1024 && (s.upload_id = /*upload_id*/
      r[10]), i[0] & /*file_data*/
      2048 && (s.files = /*file_data*/
      r[11]), t.$set(s);
    },
    i(r) {
      n || (Fe(t.$$.fragment, r), n = !0);
    },
    o(r) {
      Ke(t.$$.fragment, r), n = !1;
    },
    d(r) {
      hf(t, r);
    }
  };
}
function Tf(e) {
  let t, n, r, i;
  const s = [Sf, Ef, wf], l = [];
  function a(o, u) {
    return (
      /*filetype*/
      o[0] === "clipboard" ? 0 : (
        /*uploading*/
        o[1] ? 1 : 2
      )
    );
  }
  return t = a(e), n = l[t] = s[t](e), {
    c() {
      n.c(), r = ws();
    },
    m(o, u) {
      l[t].m(o, u), un(o, r, u), i = !0;
    },
    p(o, u) {
      let f = t;
      t = a(o), t === f ? l[t].p(o, u) : (Ts(), Ke(l[f], 1, 1, () => {
        l[f] = null;
      }), vs(), n = l[t], n ? n.p(o, u) : (n = l[t] = s[t](o), n.c()), Fe(n, 1), n.m(r.parentNode, r));
    },
    i(o) {
      i || (Fe(n), i = !0);
    },
    o(o) {
      Ke(n), i = !1;
    },
    d(o) {
      o && an(r), l[t].d(o);
    }
  };
}
function ii(e) {
  let t, n = e[0], r = 1;
  for (; r < e.length; ) {
    const i = e[r], s = e[r + 1];
    if (r += 2, (i === "optionalAccess" || i === "optionalCall") && n == null)
      return;
    i === "access" || i === "optionalAccess" ? (t = n, n = s(n)) : (i === "call" || i === "optionalCall") && (n = s((...l) => n.call(t, ...l)), t = void 0);
  }
  return n;
}
function Af(e, t) {
  return !e || e === "*" || e === "file/*" ? !0 : (typeof e == "string" && e.endsWith("/*") && (e = e.split(",")), Array.isArray(e) ? e.includes(t) || e.some((n) => {
    const [r] = n.split("/");
    return n.endsWith("/*") && t.startsWith(r + "/");
  }) : e === t);
}
function Bf(e, t, n) {
  let { $$slots: r = {}, $$scope: i } = t, { filetype: s = null } = t, { dragging: l = !1 } = t, { boundedheight: a = !0 } = t, { center: o = !0 } = t, { flex: u = !0 } = t, { file_count: f = "single" } = t, { disable_click: c = !1 } = t, { root: h } = t, { hidden: _ = !1 } = t, { format: d = "file" } = t, { uploading: p = !1 } = t, y, v, E;
  const g = yf("upload_files");
  let A;
  const T = bf();
  function w() {
    n(17, l = !l);
  }
  function j() {
    navigator.clipboard.read().then(async (m) => {
      for (let N = 0; N < m.length; N++) {
        const b = m[N].types.find((M) => M.startsWith("image/"));
        if (b) {
          m[N].getType(b).then(async (M) => {
            const S = new File([M], `clipboard.${b.replace("image/", "")}`);
            await Z([S]);
          });
          break;
        }
      }
    });
  }
  function B() {
    c || (n(13, A.value = "", A), A.click());
  }
  async function H(m) {
    await vf(), n(10, y = Math.random().toString(36).substring(2, 15)), n(1, p = !0);
    const N = await xo(m, h, y, g);
    return T("load", f === "single" ? ii([N, "optionalAccess", (b) => b[0]]) : N), n(1, p = !1), N || [];
  }
  async function Z(m) {
    if (!m.length)
      return;
    let N = m.map((b) => new File([b], b.name));
    return n(11, v = await Fo(N)), await H(v);
  }
  async function le(m) {
    const N = m.target;
    if (N.files)
      if (d != "blob")
        await Z(Array.from(N.files));
      else {
        if (f === "single") {
          T("load", N.files[0]);
          return;
        }
        T("load", N.files);
      }
  }
  async function Ge(m) {
    if (n(17, l = !1), !ii([m, "access", (b) => b.dataTransfer, "optionalAccess", (b) => b.files]))
      return;
    const N = Array.from(m.dataTransfer.files).filter((b) => {
      const M = "." + b.name.split(".").pop();
      return b.type && Af(s, b.type) || (M && Array.isArray(s) ? s.includes(M) : M === s) ? !0 : (T("error", `Invalid file type only ${s} allowed.`), !1);
    });
    await Z(N);
  }
  function $(m) {
    Ve.call(this, e, m);
  }
  function Ae(m) {
    Ve.call(this, e, m);
  }
  function oe(m) {
    Ve.call(this, e, m);
  }
  function qe(m) {
    Ve.call(this, e, m);
  }
  function Et(m) {
    Ve.call(this, e, m);
  }
  function Le(m) {
    Ve.call(this, e, m);
  }
  function rt(m) {
    Ve.call(this, e, m);
  }
  function Be(m) {
    ff[m ? "unshift" : "push"](() => {
      A = m, n(13, A);
    });
  }
  return e.$$set = (m) => {
    "filetype" in m && n(0, s = m.filetype), "dragging" in m && n(17, l = m.dragging), "boundedheight" in m && n(2, a = m.boundedheight), "center" in m && n(3, o = m.center), "flex" in m && n(4, u = m.flex), "file_count" in m && n(5, f = m.file_count), "disable_click" in m && n(18, c = m.disable_click), "root" in m && n(6, h = m.root), "hidden" in m && n(7, _ = m.hidden), "format" in m && n(19, d = m.format), "uploading" in m && n(1, p = m.uploading), "$$scope" in m && n(21, i = m.$$scope);
  }, e.$$.update = () => {
    e.$$.dirty[0] & /*filetype*/
    1 && (s == null || typeof s == "string" ? n(12, E = s) : (n(0, s = s.map((m) => m.startsWith(".") ? m : m + "/*")), n(12, E = s.join(", "))));
  }, [
    s,
    p,
    a,
    o,
    u,
    f,
    h,
    _,
    j,
    B,
    y,
    v,
    E,
    A,
    w,
    le,
    Ge,
    l,
    c,
    d,
    Z,
    i,
    r,
    $,
    Ae,
    oe,
    qe,
    Et,
    Le,
    rt,
    Be
  ];
}
class Hf extends uf {
  constructor(t) {
    super(), _f(
      this,
      t,
      Bf,
      Tf,
      pf,
      {
        filetype: 0,
        dragging: 17,
        boundedheight: 2,
        center: 3,
        flex: 4,
        file_count: 5,
        disable_click: 18,
        root: 6,
        hidden: 7,
        format: 19,
        uploading: 1,
        paste_clipboard: 8,
        open_file_upload: 9,
        load_files: 20
      },
      null,
      [-1, -1]
    );
  }
  get paste_clipboard() {
    return this.$$.ctx[8];
  }
  get open_file_upload() {
    return this.$$.ctx[9];
  }
  get load_files() {
    return this.$$.ctx[20];
  }
}
const {
  SvelteComponent: kf,
  attr: Cf,
  create_component: Pf,
  destroy_component: Nf,
  detach: If,
  element: Lf,
  init: Of,
  insert: Mf,
  mount_component: Df,
  noop: Rf,
  safe_not_equal: Uf,
  transition_in: xf,
  transition_out: Ff
} = window.__gradio__svelte__internal, { createEventDispatcher: Gf } = window.__gradio__svelte__internal;
function qf(e) {
  let t, n, r;
  return n = new Cl({
    props: { Icon: $l, label: "Remove Image" }
  }), n.$on(
    "click",
    /*click_handler*/
    e[1]
  ), {
    c() {
      t = Lf("div"), Pf(n.$$.fragment), Cf(t, "class", "svelte-1g74h68");
    },
    m(i, s) {
      Mf(i, t, s), Df(n, t, null), r = !0;
    },
    p: Rf,
    i(i) {
      r || (xf(n.$$.fragment, i), r = !0);
    },
    o(i) {
      Ff(n.$$.fragment, i), r = !1;
    },
    d(i) {
      i && If(t), Nf(n);
    }
  };
}
function jf(e) {
  const t = Gf();
  return [t, (r) => {
    t("remove_image"), r.stopPropagation();
  }];
}
class Vf extends kf {
  constructor(t) {
    super(), Of(this, t, jf, qf, Uf, {});
  }
}
const {
  SvelteComponent: zf,
  add_flush_callback: si,
  append: tr,
  attr: ht,
  bind: li,
  binding_callbacks: nr,
  bubble: Xf,
  check_outros: rr,
  create_component: mr,
  create_slot: Wf,
  destroy_component: pr,
  detach: $t,
  element: en,
  empty: Zf,
  get_all_dirty_from_scope: Jf,
  get_slot_changes: Qf,
  group_outros: ir,
  init: Yf,
  insert: tn,
  mount_component: gr,
  noop: sr,
  safe_not_equal: Kf,
  space: oi,
  transition_in: de,
  transition_out: Ee,
  update_slot_base: $f
} = window.__gradio__svelte__internal, { createEventDispatcher: ec } = window.__gradio__svelte__internal;
function ai(e) {
  let t, n;
  return t = new Vf({}), t.$on(
    "remove_image",
    /*remove_image_handler*/
    e[11]
  ), {
    c() {
      mr(t.$$.fragment);
    },
    m(r, i) {
      gr(t, r, i), n = !0;
    },
    p: sr,
    i(r) {
      n || (de(t.$$.fragment, r), n = !0);
    },
    o(r) {
      Ee(t.$$.fragment, r), n = !1;
    },
    d(r) {
      pr(t, r);
    }
  };
}
function tc(e) {
  let t, n;
  return {
    c() {
      t = en("div"), n = en("div"), ht(n, "id", "fasta_content"), ht(n, "class", "svelte-9fc1fs"), ht(t, "class", "image-frame svelte-9fc1fs");
    },
    m(r, i) {
      tn(r, t, i), tr(t, n), n.innerHTML = /*fasta_text*/
      e[7];
    },
    p(r, i) {
      i & /*fasta_text*/
      128 && (n.innerHTML = /*fasta_text*/
      r[7]);
    },
    i: sr,
    o: sr,
    d(r) {
      r && $t(t);
    }
  };
}
function nc(e) {
  let t, n, r, i;
  function s(o) {
    e[13](o);
  }
  function l(o) {
    e[14](o);
  }
  let a = {
    hidden: (
      /*value*/
      e[0] !== null
    ),
    filetype: "text/plain",
    root: (
      /*root*/
      e[3]
    ),
    $$slots: { default: [rc] },
    $$scope: { ctx: e }
  };
  return (
    /*uploading*/
    e[4] !== void 0 && (a.uploading = /*uploading*/
    e[4]), /*dragging*/
    e[5] !== void 0 && (a.dragging = /*dragging*/
    e[5]), t = new Hf({ props: a }), e[12](t), nr.push(() => li(t, "uploading", s)), nr.push(() => li(t, "dragging", l)), t.$on(
      "load",
      /*handle_upload*/
      e[8]
    ), t.$on(
      "error",
      /*error_handler*/
      e[15]
    ), {
      c() {
        mr(t.$$.fragment);
      },
      m(o, u) {
        gr(t, o, u), i = !0;
      },
      p(o, u) {
        const f = {};
        u & /*value*/
        1 && (f.hidden = /*value*/
        o[0] !== null), u & /*root*/
        8 && (f.root = /*root*/
        o[3]), u & /*$$scope, value*/
        65537 && (f.$$scope = { dirty: u, ctx: o }), !n && u & /*uploading*/
        16 && (n = !0, f.uploading = /*uploading*/
        o[4], si(() => n = !1)), !r && u & /*dragging*/
        32 && (r = !0, f.dragging = /*dragging*/
        o[5], si(() => r = !1)), t.$set(f);
      },
      i(o) {
        i || (de(t.$$.fragment, o), i = !0);
      },
      o(o) {
        Ee(t.$$.fragment, o), i = !1;
      },
      d(o) {
        e[12](null), pr(t, o);
      }
    }
  );
}
function ui(e) {
  let t;
  const n = (
    /*#slots*/
    e[10].default
  ), r = Wf(
    n,
    e,
    /*$$scope*/
    e[16],
    null
  );
  return {
    c() {
      r && r.c();
    },
    m(i, s) {
      r && r.m(i, s), t = !0;
    },
    p(i, s) {
      r && r.p && (!t || s & /*$$scope*/
      65536) && $f(
        r,
        n,
        i,
        /*$$scope*/
        i[16],
        t ? Qf(
          n,
          /*$$scope*/
          i[16],
          s,
          null
        ) : Jf(
          /*$$scope*/
          i[16]
        ),
        null
      );
    },
    i(i) {
      t || (de(r, i), t = !0);
    },
    o(i) {
      Ee(r, i), t = !1;
    },
    d(i) {
      r && r.d(i);
    }
  };
}
function rc(e) {
  let t, n, r = (
    /*value*/
    e[0] === null && ui(e)
  );
  return {
    c() {
      r && r.c(), t = Zf();
    },
    m(i, s) {
      r && r.m(i, s), tn(i, t, s), n = !0;
    },
    p(i, s) {
      /*value*/
      i[0] === null ? r ? (r.p(i, s), s & /*value*/
      1 && de(r, 1)) : (r = ui(i), r.c(), de(r, 1), r.m(t.parentNode, t)) : r && (ir(), Ee(r, 1, 1, () => {
        r = null;
      }), rr());
    },
    i(i) {
      n || (de(r), n = !0);
    },
    o(i) {
      Ee(r), n = !1;
    },
    d(i) {
      i && $t(t), r && r.d(i);
    }
  };
}
function ic(e) {
  var _;
  let t, n, r, i, s, l, a, o;
  t = new Mi({
    props: {
      show_label: (
        /*show_label*/
        e[2]
      ),
      Icon: or,
      label: (
        /*label*/
        e[1] || "Image"
      )
    }
  });
  let u = (
    /*value*/
    ((_ = e[0]) == null ? void 0 : _.url) && ai(e)
  );
  const f = [nc, tc], c = [];
  function h(d, p) {
    return (
      /*value*/
      d[0] === null ? 0 : 1
    );
  }
  return l = h(e), a = c[l] = f[l](e), {
    c() {
      mr(t.$$.fragment), n = oi(), r = en("div"), u && u.c(), i = oi(), s = en("div"), a.c(), ht(s, "class", "upload-container svelte-9fc1fs"), ht(r, "data-testid", "image"), ht(r, "class", "image-container svelte-9fc1fs");
    },
    m(d, p) {
      gr(t, d, p), tn(d, n, p), tn(d, r, p), u && u.m(r, null), tr(r, i), tr(r, s), c[l].m(s, null), o = !0;
    },
    p(d, [p]) {
      var E;
      const y = {};
      p & /*show_label*/
      4 && (y.show_label = /*show_label*/
      d[2]), p & /*label*/
      2 && (y.label = /*label*/
      d[1] || "Image"), t.$set(y), /*value*/
      (E = d[0]) != null && E.url ? u ? (u.p(d, p), p & /*value*/
      1 && de(u, 1)) : (u = ai(d), u.c(), de(u, 1), u.m(r, i)) : u && (ir(), Ee(u, 1, 1, () => {
        u = null;
      }), rr());
      let v = l;
      l = h(d), l === v ? c[l].p(d, p) : (ir(), Ee(c[v], 1, 1, () => {
        c[v] = null;
      }), rr(), a = c[l], a ? a.p(d, p) : (a = c[l] = f[l](d), a.c()), de(a, 1), a.m(s, null));
    },
    i(d) {
      o || (de(t.$$.fragment, d), de(u), de(a), o = !0);
    },
    o(d) {
      Ee(t.$$.fragment, d), Ee(u), Ee(a), o = !1;
    },
    d(d) {
      d && ($t(n), $t(r)), pr(t, d), u && u.d(), c[l].d();
    }
  };
}
function sc(e, t, n) {
  let { $$slots: r = {}, $$scope: i } = t, { value: s } = t, { label: l = void 0 } = t, { show_label: a } = t, { root: o } = t, u, f = !1, c = "";
  async function h(T) {
    const w = await fetch(T);
    n(7, c = await w.text()), n(7, c = c.replaceAll("G", "<span style='color: green'>G</span>")), n(7, c = c.replaceAll("A", "<span style='color: red'>A</span>")), n(7, c = c.replaceAll("T", "<span style='color: blue'>T</span>")), n(7, c = c.replaceAll("C", "<span style='color: orange'>C</span>")), n(7, c = c.replaceAll(/^(>.*)$/gm, "<span style='color: gray !important'>$1</span>"));
  }
  function _({ detail: T }) {
    n(0, s = Ce(T, o, null)), d("upload"), h(s.url);
  }
  const d = ec();
  let p = !1;
  const y = () => {
    n(0, s = null), d("clear");
  };
  function v(T) {
    nr[T ? "unshift" : "push"](() => {
      u = T, n(6, u);
    });
  }
  function E(T) {
    f = T, n(4, f);
  }
  function g(T) {
    p = T, n(5, p);
  }
  function A(T) {
    Xf.call(this, e, T);
  }
  return e.$$set = (T) => {
    "value" in T && n(0, s = T.value), "label" in T && n(1, l = T.label), "show_label" in T && n(2, a = T.show_label), "root" in T && n(3, o = T.root), "$$scope" in T && n(16, i = T.$$scope);
  }, e.$$.update = () => {
    e.$$.dirty & /*uploading*/
    16 && f && n(0, s = null), e.$$.dirty & /*value, root*/
    9 && s && !s.url && n(0, s = Ce(s, o, null)), e.$$.dirty & /*dragging*/
    32 && d("drag", p);
  }, [
    s,
    l,
    a,
    o,
    f,
    p,
    u,
    c,
    _,
    d,
    r,
    y,
    v,
    E,
    g,
    A,
    i
  ];
}
class lc extends zf {
  constructor(t) {
    super(), Yf(this, t, sc, ic, Kf, {
      value: 0,
      label: 1,
      show_label: 2,
      root: 3
    });
  }
}
function ut(e) {
  let t = ["", "k", "M", "G", "T", "P", "E", "Z"], n = 0;
  for (; e > 1e3 && n < t.length - 1; )
    e /= 1e3, n++;
  let r = t[n];
  return (Number.isInteger(e) ? e : e.toFixed(1)) + r;
}
const {
  SvelteComponent: oc,
  append: ve,
  attr: O,
  component_subscribe: fi,
  detach: ac,
  element: uc,
  init: fc,
  insert: cc,
  noop: ci,
  safe_not_equal: hc,
  set_style: qt,
  svg_element: ye,
  toggle_class: hi
} = window.__gradio__svelte__internal, { onMount: _c } = window.__gradio__svelte__internal;
function dc(e) {
  let t, n, r, i, s, l, a, o, u, f, c, h;
  return {
    c() {
      t = uc("div"), n = ye("svg"), r = ye("g"), i = ye("path"), s = ye("path"), l = ye("path"), a = ye("path"), o = ye("g"), u = ye("path"), f = ye("path"), c = ye("path"), h = ye("path"), O(i, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), O(i, "fill", "#FF7C00"), O(i, "fill-opacity", "0.4"), O(i, "class", "svelte-43sxxs"), O(s, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), O(s, "fill", "#FF7C00"), O(s, "class", "svelte-43sxxs"), O(l, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), O(l, "fill", "#FF7C00"), O(l, "fill-opacity", "0.4"), O(l, "class", "svelte-43sxxs"), O(a, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), O(a, "fill", "#FF7C00"), O(a, "class", "svelte-43sxxs"), qt(r, "transform", "translate(" + /*$top*/
      e[1][0] + "px, " + /*$top*/
      e[1][1] + "px)"), O(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), O(u, "fill", "#FF7C00"), O(u, "fill-opacity", "0.4"), O(u, "class", "svelte-43sxxs"), O(f, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), O(f, "fill", "#FF7C00"), O(f, "class", "svelte-43sxxs"), O(c, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), O(c, "fill", "#FF7C00"), O(c, "fill-opacity", "0.4"), O(c, "class", "svelte-43sxxs"), O(h, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), O(h, "fill", "#FF7C00"), O(h, "class", "svelte-43sxxs"), qt(o, "transform", "translate(" + /*$bottom*/
      e[2][0] + "px, " + /*$bottom*/
      e[2][1] + "px)"), O(n, "viewBox", "-1200 -1200 3000 3000"), O(n, "fill", "none"), O(n, "xmlns", "http://www.w3.org/2000/svg"), O(n, "class", "svelte-43sxxs"), O(t, "class", "svelte-43sxxs"), hi(
        t,
        "margin",
        /*margin*/
        e[0]
      );
    },
    m(_, d) {
      cc(_, t, d), ve(t, n), ve(n, r), ve(r, i), ve(r, s), ve(r, l), ve(r, a), ve(n, o), ve(o, u), ve(o, f), ve(o, c), ve(o, h);
    },
    p(_, [d]) {
      d & /*$top*/
      2 && qt(r, "transform", "translate(" + /*$top*/
      _[1][0] + "px, " + /*$top*/
      _[1][1] + "px)"), d & /*$bottom*/
      4 && qt(o, "transform", "translate(" + /*$bottom*/
      _[2][0] + "px, " + /*$bottom*/
      _[2][1] + "px)"), d & /*margin*/
      1 && hi(
        t,
        "margin",
        /*margin*/
        _[0]
      );
    },
    i: ci,
    o: ci,
    d(_) {
      _ && ac(t);
    }
  };
}
function mc(e, t, n) {
  let r, i, { margin: s = !0 } = t;
  const l = xr([0, 0]);
  fi(e, l, (h) => n(1, r = h));
  const a = xr([0, 0]);
  fi(e, a, (h) => n(2, i = h));
  let o;
  async function u() {
    await Promise.all([l.set([125, 140]), a.set([-125, -140])]), await Promise.all([l.set([-125, 140]), a.set([125, -140])]), await Promise.all([l.set([-125, 0]), a.set([125, -0])]), await Promise.all([l.set([125, 0]), a.set([-125, 0])]);
  }
  async function f() {
    await u(), o || f();
  }
  async function c() {
    await Promise.all([l.set([125, 0]), a.set([-125, 0])]), f();
  }
  return _c(() => (c(), () => o = !0)), e.$$set = (h) => {
    "margin" in h && n(0, s = h.margin);
  }, [s, r, i, l, a];
}
class pc extends oc {
  constructor(t) {
    super(), fc(this, t, mc, dc, hc, { margin: 0 });
  }
}
const {
  SvelteComponent: gc,
  append: Qe,
  attr: Se,
  binding_callbacks: _i,
  check_outros: Hs,
  create_component: bc,
  create_slot: vc,
  destroy_component: yc,
  destroy_each: ks,
  detach: k,
  element: Pe,
  empty: wt,
  ensure_array_like: nn,
  get_all_dirty_from_scope: wc,
  get_slot_changes: Ec,
  group_outros: Cs,
  init: Sc,
  insert: C,
  mount_component: Tc,
  noop: lr,
  safe_not_equal: Ac,
  set_data: me,
  set_style: xe,
  space: Te,
  text: q,
  toggle_class: _e,
  transition_in: gt,
  transition_out: bt,
  update_slot_base: Bc
} = window.__gradio__svelte__internal, { tick: Hc } = window.__gradio__svelte__internal, { onDestroy: kc } = window.__gradio__svelte__internal, Cc = (e) => ({}), di = (e) => ({});
function mi(e, t, n) {
  const r = e.slice();
  return r[38] = t[n], r[40] = n, r;
}
function pi(e, t, n) {
  const r = e.slice();
  return r[38] = t[n], r;
}
function Pc(e) {
  let t, n = (
    /*i18n*/
    e[1]("common.error") + ""
  ), r, i, s;
  const l = (
    /*#slots*/
    e[29].error
  ), a = vc(
    l,
    e,
    /*$$scope*/
    e[28],
    di
  );
  return {
    c() {
      t = Pe("span"), r = q(n), i = Te(), a && a.c(), Se(t, "class", "error svelte-1txqlrd");
    },
    m(o, u) {
      C(o, t, u), Qe(t, r), C(o, i, u), a && a.m(o, u), s = !0;
    },
    p(o, u) {
      (!s || u[0] & /*i18n*/
      2) && n !== (n = /*i18n*/
      o[1]("common.error") + "") && me(r, n), a && a.p && (!s || u[0] & /*$$scope*/
      268435456) && Bc(
        a,
        l,
        o,
        /*$$scope*/
        o[28],
        s ? Ec(
          l,
          /*$$scope*/
          o[28],
          u,
          Cc
        ) : wc(
          /*$$scope*/
          o[28]
        ),
        di
      );
    },
    i(o) {
      s || (gt(a, o), s = !0);
    },
    o(o) {
      bt(a, o), s = !1;
    },
    d(o) {
      o && (k(t), k(i)), a && a.d(o);
    }
  };
}
function Nc(e) {
  let t, n, r, i, s, l, a, o, u, f = (
    /*variant*/
    e[8] === "default" && /*show_eta_bar*/
    e[18] && /*show_progress*/
    e[6] === "full" && gi(e)
  );
  function c(g, A) {
    if (
      /*progress*/
      g[7]
    )
      return Oc;
    if (
      /*queue_position*/
      g[2] !== null && /*queue_size*/
      g[3] !== void 0 && /*queue_position*/
      g[2] >= 0
    )
      return Lc;
    if (
      /*queue_position*/
      g[2] === 0
    )
      return Ic;
  }
  let h = c(e), _ = h && h(e), d = (
    /*timer*/
    e[5] && yi(e)
  );
  const p = [Uc, Rc], y = [];
  function v(g, A) {
    return (
      /*last_progress_level*/
      g[15] != null ? 0 : (
        /*show_progress*/
        g[6] === "full" ? 1 : -1
      )
    );
  }
  ~(s = v(e)) && (l = y[s] = p[s](e));
  let E = !/*timer*/
  e[5] && Hi(e);
  return {
    c() {
      f && f.c(), t = Te(), n = Pe("div"), _ && _.c(), r = Te(), d && d.c(), i = Te(), l && l.c(), a = Te(), E && E.c(), o = wt(), Se(n, "class", "progress-text svelte-1txqlrd"), _e(
        n,
        "meta-text-center",
        /*variant*/
        e[8] === "center"
      ), _e(
        n,
        "meta-text",
        /*variant*/
        e[8] === "default"
      );
    },
    m(g, A) {
      f && f.m(g, A), C(g, t, A), C(g, n, A), _ && _.m(n, null), Qe(n, r), d && d.m(n, null), C(g, i, A), ~s && y[s].m(g, A), C(g, a, A), E && E.m(g, A), C(g, o, A), u = !0;
    },
    p(g, A) {
      /*variant*/
      g[8] === "default" && /*show_eta_bar*/
      g[18] && /*show_progress*/
      g[6] === "full" ? f ? f.p(g, A) : (f = gi(g), f.c(), f.m(t.parentNode, t)) : f && (f.d(1), f = null), h === (h = c(g)) && _ ? _.p(g, A) : (_ && _.d(1), _ = h && h(g), _ && (_.c(), _.m(n, r))), /*timer*/
      g[5] ? d ? d.p(g, A) : (d = yi(g), d.c(), d.m(n, null)) : d && (d.d(1), d = null), (!u || A[0] & /*variant*/
      256) && _e(
        n,
        "meta-text-center",
        /*variant*/
        g[8] === "center"
      ), (!u || A[0] & /*variant*/
      256) && _e(
        n,
        "meta-text",
        /*variant*/
        g[8] === "default"
      );
      let T = s;
      s = v(g), s === T ? ~s && y[s].p(g, A) : (l && (Cs(), bt(y[T], 1, 1, () => {
        y[T] = null;
      }), Hs()), ~s ? (l = y[s], l ? l.p(g, A) : (l = y[s] = p[s](g), l.c()), gt(l, 1), l.m(a.parentNode, a)) : l = null), /*timer*/
      g[5] ? E && (E.d(1), E = null) : E ? E.p(g, A) : (E = Hi(g), E.c(), E.m(o.parentNode, o));
    },
    i(g) {
      u || (gt(l), u = !0);
    },
    o(g) {
      bt(l), u = !1;
    },
    d(g) {
      g && (k(t), k(n), k(i), k(a), k(o)), f && f.d(g), _ && _.d(), d && d.d(), ~s && y[s].d(g), E && E.d(g);
    }
  };
}
function gi(e) {
  let t, n = `translateX(${/*eta_level*/
  (e[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      t = Pe("div"), Se(t, "class", "eta-bar svelte-1txqlrd"), xe(t, "transform", n);
    },
    m(r, i) {
      C(r, t, i);
    },
    p(r, i) {
      i[0] & /*eta_level*/
      131072 && n !== (n = `translateX(${/*eta_level*/
      (r[17] || 0) * 100 - 100}%)`) && xe(t, "transform", n);
    },
    d(r) {
      r && k(t);
    }
  };
}
function Ic(e) {
  let t;
  return {
    c() {
      t = q("processing |");
    },
    m(n, r) {
      C(n, t, r);
    },
    p: lr,
    d(n) {
      n && k(t);
    }
  };
}
function Lc(e) {
  let t, n = (
    /*queue_position*/
    e[2] + 1 + ""
  ), r, i, s, l;
  return {
    c() {
      t = q("queue: "), r = q(n), i = q("/"), s = q(
        /*queue_size*/
        e[3]
      ), l = q(" |");
    },
    m(a, o) {
      C(a, t, o), C(a, r, o), C(a, i, o), C(a, s, o), C(a, l, o);
    },
    p(a, o) {
      o[0] & /*queue_position*/
      4 && n !== (n = /*queue_position*/
      a[2] + 1 + "") && me(r, n), o[0] & /*queue_size*/
      8 && me(
        s,
        /*queue_size*/
        a[3]
      );
    },
    d(a) {
      a && (k(t), k(r), k(i), k(s), k(l));
    }
  };
}
function Oc(e) {
  let t, n = nn(
    /*progress*/
    e[7]
  ), r = [];
  for (let i = 0; i < n.length; i += 1)
    r[i] = vi(pi(e, n, i));
  return {
    c() {
      for (let i = 0; i < r.length; i += 1)
        r[i].c();
      t = wt();
    },
    m(i, s) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(i, s);
      C(i, t, s);
    },
    p(i, s) {
      if (s[0] & /*progress*/
      128) {
        n = nn(
          /*progress*/
          i[7]
        );
        let l;
        for (l = 0; l < n.length; l += 1) {
          const a = pi(i, n, l);
          r[l] ? r[l].p(a, s) : (r[l] = vi(a), r[l].c(), r[l].m(t.parentNode, t));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = n.length;
      }
    },
    d(i) {
      i && k(t), ks(r, i);
    }
  };
}
function bi(e) {
  let t, n = (
    /*p*/
    e[38].unit + ""
  ), r, i, s = " ", l;
  function a(f, c) {
    return (
      /*p*/
      f[38].length != null ? Dc : Mc
    );
  }
  let o = a(e), u = o(e);
  return {
    c() {
      u.c(), t = Te(), r = q(n), i = q(" | "), l = q(s);
    },
    m(f, c) {
      u.m(f, c), C(f, t, c), C(f, r, c), C(f, i, c), C(f, l, c);
    },
    p(f, c) {
      o === (o = a(f)) && u ? u.p(f, c) : (u.d(1), u = o(f), u && (u.c(), u.m(t.parentNode, t))), c[0] & /*progress*/
      128 && n !== (n = /*p*/
      f[38].unit + "") && me(r, n);
    },
    d(f) {
      f && (k(t), k(r), k(i), k(l)), u.d(f);
    }
  };
}
function Mc(e) {
  let t = ut(
    /*p*/
    e[38].index || 0
  ) + "", n;
  return {
    c() {
      n = q(t);
    },
    m(r, i) {
      C(r, n, i);
    },
    p(r, i) {
      i[0] & /*progress*/
      128 && t !== (t = ut(
        /*p*/
        r[38].index || 0
      ) + "") && me(n, t);
    },
    d(r) {
      r && k(n);
    }
  };
}
function Dc(e) {
  let t = ut(
    /*p*/
    e[38].index || 0
  ) + "", n, r, i = ut(
    /*p*/
    e[38].length
  ) + "", s;
  return {
    c() {
      n = q(t), r = q("/"), s = q(i);
    },
    m(l, a) {
      C(l, n, a), C(l, r, a), C(l, s, a);
    },
    p(l, a) {
      a[0] & /*progress*/
      128 && t !== (t = ut(
        /*p*/
        l[38].index || 0
      ) + "") && me(n, t), a[0] & /*progress*/
      128 && i !== (i = ut(
        /*p*/
        l[38].length
      ) + "") && me(s, i);
    },
    d(l) {
      l && (k(n), k(r), k(s));
    }
  };
}
function vi(e) {
  let t, n = (
    /*p*/
    e[38].index != null && bi(e)
  );
  return {
    c() {
      n && n.c(), t = wt();
    },
    m(r, i) {
      n && n.m(r, i), C(r, t, i);
    },
    p(r, i) {
      /*p*/
      r[38].index != null ? n ? n.p(r, i) : (n = bi(r), n.c(), n.m(t.parentNode, t)) : n && (n.d(1), n = null);
    },
    d(r) {
      r && k(t), n && n.d(r);
    }
  };
}
function yi(e) {
  let t, n = (
    /*eta*/
    e[0] ? `/${/*formatted_eta*/
    e[19]}` : ""
  ), r, i;
  return {
    c() {
      t = q(
        /*formatted_timer*/
        e[20]
      ), r = q(n), i = q("s");
    },
    m(s, l) {
      C(s, t, l), C(s, r, l), C(s, i, l);
    },
    p(s, l) {
      l[0] & /*formatted_timer*/
      1048576 && me(
        t,
        /*formatted_timer*/
        s[20]
      ), l[0] & /*eta, formatted_eta*/
      524289 && n !== (n = /*eta*/
      s[0] ? `/${/*formatted_eta*/
      s[19]}` : "") && me(r, n);
    },
    d(s) {
      s && (k(t), k(r), k(i));
    }
  };
}
function Rc(e) {
  let t, n;
  return t = new pc({
    props: { margin: (
      /*variant*/
      e[8] === "default"
    ) }
  }), {
    c() {
      bc(t.$$.fragment);
    },
    m(r, i) {
      Tc(t, r, i), n = !0;
    },
    p(r, i) {
      const s = {};
      i[0] & /*variant*/
      256 && (s.margin = /*variant*/
      r[8] === "default"), t.$set(s);
    },
    i(r) {
      n || (gt(t.$$.fragment, r), n = !0);
    },
    o(r) {
      bt(t.$$.fragment, r), n = !1;
    },
    d(r) {
      yc(t, r);
    }
  };
}
function Uc(e) {
  let t, n, r, i, s, l = `${/*last_progress_level*/
  e[15] * 100}%`, a = (
    /*progress*/
    e[7] != null && wi(e)
  );
  return {
    c() {
      t = Pe("div"), n = Pe("div"), a && a.c(), r = Te(), i = Pe("div"), s = Pe("div"), Se(n, "class", "progress-level-inner svelte-1txqlrd"), Se(s, "class", "progress-bar svelte-1txqlrd"), xe(s, "width", l), Se(i, "class", "progress-bar-wrap svelte-1txqlrd"), Se(t, "class", "progress-level svelte-1txqlrd");
    },
    m(o, u) {
      C(o, t, u), Qe(t, n), a && a.m(n, null), Qe(t, r), Qe(t, i), Qe(i, s), e[30](s);
    },
    p(o, u) {
      /*progress*/
      o[7] != null ? a ? a.p(o, u) : (a = wi(o), a.c(), a.m(n, null)) : a && (a.d(1), a = null), u[0] & /*last_progress_level*/
      32768 && l !== (l = `${/*last_progress_level*/
      o[15] * 100}%`) && xe(s, "width", l);
    },
    i: lr,
    o: lr,
    d(o) {
      o && k(t), a && a.d(), e[30](null);
    }
  };
}
function wi(e) {
  let t, n = nn(
    /*progress*/
    e[7]
  ), r = [];
  for (let i = 0; i < n.length; i += 1)
    r[i] = Bi(mi(e, n, i));
  return {
    c() {
      for (let i = 0; i < r.length; i += 1)
        r[i].c();
      t = wt();
    },
    m(i, s) {
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(i, s);
      C(i, t, s);
    },
    p(i, s) {
      if (s[0] & /*progress_level, progress*/
      16512) {
        n = nn(
          /*progress*/
          i[7]
        );
        let l;
        for (l = 0; l < n.length; l += 1) {
          const a = mi(i, n, l);
          r[l] ? r[l].p(a, s) : (r[l] = Bi(a), r[l].c(), r[l].m(t.parentNode, t));
        }
        for (; l < r.length; l += 1)
          r[l].d(1);
        r.length = n.length;
      }
    },
    d(i) {
      i && k(t), ks(r, i);
    }
  };
}
function Ei(e) {
  let t, n, r, i, s = (
    /*i*/
    e[40] !== 0 && xc()
  ), l = (
    /*p*/
    e[38].desc != null && Si(e)
  ), a = (
    /*p*/
    e[38].desc != null && /*progress_level*/
    e[14] && /*progress_level*/
    e[14][
      /*i*/
      e[40]
    ] != null && Ti()
  ), o = (
    /*progress_level*/
    e[14] != null && Ai(e)
  );
  return {
    c() {
      s && s.c(), t = Te(), l && l.c(), n = Te(), a && a.c(), r = Te(), o && o.c(), i = wt();
    },
    m(u, f) {
      s && s.m(u, f), C(u, t, f), l && l.m(u, f), C(u, n, f), a && a.m(u, f), C(u, r, f), o && o.m(u, f), C(u, i, f);
    },
    p(u, f) {
      /*p*/
      u[38].desc != null ? l ? l.p(u, f) : (l = Si(u), l.c(), l.m(n.parentNode, n)) : l && (l.d(1), l = null), /*p*/
      u[38].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[40]
      ] != null ? a || (a = Ti(), a.c(), a.m(r.parentNode, r)) : a && (a.d(1), a = null), /*progress_level*/
      u[14] != null ? o ? o.p(u, f) : (o = Ai(u), o.c(), o.m(i.parentNode, i)) : o && (o.d(1), o = null);
    },
    d(u) {
      u && (k(t), k(n), k(r), k(i)), s && s.d(u), l && l.d(u), a && a.d(u), o && o.d(u);
    }
  };
}
function xc(e) {
  let t;
  return {
    c() {
      t = q(" /");
    },
    m(n, r) {
      C(n, t, r);
    },
    d(n) {
      n && k(t);
    }
  };
}
function Si(e) {
  let t = (
    /*p*/
    e[38].desc + ""
  ), n;
  return {
    c() {
      n = q(t);
    },
    m(r, i) {
      C(r, n, i);
    },
    p(r, i) {
      i[0] & /*progress*/
      128 && t !== (t = /*p*/
      r[38].desc + "") && me(n, t);
    },
    d(r) {
      r && k(n);
    }
  };
}
function Ti(e) {
  let t;
  return {
    c() {
      t = q("-");
    },
    m(n, r) {
      C(n, t, r);
    },
    d(n) {
      n && k(t);
    }
  };
}
function Ai(e) {
  let t = (100 * /*progress_level*/
  (e[14][
    /*i*/
    e[40]
  ] || 0)).toFixed(1) + "", n, r;
  return {
    c() {
      n = q(t), r = q("%");
    },
    m(i, s) {
      C(i, n, s), C(i, r, s);
    },
    p(i, s) {
      s[0] & /*progress_level*/
      16384 && t !== (t = (100 * /*progress_level*/
      (i[14][
        /*i*/
        i[40]
      ] || 0)).toFixed(1) + "") && me(n, t);
    },
    d(i) {
      i && (k(n), k(r));
    }
  };
}
function Bi(e) {
  let t, n = (
    /*p*/
    (e[38].desc != null || /*progress_level*/
    e[14] && /*progress_level*/
    e[14][
      /*i*/
      e[40]
    ] != null) && Ei(e)
  );
  return {
    c() {
      n && n.c(), t = wt();
    },
    m(r, i) {
      n && n.m(r, i), C(r, t, i);
    },
    p(r, i) {
      /*p*/
      r[38].desc != null || /*progress_level*/
      r[14] && /*progress_level*/
      r[14][
        /*i*/
        r[40]
      ] != null ? n ? n.p(r, i) : (n = Ei(r), n.c(), n.m(t.parentNode, t)) : n && (n.d(1), n = null);
    },
    d(r) {
      r && k(t), n && n.d(r);
    }
  };
}
function Hi(e) {
  let t, n;
  return {
    c() {
      t = Pe("p"), n = q(
        /*loading_text*/
        e[9]
      ), Se(t, "class", "loading svelte-1txqlrd");
    },
    m(r, i) {
      C(r, t, i), Qe(t, n);
    },
    p(r, i) {
      i[0] & /*loading_text*/
      512 && me(
        n,
        /*loading_text*/
        r[9]
      );
    },
    d(r) {
      r && k(t);
    }
  };
}
function Fc(e) {
  let t, n, r, i, s;
  const l = [Nc, Pc], a = [];
  function o(u, f) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(n = o(e)) && (r = a[n] = l[n](e)), {
    c() {
      t = Pe("div"), r && r.c(), Se(t, "class", i = "wrap " + /*variant*/
      e[8] + " " + /*show_progress*/
      e[6] + " svelte-1txqlrd"), _e(t, "hide", !/*status*/
      e[4] || /*status*/
      e[4] === "complete" || /*show_progress*/
      e[6] === "hidden"), _e(
        t,
        "translucent",
        /*variant*/
        e[8] === "center" && /*status*/
        (e[4] === "pending" || /*status*/
        e[4] === "error") || /*translucent*/
        e[11] || /*show_progress*/
        e[6] === "minimal"
      ), _e(
        t,
        "generating",
        /*status*/
        e[4] === "generating"
      ), _e(
        t,
        "border",
        /*border*/
        e[12]
      ), xe(
        t,
        "position",
        /*absolute*/
        e[10] ? "absolute" : "static"
      ), xe(
        t,
        "padding",
        /*absolute*/
        e[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, f) {
      C(u, t, f), ~n && a[n].m(t, null), e[31](t), s = !0;
    },
    p(u, f) {
      let c = n;
      n = o(u), n === c ? ~n && a[n].p(u, f) : (r && (Cs(), bt(a[c], 1, 1, () => {
        a[c] = null;
      }), Hs()), ~n ? (r = a[n], r ? r.p(u, f) : (r = a[n] = l[n](u), r.c()), gt(r, 1), r.m(t, null)) : r = null), (!s || f[0] & /*variant, show_progress*/
      320 && i !== (i = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-1txqlrd")) && Se(t, "class", i), (!s || f[0] & /*variant, show_progress, status, show_progress*/
      336) && _e(t, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden"), (!s || f[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && _e(
        t,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!s || f[0] & /*variant, show_progress, status*/
      336) && _e(
        t,
        "generating",
        /*status*/
        u[4] === "generating"
      ), (!s || f[0] & /*variant, show_progress, border*/
      4416) && _e(
        t,
        "border",
        /*border*/
        u[12]
      ), f[0] & /*absolute*/
      1024 && xe(
        t,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), f[0] & /*absolute*/
      1024 && xe(
        t,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      s || (gt(r), s = !0);
    },
    o(u) {
      bt(r), s = !1;
    },
    d(u) {
      u && k(t), ~n && a[n].d(), e[31](null);
    }
  };
}
let jt = [], In = !1;
async function Gc(e, t = !0) {
  if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
    if (jt.push(e), !In)
      In = !0;
    else
      return;
    await Hc(), requestAnimationFrame(() => {
      let n = [0, 0];
      for (let r = 0; r < jt.length; r++) {
        const s = jt[r].getBoundingClientRect();
        (r === 0 || s.top + window.scrollY <= n[0]) && (n[0] = s.top + window.scrollY, n[1] = r);
      }
      window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), In = !1, jt = [];
    });
  }
}
function qc(e, t, n) {
  let r, { $$slots: i = {}, $$scope: s } = t, { i18n: l } = t, { eta: a = null } = t, { queue_position: o } = t, { queue_size: u } = t, { status: f } = t, { scroll_to_output: c = !1 } = t, { timer: h = !0 } = t, { show_progress: _ = "full" } = t, { message: d = null } = t, { progress: p = null } = t, { variant: y = "default" } = t, { loading_text: v = "Loading..." } = t, { absolute: E = !0 } = t, { translucent: g = !1 } = t, { border: A = !1 } = t, { autoscroll: T } = t, w, j = !1, B = 0, H = 0, Z = null, le = null, Ge = 0, $ = null, Ae, oe = null, qe = !0;
  const Et = () => {
    n(0, a = n(26, Z = n(19, Be = null))), n(24, B = performance.now()), n(25, H = 0), j = !0, Le();
  };
  function Le() {
    requestAnimationFrame(() => {
      n(25, H = (performance.now() - B) / 1e3), j && Le();
    });
  }
  function rt() {
    n(25, H = 0), n(0, a = n(26, Z = n(19, Be = null))), j && (j = !1);
  }
  kc(() => {
    j && rt();
  });
  let Be = null;
  function m(b) {
    _i[b ? "unshift" : "push"](() => {
      oe = b, n(16, oe), n(7, p), n(14, $), n(15, Ae);
    });
  }
  function N(b) {
    _i[b ? "unshift" : "push"](() => {
      w = b, n(13, w);
    });
  }
  return e.$$set = (b) => {
    "i18n" in b && n(1, l = b.i18n), "eta" in b && n(0, a = b.eta), "queue_position" in b && n(2, o = b.queue_position), "queue_size" in b && n(3, u = b.queue_size), "status" in b && n(4, f = b.status), "scroll_to_output" in b && n(21, c = b.scroll_to_output), "timer" in b && n(5, h = b.timer), "show_progress" in b && n(6, _ = b.show_progress), "message" in b && n(22, d = b.message), "progress" in b && n(7, p = b.progress), "variant" in b && n(8, y = b.variant), "loading_text" in b && n(9, v = b.loading_text), "absolute" in b && n(10, E = b.absolute), "translucent" in b && n(11, g = b.translucent), "border" in b && n(12, A = b.border), "autoscroll" in b && n(23, T = b.autoscroll), "$$scope" in b && n(28, s = b.$$scope);
  }, e.$$.update = () => {
    e.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    218103809 && (a === null && n(0, a = Z), a != null && Z !== a && (n(27, le = (performance.now() - B) / 1e3 + a), n(19, Be = le.toFixed(1)), n(26, Z = a))), e.$$.dirty[0] & /*eta_from_start, timer_diff*/
    167772160 && n(17, Ge = le === null || le <= 0 || !H ? null : Math.min(H / le, 1)), e.$$.dirty[0] & /*progress*/
    128 && p != null && n(18, qe = !1), e.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (p != null ? n(14, $ = p.map((b) => {
      if (b.index != null && b.length != null)
        return b.index / b.length;
      if (b.progress != null)
        return b.progress;
    })) : n(14, $ = null), $ ? (n(15, Ae = $[$.length - 1]), oe && (Ae === 0 ? n(16, oe.style.transition = "0", oe) : n(16, oe.style.transition = "150ms", oe))) : n(15, Ae = void 0)), e.$$.dirty[0] & /*status*/
    16 && (f === "pending" ? Et() : rt()), e.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    10493968 && w && c && (f === "pending" || f === "complete") && Gc(w, T), e.$$.dirty[0] & /*status, message*/
    4194320, e.$$.dirty[0] & /*timer_diff*/
    33554432 && n(20, r = H.toFixed(1));
  }, [
    a,
    l,
    o,
    u,
    f,
    h,
    _,
    p,
    y,
    v,
    E,
    g,
    A,
    w,
    $,
    Ae,
    oe,
    Ge,
    qe,
    Be,
    r,
    c,
    d,
    T,
    B,
    H,
    Z,
    le,
    s,
    i,
    m,
    N
  ];
}
class Ps extends gc {
  constructor(t) {
    super(), Sc(
      this,
      t,
      qc,
      Fc,
      Ac,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 21,
        timer: 5,
        show_progress: 6,
        message: 22,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 23
      },
      null,
      [-1, -1]
    );
  }
}
const {
  SvelteComponent: jc,
  append: Vc,
  attr: At,
  detach: Ns,
  element: ki,
  empty: zc,
  init: Xc,
  insert: Is,
  noop: Ci,
  safe_not_equal: Wc,
  src_url_equal: Pi,
  toggle_class: ot
} = window.__gradio__svelte__internal;
function Ni(e) {
  let t, n, r;
  return {
    c() {
      t = ki("div"), n = ki("img"), Pi(n.src, r = /*samples_dir*/
      e[1] + /*value*/
      e[0].path) || At(n, "src", r), At(n, "alt", ""), At(n, "class", "svelte-giydt1"), At(t, "class", "container svelte-giydt1"), ot(
        t,
        "table",
        /*type*/
        e[2] === "table"
      ), ot(
        t,
        "gallery",
        /*type*/
        e[2] === "gallery"
      ), ot(
        t,
        "selected",
        /*selected*/
        e[3]
      );
    },
    m(i, s) {
      Is(i, t, s), Vc(t, n);
    },
    p(i, s) {
      s & /*samples_dir, value*/
      3 && !Pi(n.src, r = /*samples_dir*/
      i[1] + /*value*/
      i[0].path) && At(n, "src", r), s & /*type*/
      4 && ot(
        t,
        "table",
        /*type*/
        i[2] === "table"
      ), s & /*type*/
      4 && ot(
        t,
        "gallery",
        /*type*/
        i[2] === "gallery"
      ), s & /*selected*/
      8 && ot(
        t,
        "selected",
        /*selected*/
        i[3]
      );
    },
    d(i) {
      i && Ns(t);
    }
  };
}
function Zc(e) {
  let t, n = (
    /*value*/
    e[0] && Ni(e)
  );
  return {
    c() {
      n && n.c(), t = zc();
    },
    m(r, i) {
      n && n.m(r, i), Is(r, t, i);
    },
    p(r, [i]) {
      /*value*/
      r[0] ? n ? n.p(r, i) : (n = Ni(r), n.c(), n.m(t.parentNode, t)) : n && (n.d(1), n = null);
    },
    i: Ci,
    o: Ci,
    d(r) {
      r && Ns(t), n && n.d(r);
    }
  };
}
function Jc(e, t, n) {
  let { value: r } = t, { samples_dir: i } = t, { type: s } = t, { selected: l = !1 } = t;
  return e.$$set = (a) => {
    "value" in a && n(0, r = a.value), "samples_dir" in a && n(1, i = a.samples_dir), "type" in a && n(2, s = a.type), "selected" in a && n(3, l = a.selected);
  }, [r, i, s, l];
}
class b0 extends jc {
  constructor(t) {
    super(), Xc(this, t, Jc, Zc, Wc, {
      value: 0,
      samples_dir: 1,
      type: 2,
      selected: 3
    });
  }
}
const {
  SvelteComponent: Qc,
  add_flush_callback: Yc,
  assign: Ls,
  bind: Kc,
  binding_callbacks: $c,
  check_outros: e0,
  create_component: $e,
  destroy_component: et,
  detach: br,
  empty: t0,
  flush: te,
  get_spread_object: Os,
  get_spread_update: Ms,
  group_outros: n0,
  init: r0,
  insert: vr,
  mount_component: tt,
  safe_not_equal: i0,
  space: Ds,
  transition_in: Ne,
  transition_out: Ie
} = window.__gradio__svelte__internal;
function s0(e) {
  let t, n;
  return t = new Oi({
    props: {
      visible: (
        /*visible*/
        e[3]
      ),
      variant: (
        /*_value*/
        e[13] === null ? "dashed" : "solid"
      ),
      border_mode: (
        /*dragging*/
        e[14] ? "focus" : "base"
      ),
      padding: !1,
      elem_id: (
        /*elem_id*/
        e[1]
      ),
      elem_classes: (
        /*elem_classes*/
        e[2]
      ),
      allow_overflow: !1,
      container: (
        /*container*/
        e[7]
      ),
      scale: (
        /*scale*/
        e[8]
      ),
      min_width: (
        /*min_width*/
        e[9]
      ),
      $$slots: { default: [a0] },
      $$scope: { ctx: e }
    }
  }), {
    c() {
      $e(t.$$.fragment);
    },
    m(r, i) {
      tt(t, r, i), n = !0;
    },
    p(r, i) {
      const s = {};
      i & /*visible*/
      8 && (s.visible = /*visible*/
      r[3]), i & /*_value*/
      8192 && (s.variant = /*_value*/
      r[13] === null ? "dashed" : "solid"), i & /*dragging*/
      16384 && (s.border_mode = /*dragging*/
      r[14] ? "focus" : "base"), i & /*elem_id*/
      2 && (s.elem_id = /*elem_id*/
      r[1]), i & /*elem_classes*/
      4 && (s.elem_classes = /*elem_classes*/
      r[2]), i & /*container*/
      128 && (s.container = /*container*/
      r[7]), i & /*scale*/
      256 && (s.scale = /*scale*/
      r[8]), i & /*min_width*/
      512 && (s.min_width = /*min_width*/
      r[9]), i & /*$$scope, root, label, show_label, gradio, value, dragging, loading_status*/
      2118769 && (s.$$scope = { dirty: i, ctx: r }), t.$set(s);
    },
    i(r) {
      n || (Ne(t.$$.fragment, r), n = !0);
    },
    o(r) {
      Ie(t.$$.fragment, r), n = !1;
    },
    d(r) {
      et(t, r);
    }
  };
}
function l0(e) {
  let t, n;
  return t = new Oi({
    props: {
      visible: (
        /*visible*/
        e[3]
      ),
      variant: "solid",
      border_mode: (
        /*dragging*/
        e[14] ? "focus" : "base"
      ),
      padding: !1,
      elem_id: (
        /*elem_id*/
        e[1]
      ),
      elem_classes: (
        /*elem_classes*/
        e[2]
      ),
      allow_overflow: !1,
      container: (
        /*container*/
        e[7]
      ),
      scale: (
        /*scale*/
        e[8]
      ),
      min_width: (
        /*min_width*/
        e[9]
      ),
      $$slots: { default: [u0] },
      $$scope: { ctx: e }
    }
  }), {
    c() {
      $e(t.$$.fragment);
    },
    m(r, i) {
      tt(t, r, i), n = !0;
    },
    p(r, i) {
      const s = {};
      i & /*visible*/
      8 && (s.visible = /*visible*/
      r[3]), i & /*dragging*/
      16384 && (s.border_mode = /*dragging*/
      r[14] ? "focus" : "base"), i & /*elem_id*/
      2 && (s.elem_id = /*elem_id*/
      r[1]), i & /*elem_classes*/
      4 && (s.elem_classes = /*elem_classes*/
      r[2]), i & /*container*/
      128 && (s.container = /*container*/
      r[7]), i & /*scale*/
      256 && (s.scale = /*scale*/
      r[8]), i & /*min_width*/
      512 && (s.min_width = /*min_width*/
      r[9]), i & /*$$scope, _value, label, show_label, gradio, loading_status*/
      2110560 && (s.$$scope = { dirty: i, ctx: r }), t.$set(s);
    },
    i(r) {
      n || (Ne(t.$$.fragment, r), n = !0);
    },
    o(r) {
      Ie(t.$$.fragment, r), n = !1;
    },
    d(r) {
      et(t, r);
    }
  };
}
function o0(e) {
  let t, n;
  return t = new Io({
    props: {
      i18n: (
        /*gradio*/
        e[12].i18n
      ),
      mode: "short"
    }
  }), {
    c() {
      $e(t.$$.fragment);
    },
    m(r, i) {
      tt(t, r, i), n = !0;
    },
    p(r, i) {
      const s = {};
      i & /*gradio*/
      4096 && (s.i18n = /*gradio*/
      r[12].i18n), t.$set(s);
    },
    i(r) {
      n || (Ne(t.$$.fragment, r), n = !0);
    },
    o(r) {
      Ie(t.$$.fragment, r), n = !1;
    },
    d(r) {
      et(t, r);
    }
  };
}
function a0(e) {
  let t, n, r, i, s;
  const l = [
    {
      autoscroll: (
        /*gradio*/
        e[12].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      e[12].i18n
    ) },
    /*loading_status*/
    e[10]
  ];
  let a = {};
  for (let f = 0; f < l.length; f += 1)
    a = Ls(a, l[f]);
  t = new Ps({ props: a });
  function o(f) {
    e[17](f);
  }
  let u = {
    root: (
      /*root*/
      e[4]
    ),
    label: (
      /*label*/
      e[5]
    ),
    show_label: (
      /*show_label*/
      e[6]
    ),
    i18n: (
      /*gradio*/
      e[12].i18n
    ),
    $$slots: { default: [o0] },
    $$scope: { ctx: e }
  };
  return (
    /*value*/
    e[0] !== void 0 && (u.value = /*value*/
    e[0]), r = new lc({ props: u }), $c.push(() => Kc(r, "value", o)), r.$on(
      "clear",
      /*clear_handler*/
      e[18]
    ), r.$on(
      "drag",
      /*drag_handler*/
      e[19]
    ), r.$on(
      "upload",
      /*upload_handler*/
      e[20]
    ), {
      c() {
        $e(t.$$.fragment), n = Ds(), $e(r.$$.fragment);
      },
      m(f, c) {
        tt(t, f, c), vr(f, n, c), tt(r, f, c), s = !0;
      },
      p(f, c) {
        const h = c & /*gradio, loading_status*/
        5120 ? Ms(l, [
          c & /*gradio*/
          4096 && {
            autoscroll: (
              /*gradio*/
              f[12].autoscroll
            )
          },
          c & /*gradio*/
          4096 && { i18n: (
            /*gradio*/
            f[12].i18n
          ) },
          c & /*loading_status*/
          1024 && Os(
            /*loading_status*/
            f[10]
          )
        ]) : {};
        t.$set(h);
        const _ = {};
        c & /*root*/
        16 && (_.root = /*root*/
        f[4]), c & /*label*/
        32 && (_.label = /*label*/
        f[5]), c & /*show_label*/
        64 && (_.show_label = /*show_label*/
        f[6]), c & /*gradio*/
        4096 && (_.i18n = /*gradio*/
        f[12].i18n), c & /*$$scope, gradio*/
        2101248 && (_.$$scope = { dirty: c, ctx: f }), !i && c & /*value*/
        1 && (i = !0, _.value = /*value*/
        f[0], Yc(() => i = !1)), r.$set(_);
      },
      i(f) {
        s || (Ne(t.$$.fragment, f), Ne(r.$$.fragment, f), s = !0);
      },
      o(f) {
        Ie(t.$$.fragment, f), Ie(r.$$.fragment, f), s = !1;
      },
      d(f) {
        f && br(n), et(t, f), et(r, f);
      }
    }
  );
}
function u0(e) {
  let t, n, r, i;
  const s = [
    {
      autoscroll: (
        /*gradio*/
        e[12].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      e[12].i18n
    ) },
    /*loading_status*/
    e[10]
  ];
  let l = {};
  for (let a = 0; a < s.length; a += 1)
    l = Ls(l, s[a]);
  return t = new Ps({ props: l }), r = new sa({
    props: {
      value: (
        /*_value*/
        e[13]
      ),
      label: (
        /*label*/
        e[5]
      ),
      show_label: (
        /*show_label*/
        e[6]
      ),
      i18n: (
        /*gradio*/
        e[12].i18n
      )
    }
  }), {
    c() {
      $e(t.$$.fragment), n = Ds(), $e(r.$$.fragment);
    },
    m(a, o) {
      tt(t, a, o), vr(a, n, o), tt(r, a, o), i = !0;
    },
    p(a, o) {
      const u = o & /*gradio, loading_status*/
      5120 ? Ms(s, [
        o & /*gradio*/
        4096 && {
          autoscroll: (
            /*gradio*/
            a[12].autoscroll
          )
        },
        o & /*gradio*/
        4096 && { i18n: (
          /*gradio*/
          a[12].i18n
        ) },
        o & /*loading_status*/
        1024 && Os(
          /*loading_status*/
          a[10]
        )
      ]) : {};
      t.$set(u);
      const f = {};
      o & /*_value*/
      8192 && (f.value = /*_value*/
      a[13]), o & /*label*/
      32 && (f.label = /*label*/
      a[5]), o & /*show_label*/
      64 && (f.show_label = /*show_label*/
      a[6]), o & /*gradio*/
      4096 && (f.i18n = /*gradio*/
      a[12].i18n), r.$set(f);
    },
    i(a) {
      i || (Ne(t.$$.fragment, a), Ne(r.$$.fragment, a), i = !0);
    },
    o(a) {
      Ie(t.$$.fragment, a), Ie(r.$$.fragment, a), i = !1;
    },
    d(a) {
      a && br(n), et(t, a), et(r, a);
    }
  };
}
function f0(e) {
  let t, n, r, i;
  const s = [l0, s0], l = [];
  function a(o, u) {
    return (
      /*interactive*/
      o[11] ? 1 : 0
    );
  }
  return t = a(e), n = l[t] = s[t](e), {
    c() {
      n.c(), r = t0();
    },
    m(o, u) {
      l[t].m(o, u), vr(o, r, u), i = !0;
    },
    p(o, [u]) {
      let f = t;
      t = a(o), t === f ? l[t].p(o, u) : (n0(), Ie(l[f], 1, 1, () => {
        l[f] = null;
      }), e0(), n = l[t], n ? n.p(o, u) : (n = l[t] = s[t](o), n.c()), Ne(n, 1), n.m(r.parentNode, r));
    },
    i(o) {
      i || (Ne(n), i = !0);
    },
    o(o) {
      Ie(n), i = !1;
    },
    d(o) {
      o && br(r), l[t].d(o);
    }
  };
}
function c0(e) {
  let t, n = e[0], r = 1;
  for (; r < e.length; ) {
    const i = e[r], s = e[r + 1];
    if (r += 2, (i === "optionalAccess" || i === "optionalCall") && n == null)
      return;
    i === "access" || i === "optionalAccess" ? (t = n, n = s(n)) : (i === "call" || i === "optionalCall") && (n = s((...l) => n.call(t, ...l)), t = void 0);
  }
  return n;
}
function h0(e, t, n) {
  let r, i, { elem_id: s = "" } = t, { elem_classes: l = [] } = t, { visible: a = !0 } = t, { value: o = null } = t, { root: u } = t, { proxy_url: f } = t, { label: c } = t, { show_label: h } = t, { container: _ = !0 } = t, { scale: d = null } = t, { min_width: p = void 0 } = t, { loading_status: y } = t, { interactive: v } = t, { gradio: E } = t, g;
  function A(B) {
    o = B, n(0, o);
  }
  const T = () => E.dispatch("clear"), w = ({ detail: B }) => n(14, g = B), j = () => E.dispatch("upload");
  return e.$$set = (B) => {
    "elem_id" in B && n(1, s = B.elem_id), "elem_classes" in B && n(2, l = B.elem_classes), "visible" in B && n(3, a = B.visible), "value" in B && n(0, o = B.value), "root" in B && n(4, u = B.root), "proxy_url" in B && n(15, f = B.proxy_url), "label" in B && n(5, c = B.label), "show_label" in B && n(6, h = B.show_label), "container" in B && n(7, _ = B.container), "scale" in B && n(8, d = B.scale), "min_width" in B && n(9, p = B.min_width), "loading_status" in B && n(10, y = B.loading_status), "interactive" in B && n(11, v = B.interactive), "gradio" in B && n(12, E = B.gradio);
  }, e.$$.update = () => {
    e.$$.dirty & /*value, root, proxy_url*/
    32785 && n(13, r = Ce(o, u, f)), e.$$.dirty & /*_value*/
    8192 && n(16, i = c0([r, "optionalAccess", (B) => B.url])), e.$$.dirty & /*url, gradio*/
    69632 && E.dispatch("change");
  }, [
    o,
    s,
    l,
    a,
    u,
    c,
    h,
    _,
    d,
    p,
    y,
    v,
    E,
    r,
    g,
    f,
    i,
    A,
    T,
    w,
    j
  ];
}
class v0 extends Qc {
  constructor(t) {
    super(), r0(this, t, h0, f0, i0, {
      elem_id: 1,
      elem_classes: 2,
      visible: 3,
      value: 0,
      root: 4,
      proxy_url: 15,
      label: 5,
      show_label: 6,
      container: 7,
      scale: 8,
      min_width: 9,
      loading_status: 10,
      interactive: 11,
      gradio: 12
    });
  }
  get elem_id() {
    return this.$$.ctx[1];
  }
  set elem_id(t) {
    this.$$set({ elem_id: t }), te();
  }
  get elem_classes() {
    return this.$$.ctx[2];
  }
  set elem_classes(t) {
    this.$$set({ elem_classes: t }), te();
  }
  get visible() {
    return this.$$.ctx[3];
  }
  set visible(t) {
    this.$$set({ visible: t }), te();
  }
  get value() {
    return this.$$.ctx[0];
  }
  set value(t) {
    this.$$set({ value: t }), te();
  }
  get root() {
    return this.$$.ctx[4];
  }
  set root(t) {
    this.$$set({ root: t }), te();
  }
  get proxy_url() {
    return this.$$.ctx[15];
  }
  set proxy_url(t) {
    this.$$set({ proxy_url: t }), te();
  }
  get label() {
    return this.$$.ctx[5];
  }
  set label(t) {
    this.$$set({ label: t }), te();
  }
  get show_label() {
    return this.$$.ctx[6];
  }
  set show_label(t) {
    this.$$set({ show_label: t }), te();
  }
  get container() {
    return this.$$.ctx[7];
  }
  set container(t) {
    this.$$set({ container: t }), te();
  }
  get scale() {
    return this.$$.ctx[8];
  }
  set scale(t) {
    this.$$set({ scale: t }), te();
  }
  get min_width() {
    return this.$$.ctx[9];
  }
  set min_width(t) {
    this.$$set({ min_width: t }), te();
  }
  get loading_status() {
    return this.$$.ctx[10];
  }
  set loading_status(t) {
    this.$$set({ loading_status: t }), te();
  }
  get interactive() {
    return this.$$.ctx[11];
  }
  set interactive(t) {
    this.$$set({ interactive: t }), te();
  }
  get gradio() {
    return this.$$.ctx[12];
  }
  set gradio(t) {
    this.$$set({ gradio: t }), te();
  }
}
export {
  b0 as BaseExample,
  lc as BaseImageUploader,
  sa as BaseStaticImage,
  v0 as default
};
