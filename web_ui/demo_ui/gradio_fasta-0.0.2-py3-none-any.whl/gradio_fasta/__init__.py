
from .fasta import FASTA

__all__ = ['FASTA']
